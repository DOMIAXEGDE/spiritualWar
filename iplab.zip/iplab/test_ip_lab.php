<?php
/**
 * IP Lab - Automated Backend Test Suite
 *
 * This script runs a series of automated tests for Phase 1 (Unit/Module) and
 * Phase 2 (Integration) to validate the core functionality of the IP Lab backend.
 * It also includes placeholder tests for future architect-level features.
 *
 * USAGE: Run from the command line in the root iplab directory:
 * > php test_ip_lab.php
 */

// --- Test Environment Setup ---
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Emulate a web server environment for the session
$_SERVER['HTTP_HOST'] = 'localhost';
$_SERVER['REQUEST_URI'] = '/';

require_once 'bootstrap.php';

class TestRunner
{
    private int $passCount = 0;
    private int $failCount = 0;
    private int $skippedCount = 0;
    private string $currentGroup = '';

    public function startGroup(string $name): void
    {
        $this->currentGroup = $name;
        echo "\n--- Testing Group: {$name} ---\n";
    }

    public function run(string $description, callable $testFn): void
    {
        try {
            $result = $testFn();
            if ($result === false) {
                throw new Exception("Assertion failed.");
            }
            $this->pass($description);
        } catch (Throwable $e) {
            // Check for the specific "not implemented" message to mark as skipped.
            if (strpos($e->getMessage(), "Test not implemented yet.") !== false) {
                $this->skip($description, "Not implemented");
            } else {
                $this->fail($description, $e->getMessage());
            }
        }
    }

    private function pass(string $description): void
    {
        $this->passCount++;
        echo "  \033[32m✓ PASS:\033[0m {$description}\n";
    }

    private function fail(string $description, string $reason): void
    {
        $this->failCount++;
        echo "  \033[31m✗ FAIL:\033[0m {$description}\n";
        echo "    \033[90mReason: {$reason}\033[0m\n";
    }

    private function skip(string $description, string $reason): void
    {
        $this->skippedCount++;
        echo "  \033[33m~ SKIP:\033[0m {$description}\n";
        echo "    \033[90mReason: {$reason}\033[0m\n";
    }

    public function report(): void
    {
        echo "\n--- Test Report ---\n";
        echo "Total Tests: " . ($this->passCount + $this->failCount + $this->skippedCount) . "\n";
        echo "\033[32mPassed: {$this->passCount}\033[0m\n";
        if ($this->failCount > 0) {
            echo "\033[31mFailed: {$this->failCount}\033[0m\n";
        }
        if ($this->skippedCount > 0) {
            echo "\033[33mSkipped: {$this->skippedCount}\033[0m\n";
        }
        if ($this->failCount === 0) {
            echo "All tests passed successfully!\n";
        }
        echo "-------------------\n";
    }
}

/**
 * Recursively deletes a directory.
 * @param string $dir The directory path to delete.
 */
function deleteDirectory(string $dir): void {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? deleteDirectory("$dir/$file") : unlink("$dir/$file");
    }
    rmdir($dir);
}

/**
 * Simulates a user login to establish a session.
 * @param string $username The user's username.
 * @param string $password The user's password.
 */
function simulateLogin(string $username, string $password): void {
    // Reset session before logging in
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
    session_start();
    
    $_POST['method'] = 'login';
    $_POST['params'] = json_encode(['username' => $username, 'password' => $password]);
    handleAuthAPI();
}

// ============================================================
// TEST EXECUTION
// ============================================================

$runner = new TestRunner();

// --- Setup: Clean and initialize the environment ---
$runner->startGroup("Environment Setup");
$runner->run("Clean storage directory", function() {
    global $config;
    deleteDirectory($config['filesystem']['root_dir']);
    return !is_dir($config['filesystem']['root_dir']);
});

$runner->run("Create required storage directories", function() {
    global $config;
    $dirs = [
        $config['filesystem']['root_dir'],
        $config['filesystem']['system_dir'],
        $config['filesystem']['user_dir'],
        $config['filesystem']['apps_dir'],
        $config['filesystem']['temp_dir']
    ];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, true)) {
                return false;
            }
        }
    }
    return true;
});

$runner->run("Initialize system (create default files)", function() {
    initializeSystem();
    global $config;
    return file_exists($config['filesystem']['system_dir'] . '/users.json');
});

// --- Phase 1: Unit & Module Testing ---

$runner->startGroup("Auth Module");
$runner->run("Should register a new developer user 'testdev'", function() {
    $_POST['method'] = 'register';
    $_POST['params'] = json_encode([
        'username' => 'testdev',
        'password' => 'password123',
        'name' => 'Test Developer'
    ]);
    $response = handleAuthAPI();
    return $response['success'] === true;
});
$runner->run("Should fail to log in with incorrect credentials", function() {
    simulateLogin('admin', 'wrongpassword');
    return !isAuthenticated();
});
$runner->run("Should log in successfully as 'admin'", function() {
    simulateLogin('admin', '00EITA00');
    return isAuthenticated() && isAdmin();
});
$runner->run("Should verify admin permissions", function() {
    return hasPermission('system.admin.*') && hasPermission('filesystem.write.*');
});

$runner->startGroup("Users Module (as Admin)");
$runner->run("Should create a new user 'testuser'", function() {
    simulateLogin('admin', '00EITA00');
    $_POST['method'] = 'createUser';
    $_POST['params'] = json_encode(['username' => 'testuser', 'password' => 'password123', 'name' => 'Test User', 'roles' => ['user']]);
    $response = handleUsersAPI();
    return $response['success'] === true;
});
$runner->run("Should update 'testuser' details", function() {
    $_POST['method'] = 'updateUser';
    $_POST['params'] = json_encode(['username' => 'testuser', 'name' => 'Updated Test User']);
    $response = handleUsersAPI();
    return $response['success'] === true;
});
$runner->run("Should delete 'testuser'", function() {
    $_POST['method'] = 'deleteUser';
    $_POST['params'] = json_encode(['username' => 'testuser']);
    $response = handleUsersAPI();
    return $response['success'] === true;
});

$runner->startGroup("Apps Module (as Developer & Admin)");
$runner->run("Should submit an application as 'testdev'", function() {
    simulateLogin('testdev', 'password123');
    $params = [
        'manifest' => json_encode(['id' => 'test-app', 'title' => 'Test App', 'entry' => 'test.js']),
        'code' => 'console.log("hello world");'
    ];
    $response = submitApp($params);
    return $response['success'] === true;
});
$runner->run("Should list pending submission as 'admin'", function() {
    simulateLogin('admin', '00EITA00');
    $submissions = loadAppSubmissions();
    return count($submissions) === 1 && $submissions[0]['manifest']['id'] === 'test-app';
});
$runner->run("Should approve the submitted application", function() {
    $params = ['id' => 'test-app'];
    $response = approveSubmission($params);
    return $response['success'] === true;
});
$runner->run("Should list the new app in the main catalogue", function() {
    $apps = listApps();
    $found = false;
    foreach ($apps as $app) {
        if ($app['id'] === 'test-app') {
            $found = true;
            break;
        }
    }
    return $found;
});

$runner->startGroup("Sandbox Module (as Admin)");
$runner->run("Should execute simple, safe code", function() {
    simulateLogin('admin', '00EITA00');
    $_POST['method'] = 'execute';
    $_POST['params'] = json_encode(['code' => 'echo "sandbox ok";']);
    $response = handleSandboxAPI();
    return $response['success'] === true && trim($response['data']['output']) === 'sandbox ok';
});
$runner->run("Should handle and report a fatal error", function() {
    $_POST['method'] = 'execute';
    $_POST['params'] = json_encode(['code' => 'this_is_a_fatal_error();']);
    $response = handleSandboxAPI();
    return $response['success'] === true && strpos($response['data']['output'], 'Error: Call to undefined function') !== false;
});
$runner->run("Should respect disabled functions", function() {
    $_POST['method'] = 'execute';
    $_POST['params'] = json_encode(['code' => 'echo shell_exec("echo hello");']);
    $response = handleSandboxAPI();
    return $response['success'] === true && strpos($response['data']['errors'], 'shell_exec() has been disabled') !== false;
});


// --- Phase 2: Integration Testing ---

$runner->startGroup("Auth <-> Filesystem Integration");
$runner->run("Should FAIL for 'testdev' to write to a system directory", function() {
    simulateLogin('testdev', 'password123');
    $_POST['method'] = 'writeFile';
    $_POST['params'] = json_encode(['path' => '/system/test.txt', 'content' => 'test']);
    $response = handleFileSystemAPI();
    return $response['success'] === false && $response['message'] === 'Access Denied';
});
$runner->run("Should SUCCEED for 'testdev' to write to their home directory", function() {
    $_POST['method'] = 'writeFile';
    $_POST['params'] = json_encode(['path' => '/users/testdev/Documents/test.txt', 'content' => 'test']);
    $response = handleFileSystemAPI();
    return $response['success'] === true;
});

$runner->startGroup("Apps <-> Filesystem Integration");
$runner->run("Should create physical app files upon approval", function() {
    global $config;
    $appDir = $config['filesystem']['apps_dir'] . '/test-app';
    $manifestPath = $appDir . '/test-app.json';
    $scriptPath = $appDir . '/test-app.js';
    return is_dir($appDir) && is_file($manifestPath) && is_file($scriptPath);
});

$runner->startGroup("Process Integration (Simulating Frontend)");
$runner->run("Should successfully retrieve a built-in app manifest for launch", function() {
    simulateLogin('admin', '00EITA00');
    $response = getAppInfo(['id' => 'fileManager']);
    return $response !== null && $response['id'] === 'fileManager';
});

// --- ENHANCEMENT: Placeholder tests for future architect features ---
$runner->startGroup("Architect Module (Future Implementation)");
$runner->run("Should export the current OS state as version_1", function() {
    // This is a placeholder for a future feature.
    // It would call an API like: handleArchitectAPI('export', ['version' => 1]);
    throw new Exception("Test not implemented yet.");
});
$runner->run("Should be able to generate a new version of IP Lab", function() {
    // This is a placeholder for the core self-generation feature.
    // It would involve complex state analysis and code generation.
    throw new Exception("Test not implemented yet.");
});


// --- Final Report ---
$runner->report();

// Clean up session
if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}
?>
