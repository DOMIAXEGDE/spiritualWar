/**
 * IP Lab Terminal Application
 *
 * This is the entry point for the kernel-aware terminal. It receives an API
 * proxy from the kernel, allowing it to execute commands that interact
 * directly with the OS modules.
 */

class TerminalApp {
    constructor(kernelApi) {
        this.api = kernelApi;
        this.state = {
            currentDir: `/users/${this.api.user.username}`,
            history: [],
            historyIndex: -1,
        };
        this.container = this.api.window.getContainer();
        this.initializeUI();
        this.registerCommands();
    }

    initializeUI() {
        this.container.innerHTML = `
            <div class="terminal-container">
                <div class="terminal-output"></div>
                <div class="terminal-input-line">
                    <span class="terminal-prompt"></span>
                    <input type="text" class="terminal-input" autofocus>
                </div>
            </div>
            <style>
                .terminal-container { height:100%; display:flex; flex-direction:column; background:#0a0a0a; font-family: 'Courier New', monospace; font-size: 14px; }
                .terminal-output { flex-grow:1; overflow-y:auto; padding:10px; white-space:pre-wrap; }
                .terminal-input-line { display:flex; padding:5px; }
                .terminal-prompt { color:#33ff33; }
                .terminal-input { flex-grow:1; background:transparent; border:none; color:#33ff33; font-family:inherit; outline:none; font-size: inherit; }
                .terminal-output .error { color: #ff4d4d; }
                .terminal-output .info { color: #87ceeb; }
                .terminal-output .success { color: #28a745; }
                table { border-collapse: collapse; width: 100%; margin: 5px 0; }
                td, th { padding: 2px 8px; text-align: left; }
            </style>
        `;

        this.outputEl = this.container.querySelector('.terminal-output');
        this.inputEl = this.container.querySelector('.terminal-input');
        this.promptEl = this.container.querySelector('.terminal-prompt');

        this.inputEl.addEventListener('keydown', e => this.handleInput(e));
        this.container.addEventListener('click', () => this.inputEl.focus());

        this.appendOutput(`IP Lab Kernel Terminal [Version ${this.api.app.version}]`);
        this.updatePrompt();
    }

    registerCommands() {
        this.commands = {
            'help': { exec: this.cmd_help.bind(this), desc: 'Show this help message.' },
            'ls': { exec: this.cmd_ls.bind(this), desc: 'List directory contents.' },
            'cd': { exec: this.cmd_cd.bind(this), desc: 'Change directory.' },
            'pwd': { exec: this.cmd_pwd.bind(this), desc: 'Print working directory.' },
            'cat': { exec: this.cmd_cat.bind(this), desc: 'Show file content.' },
            'mkdir': { exec: this.cmd_mkdir.bind(this), desc: 'Create a directory.' },
            'touch': { exec: this.cmd_touch.bind(this), desc: 'Create an empty file.' },
            'rm': { exec: this.cmd_rm.bind(this), desc: 'Remove a file or empty directory.' },
            'clear': { exec: this.cmd_clear.bind(this), desc: 'Clear the terminal screen.' },
            'echo': { exec: this.cmd_echo.bind(this), desc: 'Display a line of text.' },
            'whoami': { exec: this.cmd_whoami.bind(this), desc: 'Print the current user.' },
            'date': { exec: this.cmd_date.bind(this), desc: 'Print the current date and time.' },
            'ps': { exec: this.cmd_ps.bind(this), desc: 'List running processes.' },
            'kill': { exec: this.cmd_kill.bind(this), desc: 'Terminate a process by its PID.' },
            'start': { exec: this.cmd_start.bind(this), desc: 'Launch an application by its ID.' },
            'sysinfo': { exec: this.cmd_sysinfo.bind(this), desc: 'Display system information.' },
            'arch': { exec: this.cmd_arch.bind(this), desc: 'Architect IP Lab (admin only).' }
        };
    }

    async handleInput(e) {
        if (e.key === 'Enter') {
            const commandLine = this.inputEl.value;
            if (commandLine.trim()) {
                this.state.history.push(commandLine);
                this.state.historyIndex = this.state.history.length;
                this.appendOutput(`${this.promptEl.textContent}${commandLine}`);
                await this.executeCommand(commandLine);
                this.inputEl.value = '';
                this.updatePrompt();
            }
        } else if (e.key === 'ArrowUp') {
            if (this.state.historyIndex > 0) {
                this.state.historyIndex--;
                this.inputEl.value = this.state.history[this.state.historyIndex];
            }
        } else if (e.key === 'ArrowDown') {
            if (this.state.historyIndex < this.state.history.length - 1) {
                this.state.historyIndex++;
                this.inputEl.value = this.state.history[this.state.historyIndex];
            } else {
                this.state.historyIndex = this.state.history.length;
                this.inputEl.value = '';
            }
        }
    }

    async executeCommand(commandLine) {
        const [cmd, ...args] = commandLine.trim().split(' ').filter(Boolean);
        if (this.commands[cmd]) {
            try {
                await this.commands[cmd].exec(args);
            } catch (error) {
                this.appendOutput(`<span class="error">Error: ${error.message}</span>`);
            }
        } else {
            this.appendOutput(`<span class="error">Command not found: ${cmd}</span>`);
        }
    }

    // --- Command Implementations ---
    cmd_help() {
        let helpText = 'IP Lab Kernel Terminal Commands:\n\n';
        for (const [cmd, { desc }] of Object.entries(this.commands)) {
            helpText += `  ${cmd.padEnd(10)} ${desc}\n`;
        }
        this.appendOutput(helpText);
    }
    async cmd_ls(args) {
        const path = this._resolvePath(args[0] || this.state.currentDir);
        const files = await this.api.filesystem.listDirectory(path);
        let output = files.map(f => `<span style="color:${f.type === 'directory' ? '#87ceeb' : '#ffffff'};">${f.name}</span>`).join('\n');
        this.appendOutput(output || '(empty)');
    }
    async cmd_cd(args) {
        const newPath = this._resolvePath(args[0] || `~`);
        await this.api.filesystem.listDirectory(newPath); // Throws if not a directory
        this.state.currentDir = newPath;
    }
    cmd_pwd() { this.appendOutput(this.state.currentDir); }
    async cmd_cat(args) {
        const content = await this.api.filesystem.readFile(this._resolvePath(args[0]));
        this.appendOutput(content.content.replace(/</g, '&lt;').replace(/>/g, '&gt;'));
    }
    async cmd_mkdir(args) {
        await this.api.filesystem.createDirectory(this._resolvePath(args[0]));
        this.appendOutput(`Directory created.`);
    }
    async cmd_touch(args) {
        await this.api.filesystem.writeFile(this._resolvePath(args[0]), args.slice(1).join(' ') || '');
        this.appendOutput(`File created.`);
    }
    async cmd_rm(args) {
        await this.api.filesystem.delete(this._resolvePath(args[0]));
        this.appendOutput(`File or directory removed.`);
    }
    cmd_clear() { this.outputEl.innerHTML = ''; }
    cmd_echo(args) { this.appendOutput(args.join(' ')); }
    cmd_whoami() { this.appendOutput(this.api.user.username); }
    cmd_date() { this.appendOutput(new Date().toString()); }
    cmd_ps() {
        const processes = this.api.process.getRunningProcesses();
        let psOutput = '<table><tr><th>PID</th><th>APP_ID</th><th>TITLE</th></tr>';
        processes.forEach(p => {
            psOutput += `<tr><td>${p.id}</td><td>${p.appId}</td><td>${p.appInfo.title}</td></tr>`;
        });
        psOutput += '</table>';
        this.appendOutput(psOutput);
    }
    cmd_kill(args) {
        const pid = parseInt(args[0]);
        if (isNaN(pid)) throw new Error("Invalid PID. Must be a number.");
        this.api.process.terminate(pid);
        this.appendOutput(`<span class="success">Process ${pid} terminated.</span>`);
    }
    async cmd_start(args) {
        if (!args[0]) throw new Error("App ID is required.");
        await this.api.process.launch(args[0]);
    }
    async cmd_sysinfo() {
        const info = await this.api.system.getSystemInfo();
        let infoOutput = `IP Lab Version: ${info.version}\n`;
        infoOutput += `Debug Mode: ${info.debug_mode}\n`;
        infoOutput += `Filesystem: ${info.use_local_filesystem ? 'Local' : 'Browser Storage'}`;
        this.appendOutput(infoOutput);
    }
    cmd_arch(args) {
        if (!this.api.security.isAdmin()) {
            throw new Error("Permission denied: 'arch' command is for administrators only.");
        }
        const [subcommand, ...params] = args;
        switch (subcommand) {
            case 'export':
                this.appendOutput(`<span class="info">Exporting IP Lab version ${params[0]}... (Not yet implemented)</span>`);
                break;
            case 'generate':
                this.appendOutput(`<span class="info">Generating IP Lab version ${params[0]} from current... (Not yet implemented)</span>`);
                break;
            default:
                this.appendOutput(`Usage: arch [export|generate] [version]`);
        }
    }

    // --- Helpers ---
    appendOutput(html) {
        this.outputEl.innerHTML += `<div>${html.replace(/\n/g, '<br>')}</div>`;
        this.outputEl.scrollTop = this.outputEl.scrollHeight;
    }
    updatePrompt() {
        let displayPath = this.state.currentDir;
        const homeDir = `/users/${this.api.user.username}`;
        if (displayPath.startsWith(homeDir)) {
            displayPath = '~' + displayPath.substring(homeDir.length);
        }
        this.promptEl.textContent = `${this.api.user.username}@iplab:${displayPath}$ `;
    }
    _resolvePath(path) {
        if (!path) throw new Error("Path is required.");
        if (path.startsWith('/')) return path;
        if (path.startsWith('~')) {
            const homeDir = `/users/${this.api.user.username}`;
            return path === '~' ? homeDir : `${homeDir}/${path.substring(2)}`;
        }
        const newPath = `${this.state.currentDir}/${path}`.replace(/\/+/g, '/');
        const parts = newPath.split('/');
        const resolved = [];
        for (const part of parts) {
            if (part === '..') {
                resolved.pop();
            } else if (part !== '.' && part !== '') {
                resolved.push(part);
            }
        }
        return '/' + resolved.join('/');
    }
}

// The kernel will call this function to start the application.
export function initialize(kernelApi) {
    new TerminalApp(kernelApi);
}
