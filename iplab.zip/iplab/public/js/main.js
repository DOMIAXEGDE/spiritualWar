/**
 * IP Lab - Main Frontend JavaScript
 *
 * This file contains the client-side Kernel and all the necessary managers
 * to run the IP Lab operating system in the browser. It handles the UI,
 * process management, and all communication with the backend API.
 */

// ============================================================
// KERNEL CLASS
// ============================================================

class Kernel {
    constructor() {
        this.version = '1.0.0-genesis';
        this.state = { status: 'uninitialized', debug: true };
        this.config = {};
        this.currentUser = null;

        // Core Modules
        this.events = new EventManager(this);
        this.security = new SecurityManager(this);
        this.filesystem = new FilesystemManager(this);
        this.process = new ProcessManager(this);
        this.ui = new UIManager(this);

        this.log = this._createLogger('kernel');
        this.log.info(`IP Lab Kernel v${this.version} created.`);
    }

    /**
     * Initializes the entire OS.
     */
    async initialize() {
        this.state.status = 'initializing';
        this.log.info('Kernel initialization started.');

        try {
            // 1. Load configuration from the backend
            this.ui.updateLoadingProgress(10, 'Loading system configuration...');
            const systemInfo = await this.api('system', 'getSystemInfo');
            this.config = systemInfo;
            this.state.debug = this.config.debug_mode;
            this.log.info('System configuration loaded.');

            // 2. Validate user session
            this.ui.updateLoadingProgress(40, 'Validating session...');
            const authResult = await this.api('auth', 'validateToken');
            if (authResult.valid) {
                this.security.handleLogin(authResult);
            }

            // 3. Initialize UI and show appropriate screen
            this.ui.updateLoadingProgress(70, 'Initializing user interface...');
            this.ui.initialize();

            if (this.security.isAuthenticated()) {
                this.ui.showDesktop();
            } else {
                this.ui.showLoginScreen();
            }

            this.state.status = 'running';
            this.ui.updateLoadingProgress(100, 'System ready!');
            this.log.info('Kernel initialization complete.');
        } catch (error) {
            this.state.status = 'error';
            this.log.error('Kernel initialization failed:', error);
            this.ui.showErrorScreen('Kernel Initialization Failed', error.message);
        }
    }

    /**
     * Central API call handler for communicating with the backend.
     * @param {string} api - The API module name (e.g., 'auth', 'filesystem').
     * @param {string} method - The method to call on the module.
     * @param {object} params - The parameters for the method.
     * @returns {Promise<any>} The data from the API response.
     */
    async api(api, method, params = {}) {
        const url = `api.php?api=${api}`;
        const formData = new FormData();
        formData.append('method', method);
        formData.append('params', JSON.stringify(params));
        let response; 

        try {
            response = await fetch(url, { method: 'POST', body: formData });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || 'An unknown API error occurred.');
            }
            return result.data;
        } catch (error) {
            this.log.error(`API call to ${api}.${method} failed:`, error);
            if (response) {
                const rawText = await response.text();
                this.log.error(`Raw API response text:`, rawText);
            }
            throw error;
        }
    }

    _createLogger(component) {
        return {
            info: (message, data) => console.info(`[IP Lab:${component}] ${message}`, data || ''),
            warn: (message, data) => console.warn(`[IP Lab:${component}] ${message}`, data || ''),
            error: (message, error) => console.error(`[IP Lab:${component}] ${message}`, error || ''),
        };
    }
}

// ============================================================
// KERNEL MODULES
// ============================================================

class EventManager {
    constructor(kernel) { this.kernel = kernel; this.events = new Map(); }
    on(eventName, handler) {
        if (!this.events.has(eventName)) this.events.set(eventName, []);
        this.events.get(eventName).push(handler);
    }
    emit(eventName, data = {}) {
        if (!this.events.has(eventName)) return;
        this.events.get(eventName).forEach(handler => {
            try { handler(data); } catch (e) { this.kernel.log.error(`Event handler for ${eventName} failed`, e); }
        });
    }
}

class SecurityManager {
    constructor(kernel) { this.kernel = kernel; this.user = null; this.permissions = new Set(); }
    handleLogin(data) {
        this.user = data.user;
        this.permissions = new Set(data.permissions || []);
        this.kernel.currentUser = this.user;
    }
    handleLogout() { this.user = null; this.permissions.clear(); this.kernel.currentUser = null; }
    isAuthenticated() { return this.user !== null; }
    isAdmin() { return this.user && this.user.roles.includes('admin'); }
}

class FilesystemManager {
    constructor(kernel) { this.kernel = kernel; }
    async listDirectory(path) { return this.kernel.api('filesystem', 'listDirectory', { path }); }
    async readFile(path) { return this.kernel.api('filesystem', 'readFile', { path }); }
    async writeFile(path, content) { return this.kernel.api('filesystem', 'writeFile', { path, content }); }
    async createDirectory(path) { return this.kernel.api('filesystem', 'createDirectory', { path }); }
    async delete(path) { return this.kernel.api('filesystem', 'deleteFile', { path }); }
}

class ProcessManager {
    constructor(kernel) {
        this.kernel = kernel;
        this.processes = new Map();
        this.nextPid = 1000;
    }
    async launch(appId, params = {}) {
        this.kernel.log.info(`Attempting to launch app: ${appId}`);
        try {
            const appInfo = await this.kernel.api('apps', 'getAppInfo', { id: appId });
            if (!appInfo) throw new Error(`Application manifest for '${appId}' not found.`);

            const pid = this.nextPid++;
            const windowId = `window-${pid}`;
            const windowEl = this.kernel.ui.createWindow(windowId, appInfo.title, appInfo.icon, appInfo.window);

            const process = { id: pid, appId, appInfo, windowId, windowEl, params };
            this.processes.set(pid, process);
            
            this.kernel.ui.createTaskbarItem(windowId, appInfo.title, appInfo.icon);

            this._bootApplication(process);

            this.kernel.events.emit('process:launched', process);
            return pid;
        } catch (error) {
            this.kernel.log.error(`Failed to launch app ${appId}`, error);
            this.kernel.ui.showNotification('Launch Error', error.message, 'error');
        }
    }

    _bootApplication(process) {
        const { appInfo, windowEl, id: pid } = process;
        const contentEl = windowEl.querySelector('.window-content');
        contentEl.innerHTML = ''; // Clear any loading text

        const iframe = document.createElement('iframe');
        iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
        iframe.style.border = 'none';
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        
        contentEl.appendChild(iframe);

        const kernelApiProxy = {
            app: { id: appInfo.id, title: appInfo.title, version: appInfo.version, params: process.params },
            user: { username: this.kernel.currentUser.username, name: this.kernel.currentUser.name, roles: this.kernel.currentUser.roles },
            window: {
                getContainer: () => iframe.contentDocument.body,
                setTitle: (newTitle) => {
                    const titleEl = document.querySelector(`#${process.windowId} .window-title`);
                    if (titleEl) titleEl.textContent = newTitle;
                },
                close: () => this.terminate(pid),
            },
            filesystem: this.kernel.filesystem,
            process: {
                launch: (appId, params) => this.launch(appId, params),
                terminate: (pidToKill) => this.terminate(pidToKill),
                getRunningProcesses: () => this.getRunningProcesses()
            },
            security: {
                isAdmin: () => this.kernel.security.isAdmin()
            },
            system: {
                getSystemInfo: () => this.kernel.api('system', 'getSystemInfo')
            }
        };

        iframe.addEventListener('load', () => {
            if (!window.IPLabAPIProxies) window.IPLabAPIProxies = {};
            window.IPLabAPIProxies[pid] = kernelApiProxy;

            const script = iframe.contentDocument.createElement('script');
            script.type = 'module';
            script.innerHTML = `
                try {
                    const apiProxy = window.parent.IPLabAPIProxies[${pid}];
                    // Use a cache-busting query parameter for dynamic imports
                    const moduleUrl = './apps/${appInfo.id}/${appInfo.entry}?v=${Date.now()}';
                    const module = await import(moduleUrl);
                    if (module.initialize && typeof module.initialize === 'function') {
                        module.initialize(apiProxy);
                    } else {
                        throw new Error("Application entry point must export an 'initialize' function.");
                    }
                } catch(e) {
                    document.body.innerHTML = '<div style="padding:20px;color:#ff4d4d;"><h4>App Error</h4><p>' + e.message + '</p><pre>' + (e.stack || '') + '</pre></div>';
                    console.error('Error within sandboxed app:', e);
                }
            `;
            iframe.contentDocument.body.appendChild(script);
        });

        iframe.src = 'sandbox.html';
    }

    terminate(pid) {
        if (!this.processes.has(pid)) return;
        const process = this.processes.get(pid);
        this.kernel.ui.removeWindow(process.windowId);
        this.kernel.ui.removeTaskbarItem(process.windowId);
        this.processes.delete(pid);
        if (window.IPLabAPIProxies && window.IPLabAPIProxies[pid]) {
            delete window.IPLabAPIProxies[pid];
        }
        this.kernel.events.emit('process:terminated', process);
        this.kernel.log.info(`Terminated process ${pid} for app ${process.appId}`);
    }
    getRunningProcesses() {
        return Array.from(this.processes.values());
    }
}

class UIManager {
    constructor(kernel) {
        this.kernel = kernel;
        this.nextZIndex = 100;
    }
    initialize() {
        this.splashScreen = document.getElementById('splash-screen');
        this.loginScreen = document.getElementById('login-screen');
        this.desktop = document.getElementById('desktop');
        this.taskbar = document.getElementById('taskbar');
        
        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const form = e.target;
            const username = form.username.value;
            const password = form.password.value;
            const errorDiv = document.getElementById('login-error');
            errorDiv.textContent = '';
            try {
                const result = await this.kernel.api('auth', 'login', { username, password });
                this.kernel.security.handleLogin(result);
                this.showDesktop();
            } catch (error) {
                errorDiv.textContent = error.message;
            }
        });

        document.getElementById('start-button').addEventListener('click', () => this.toggleStartMenu());
    }

    updateLoadingProgress(progress, status) {
        document.getElementById('loading-progress').style.width = `${progress}%`;
        document.getElementById('loading-status').textContent = status;
    }

    showLoginScreen() {
        // This function is called when the kernel is ready.
        // It should hide the splash screen and show the login form.
        const onTransitionEnd = () => {
            this.splashScreen.removeEventListener('transitionend', onTransitionEnd);
            this.splashScreen.style.display = 'none'; // Fully hide it after transition
        };
        this.splashScreen.addEventListener('transitionend', onTransitionEnd);

        // Start the splash screen fade out
        this.splashScreen.classList.add('fade-out');

        // Show the login screen. It starts with opacity 0.
        this.loginScreen.style.display = 'flex';
        
        // Use requestAnimationFrame to ensure the 'display' change is painted
        // before we add the 'show' class to trigger the fade-in animation.
        requestAnimationFrame(() => {
            this.loginScreen.classList.add('show');
        });
    }

    showDesktop() {
        const onTransitionEnd = () => {
            this.loginScreen.removeEventListener('transitionend', onTransitionEnd);
            this.loginScreen.style.display = 'none';
        };
        this.loginScreen.addEventListener('transitionend', onTransitionEnd);

        // Start the login screen fade out
        this.loginScreen.classList.remove('show');
        
        // Show the desktop. It starts with opacity 0.
        this.desktop.style.display = 'flex';
        this.desktop.style.flexDirection = 'column';

        requestAnimationFrame(() => {
            this.desktop.classList.add('show');
        });

        this.renderDesktopIcons();
    }
    
    async renderDesktopIcons() {
        const container = document.getElementById('desktop-icons');
        if (!container) return;
        container.innerHTML = '';
        try {
            const apps = await this.kernel.api('apps', 'listApps');
            apps.forEach(app => {
                // As per user request, only focus on the Terminal for now.
                if (['terminal'].includes(app.id)) {
                    const iconEl = document.createElement('div');
                    iconEl.className = 'desktop-icon';
                    iconEl.innerHTML = `<div class="icon-image">${app.icon || '🚀'}</div><div class="icon-text">${app.title}</div>`;
                    iconEl.addEventListener('dblclick', () => this.kernel.process.launch(app.id));
                    container.appendChild(iconEl);
                }
            });
        } catch (error) {
            this.kernel.log.error('Failed to render desktop icons', error);
        }
    }

    toggleStartMenu() {
        const menu = document.getElementById('start-menu');
        const isVisible = menu.style.display === 'block';
        if (isVisible) {
            menu.style.display = 'none';
        } else {
            this.renderStartMenu(menu);
            menu.style.display = 'block';
        }
    }

    async renderStartMenu(menuElement) {
        menuElement.innerHTML = 'Loading apps...';
        try {
            const apps = await this.kernel.api('apps', 'listApps');
            let html = '';
            apps.forEach(app => {
                html += `<div class="menu-item" data-appid="${app.id}">${app.icon || '🚀'} ${app.title}</div>`;
            });
            html += '<div class="menu-item" data-action="logout">🚪 Logout</div>';
            menuElement.innerHTML = html;

            menuElement.querySelectorAll('.menu-item').forEach(item => {
                item.addEventListener('click', async () => {
                    const appId = item.dataset.appid;
                    const action = item.dataset.action;
                    if (appId) {
                        this.kernel.process.launch(appId);
                    } else if (action === 'logout') {
                        await this.kernel.api('auth', 'logout');
                        window.location.reload();
                    }
                    this.toggleStartMenu();
                });
            });
        } catch (error) {
            menuElement.innerHTML = '<div class="menu-item">Error loading apps</div>';
        }
    }

    createWindow(id, title, icon, options = {}) {
        const win = document.createElement('div');
        win.id = id;
        win.className = 'window';
        win.style.width = `${options.width || 600}px`;
        win.style.height = `${options.height || 400}px`;
        win.style.left = `${(window.innerWidth - (options.width || 600)) / 2 + (Math.random() * 100 - 50)}px`;
        win.style.top = `${(window.innerHeight - (options.height || 400)) / 3 + (Math.random() * 100 - 50)}px`;
        win.style.zIndex = this.nextZIndex++;
        
        win.innerHTML = `
            <div class="window-header">
                <span class="window-title">${icon || ''} ${title}</span>
                <div class="window-controls">
                    <button class="window-control" data-action="minimize">_</button>
                    <button class="window-control" data-action="maximize">□</button>
                    <button class="window-control" data-action="close">×</button>
                </div>
            </div>
            <div class="window-content"></div>
        `;
        
        document.getElementById('workspace').appendChild(win);

        const header = win.querySelector('.window-header');
        let isDragging = false, dragOffsetX, dragOffsetY;
        header.addEventListener('mousedown', e => {
            if (e.target.classList.contains('window-control')) return;
            isDragging = true;
            dragOffsetX = e.clientX - win.offsetLeft;
            dragOffsetY = e.clientY - win.offsetTop;
            win.style.zIndex = this.nextZIndex++;
        });
        document.addEventListener('mousemove', e => {
            if (!isDragging) return;
            win.style.left = `${e.clientX - dragOffsetX}px`;
            win.style.top = `${e.clientY - dragOffsetY}px`;
        });
        document.addEventListener('mouseup', () => isDragging = false);
        
        win.querySelector('[data-action="close"]').addEventListener('click', () => {
            const pid = parseInt(id.replace('window-', ''));
            this.kernel.process.terminate(pid);
        });

        return win;
    }

    removeWindow(id) {
        const win = document.getElementById(id);
        if (win) win.remove();
    }

    createTaskbarItem(windowId, title, icon) {
        const item = document.createElement('div');
        item.id = `task-${windowId}`;
        item.className = 'taskbar-item';
        item.innerHTML = `${icon || ''} ${title}`;
        document.getElementById('taskbar-items').appendChild(item);
    }

    removeTaskbarItem(windowId) {
        const item = document.getElementById(`task-${windowId}`);
        if (item) item.remove();
    }

    showNotification(title, message, type = 'info') {
        const container = document.getElementById('notification-container');
        const note = document.createElement('div');
        note.className = `notification notification-${type}`;
        note.innerHTML = `<strong>${title}</strong><p>${message}</p>`;
        container.appendChild(note);
        setTimeout(() => note.remove(), 5000);
    }

    showErrorScreen(title, message) {
        document.getElementById('splash-screen').style.display = 'none';
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('desktop').style.display = 'none';
        document.getElementById('error-title').textContent = title;
        document.getElementById('error-message').textContent = message;
        document.getElementById('error-screen').style.display = 'flex';
    }
}

// ============================================================
// OS BOOTSTRAP
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    window.IPLab = new Kernel();
    window.IPLab.initialize();
});
