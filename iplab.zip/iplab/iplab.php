<?php
/**
 * IP Lab - Main Entry Point
 * This file serves the main HTML shell for the web operating system.
 */
require_once 'bootstrap.php';
initializeSystem(); // From modules/system.php
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Lab</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <!-- CRT effects (toggled by settings) -->
    <div class="crt-overlay" id="crt-overlay"></div>
    <div class="scanline" id="scanline"></div>

    <!-- Splash Screen -->
    <div id="splash-screen" class="splash-screen">
        <div id="splash-logo">IP</div>
        <div class="loading-indicator">
            <div class="loading-bar">
                <div id="loading-progress" class="loading-progress"></div>
            </div>
            <div id="loading-status">Initializing Kernel...</div>
        </div>
    </div>
    
	<!-- Login Screen -->
	<div id="login-screen" class="login-screen">
		<div class="login-container">
			<h2 class="login-heading">IP Lab Login</h2>
			<form id="login-form" autocomplete="on">
				<div class="login-input">
                    <!-- ENHANCEMENT: Added autocomplete attribute for better browser/password manager support -->
					<input type="text" id="username" name="username" placeholder="Username" required autocomplete="username">
				</div>
				<div class="login-input">
                    <!-- ENHANCEMENT: Added autocomplete attribute for better browser/password manager support -->
					<input type="password" id="password" name="password" placeholder="Password" required autocomplete="current-password">
				</div>
				<button type="submit" class="login-button">Log In</button>
				<div id="login-error" class="login-error"></div>
                <div class="login-extra-links">
                    <a id="register-link" style="display: none;">Register as Developer</a>
                </div>
			</form>
		</div>
	</div>
    
    <!-- Desktop Environment -->
    <div id="desktop" class="desktop">
        <div id="workspace" class="workspace">
            <div id="desktop-icons" class="desktop-icons"></div>
            <!-- Windows will be created here -->
        </div>
        <div id="taskbar" class="taskbar">
            <button id="start-button" class="start-button">IP LAB</button>
            <div id="taskbar-items" class="taskbar-items"></div>
            <div id="system-tray" class="system-tray">
                <div id="clock" class="clock"></div>
            </div>
        </div>
    </div>
    
    <!-- Start Menu -->
    <div id="start-menu" class="start-menu"></div>
    
    <!-- Context Menu -->
    <div id="desktop-context-menu" class="context-menu" style="display: none;">
        <div class="context-menu-item" data-action="new-folder">New Folder</div>
        <div class="context-menu-item" data-action="new-file">New File</div>
        <div class="context-menu-separator"></div>
        <div class="context-menu-item" data-action="refresh">Refresh</div>
        <div class="context-menu-item" data-action="settings">Settings</div>
    </div>
    
    <!-- Notification Container -->
    <div id="notification-container" class="notification-container"></div>

    <!-- Error Banner -->
    <div id="error-banner" class="error-banner"></div>

    <!-- Debug Console -->
    <pre id="debug-console" class="debug-console"></pre>
    
    <!-- Error Screen -->
    <div id="error-screen" class="error-screen">
        <div class="error-container">
            <h2 id="error-title">System Error</h2>
            <p id="error-message">An error occurred.</p>
            <button id="restart-button" class="button" onclick="window.location.reload()">Restart</button>
        </div>
    </div>
	
    <script type="module" src="public/js/main.js"></script>
</body>
</html>
