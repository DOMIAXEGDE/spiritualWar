<?php
/**
 * IP Lab Sandbox Module
 *
 * This module provides a secure environment for executing untrusted code. It runs
 * code in a separate process with strict resource limits to protect the main
 * OS from errors, infinite loops, and excessive resource consumption.
 */

/**
 * Handles all incoming API requests for the sandbox module.
 * @return array The JSON response.
 */
function handleSandboxAPI(): array
{
    global $config;
    $method = $_POST['method'] ?? null;
    $params = $_POST['params'] ?? [];
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }

    // Permission check: Only admins or users with specific sandbox permissions can execute code.
    $user = getCurrentUser();
    $context = $params['context'] ?? 'default';
    $permission = 'sandbox.execute.' . ($context === 'user' ? 'user' : '*');

    if (!hasPermission($permission)) {
        return ['success' => false, 'message' => 'Access denied for sandbox execution'];
    }

    if ($method === 'execute') {
        if (isset($params['code']) && is_string($params['code'])) {
            return executeSandboxedCode($params['code'], $context, $user);
        }
    }

    return ['success' => false, 'message' => 'Invalid method or parameters for sandbox'];
}

/**
 * Executes a string of PHP code in a secure, isolated environment.
 *
 * @param string $code The PHP code to execute (without opening <?php tag).
 * @param string $context The context of the execution (e.g., 'user', 'system').
 * @param array|null $user The current user's data.
 * @return array The result of the execution, including output and errors.
 */
function executeSandboxedCode(string $code, string $context, ?array $user): array
{
    global $config;
    $memoryLimit = $config['security']['sandbox_memory_limit'];
    $timeLimit = $config['security']['sandbox_time_limit'];

    // Create a temporary file for the user's code.
    $userCodeFile = tempnam($config['filesystem']['temp_dir'], 'user_code_');
    file_put_contents($userCodeFile, "<?php\n" . $code);

    // Create a wrapper script to execute the user's code safely.
    $wrapperTemplate = <<<'EOT'
<?php
ini_set('memory_limit', '{{MEMORY_LIMIT}}');
set_time_limit({{TIME_LIMIT}});
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();

// Define a limited, safe context for the sandboxed code.
$context = '{{CONTEXT}}';
$user = {{USER_JSON}};

try {
    include '{{USER_CODE_FILE}}';
} catch (Throwable $e) {
    echo "Error: " . $e->getMessage() . " on line " . $e->getLine();
}

$output = ob_get_clean();
echo json_encode(['output' => $output]);
EOT;

    $wrapperCode = str_replace(
        ['{{MEMORY_LIMIT}}', '{{TIME_LIMIT}}', '{{CONTEXT}}', '{{USER_JSON}}', '{{USER_CODE_FILE}}'],
        [$memoryLimit, $timeLimit, $context, json_encode($user), $userCodeFile],
        $wrapperTemplate
    );

    $wrapperFile = tempnam($config['filesystem']['temp_dir'], 'sandbox_wrapper_');
    file_put_contents($wrapperFile, $wrapperCode);

    // Execute the wrapper script in a separate process with disabled functions for extra security.
    $descriptorspec = [ 0 => ["pipe", "r"], 1 => ["pipe", "w"], 2 => ["pipe", "w"] ];
    $disableFunctions = 'system,exec,shell_exec,passthru,proc_open,popen,curl_exec,fsockopen,file_put_contents,unlink,mkdir,rmdir';
    
    // --- FIX: Use a more robust method to build and execute the command ---
    $php_executable = PHP_BINARY; // Use the same PHP executable that is running this script.
    $command = escapeshellcmd($php_executable) .
               ' -d disable_functions=' . escapeshellarg($disableFunctions) .
               ' ' . escapeshellarg($wrapperFile);

    $process = proc_open($command, $descriptorspec, $pipes);

    if (is_resource($process)) {
        fclose($pipes[0]); // Close stdin
        $output = stream_get_contents($pipes[1]);
        $errors = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exitCode = proc_close($process);

        // Clean up temporary files.
        @unlink($wrapperFile);
        @unlink($userCodeFile);

        $result = json_decode($output, true);
        if ($result !== null) {
            return [
                'success' => true,
                'data' => [
                    'output' => $result['output'],
                    'errors' => $errors,
                    'exitCode' => $exitCode
                ]
            ];
        }

        return [
            'success' => false,
            'message' => 'Failed to parse sandbox output. The script may have timed out or exceeded memory limits.',
            'data' => ['raw' => $output, 'errors' => $errors, 'exitCode' => $exitCode]
        ];
    }

    return ['success' => false, 'message' => 'Failed to create sandbox process.'];
}
