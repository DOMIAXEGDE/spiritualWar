<?php
/**
 * IP Lab Filesystem Module
 *
 * This module handles all API requests related to file and directory
 * operations, enforcing permissions based on the user's session and managing
 * storage quotas. It is the sole gateway for filesystem interactions.
 */

/* ============================================================
 * HELPER FUNCTIONS
 * ============================================================ */

/**
 * Resolves a virtual OS path to a real server path.
 *
 * @param string $virtualPath The virtual path (e.g., /users/admin/Desktop).
 * @return string The corresponding absolute path on the server's filesystem.
 */
function resolvePath(string $virtualPath): string {
    global $config;
    
    // Normalize the path to remove trailing slashes and resolve relative parts.
    $virtualPath = '/' . trim($virtualPath, '/');
    $parts = array_filter(explode('/', $virtualPath), 'strlen');
    $absolutes = [];
    
    foreach ($parts as $part) {
        if ($part === '.') continue;
        if ($part === '..') {
            array_pop($absolutes);
        } else {
            $absolutes[] = $part;
        }
    }
    
    $normalizedPath = '/' . implode('/', $absolutes);
    
    // Map the normalized virtual path to its real directory on the server.
    if ($config['filesystem']['use_local']) {
        if (strpos($normalizedPath, '/users/') === 0) return $config['filesystem']['user_dir'] . substr($normalizedPath, 6);
        if (strpos($normalizedPath, '/apps/') === 0) return $config['filesystem']['apps_dir'] . substr($normalizedPath, 5);
        if (strpos($normalizedPath, '/system/') === 0) return $config['filesystem']['system_dir'] . substr($normalizedPath, 7);
        if (strpos($normalizedPath, '/temp/') === 0) return $config['filesystem']['temp_dir'] . substr($normalizedPath, 5);
        return $config['filesystem']['root_dir'] . $normalizedPath;
    }
    
    return $normalizedPath;
}

/**
 * Checks if the current user has permission to access a given path.
 *
 * @param string $virtualPath The virtual path being accessed.
 * @param bool $writeAccess Set to true for destructive operations (write, delete).
 * @return bool True if access is granted.
 */
function canAccessPath(string $virtualPath, bool $writeAccess = false): bool {
    $user = getCurrentUser();
    if (!$user) return false;
    if (isAdmin()) return true;

    $permissionPrefix = $writeAccess ? 'filesystem.write.' : 'filesystem.read.';
    
    if (strpos($virtualPath, '/users/' . $user['username']) === 0) {
        return hasPermission($permissionPrefix . 'user.*');
    }
    if (strpos($virtualPath, '/apps/' . $user['username']) === 0) {
        return hasPermission($permissionPrefix . 'apps.self');
    }
    
    // Allow general read access if permitted.
    if (!$writeAccess) {
        return hasPermission('filesystem.read.*');
    }

    return false;
}

/**
 * Retrieves a user's storage quota from the database.
 * @param string $username The user's username.
 * @return int The user's quota in bytes.
 */
function getUserQuota(string $username): int {
    $users = loadUserDB();
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            return $user['quota'] ?? 0;
        }
    }
    return 0;
}

/**
 * Calculates the total disk usage for a specific user.
 * @param string $username The user's username.
 * @return int The total size of the user's files in bytes.
 */
function getUserDiskUsage(string $username): int {
    global $config;
    $userDir = $config['filesystem']['user_dir'] . '/' . $username;
    if (!is_dir($userDir)) return 0;

    $totalSize = 0;
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($userDir, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $totalSize += $file->getSize();
        }
    }
    return $totalSize;
}

/* ============================================================
 * API HANDLER
 * ============================================================ */

/**
 * Handles all incoming API requests for the filesystem module.
 */
function handleFileSystemAPI(): array {
    global $config;
    $method = $_POST['method'] ?? '';
    $params = $_POST['params'] ?? [];
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }
    
    $path = $params['path'] ?? null;
    if ($path === null) {
        return ['success' => false, 'message' => 'Path parameter is missing.'];
    }

    $writeAccess = in_array($method, ['writeFile', 'deleteFile', 'createDirectory']);

    if (!canAccessPath($path, $writeAccess)) {
        return ['success' => false, 'message' => 'Access Denied'];
    }

    try {
        switch ($method) {
            case 'readFile':
                $realPath = resolvePath($path);
                if (is_file($realPath)) {
                    return ['success' => true, 'data' => [
                        'content' => file_get_contents($realPath),
                        'size' => filesize($realPath),
                        'modified' => filemtime($realPath)
                    ]];
                }
                return ['success' => false, 'message' => 'File not found'];

            case 'writeFile':
                $realPath = resolvePath($path);
                $user = getCurrentUser();
                if ($user && !isAdmin()) {
                    $quota = getUserQuota($user['username']);
                    $usageBefore = getUserDiskUsage($user['username']);
                    $existingSize = file_exists($realPath) ? filesize($realPath) : 0;
                    $newSize = strlen($params['content'] ?? '');
                    if ($usageBefore - $existingSize + $newSize > $quota) {
                        return ['success' => false, 'message' => 'User quota exceeded'];
                    }
                }
                $dir = dirname($realPath);
                if (!is_dir($dir)) mkdir($dir, 0755, true);
                if (file_put_contents($realPath, $params['content'] ?? '') !== false) {
                    return ['success' => true, 'data' => ['path' => $path, 'size' => filesize($realPath), 'modified' => filemtime($realPath)]];
                }
                return ['success' => false, 'message' => 'Failed to write file'];

            case 'deleteFile':
                $realPath = resolvePath($path);
                if (file_exists($realPath)) {
                    if (is_file($realPath)) {
                        if (unlink($realPath)) return ['success' => true];
                    } elseif (is_dir($realPath)) {
                        if (count(scandir($realPath)) <= 2) {
                            if (rmdir($realPath)) return ['success' => true];
                        } else {
                            return ['success' => false, 'message' => 'Directory is not empty'];
                        }
                    }
                }
                return ['success' => false, 'message' => 'File or directory not found'];

            case 'listDirectory':
                $realPath = resolvePath($path);
                if (is_dir($realPath)) {
                    $items = array_diff(scandir($realPath), ['.', '..']);
                    $files = []; $dirs = [];
                    foreach ($items as $item) {
                        $itemPath = $realPath . '/' . $item;
                        $itemData = ['name' => $item, 'path' => rtrim($path, '/') . '/' . $item, 'modified' => filemtime($itemPath)];
                        if (is_file($itemPath)) {
                            $itemData['type'] = 'file';
                            $itemData['size'] = filesize($itemPath);
                            $itemData['extension'] = pathinfo($item, PATHINFO_EXTENSION);
                            $files[] = $itemData;
                        } else {
                            $itemData['type'] = 'directory';
                            $dirs[] = $itemData;
                        }
                    }
                    sort($dirs); sort($files);
                    return ['success' => true, 'data' => array_merge($dirs, $files)];
                }
                return ['success' => false, 'message' => 'Directory not found'];

            case 'createDirectory':
                $realPath = resolvePath($path);
                if (!file_exists($realPath)) {
                    if (mkdir($realPath, 0755, true)) return ['success' => true];
                    return ['success' => false, 'message' => 'Failed to create directory'];
                }
                return ['success' => false, 'message' => 'Directory already exists'];

            default:
                return ['success' => false, 'message' => 'Invalid filesystem method'];
        }
    } catch (Throwable $e) {
        error_log("Filesystem Error: " . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
