<?php
/**
 * IP Lab Users Module
 *
 * This module provides all API endpoints for managing user accounts. It handles
 * listing, creating, updating, and deleting users, as well as password changes.
 * All operations are protected by administrative permissions.
 */

/**
 * Handles all incoming API requests for the users module.
 * @return array The JSON response.
 */
function handleUsersAPI(): array
{
    $method = $_POST['method'] ?? '';
    $params = $_POST['params'] ?? [];
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }

    // A user can change their own password without being an admin.
    if ($method === 'setPassword') {
        $user = getCurrentUser();
        if (isset($params['username']) && $user['username'] === $params['username']) {
            return setPassword($params);
        }
    }

    // All other methods require admin privileges.
    if (!isAdmin()) {
        return ['success' => false, 'message' => 'Access denied: Administrator privileges required.'];
    }

    try {
        switch ($method) {
            case 'listUsers':
                $users = loadUserDB();
                // Never expose password hashes via the API.
                foreach ($users as &$u) {
                    unset($u['password']);
                }
                return ['success' => true, 'data' => $users];

            case 'createUser':
                return createUser($params);

            case 'getUserDetails':
                return getUserDetails($params);

            case 'updateUser':
                return updateUser($params);

            case 'deleteUser':
                return deleteUser($params);

            case 'setPassword':
                return setPassword($params); // Admin can set any user's password

            default:
                return ['success' => false, 'message' => 'Invalid user management method.'];
        }
    } catch (Throwable $e) {
        error_log("[UsersAPI] Exception: " . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Retrieves a single user's details, excluding the password hash.
 * @param array $params Requires 'username'.
 * @return array API response.
 */
function getUserDetails(array $params): array
{
    $username = $params['username'] ?? null;
    if (!$username) {
        return ['success' => false, 'message' => 'Username is required.'];
    }

    $users = loadUserDB();
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            unset($user['password']); // Never expose the password hash.
            return ['success' => true, 'data' => $user];
        }
    }

    return ['success' => false, 'message' => 'User not found.'];
}

/**
 * Creates a new user account and their home directory.
 * @param array $params Requires 'username' and 'password'.
 * @return array API response.
 */
function createUser(array $params): array
{
    $username = $params['username'] ?? null;
    $password = $params['password'] ?? null;
    $name = $params['name'] ?? 'New User';
    $roles = $params['roles'] ?? ['user'];

    if (!$username || !$password) return ['success' => false, 'message' => 'Username and password are required.'];
    if (!is_array($roles)) return ['success' => false, 'message' => 'Roles must be an array.'];

    $users = loadUserDB();
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            return ['success' => false, 'message' => 'Username already exists.'];
        }
    }

    $users[] = [
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'roles' => $roles,
        'name' => htmlspecialchars($name),
        'quota' => 10 * 1024 * 1024, // Default 10MB
        'lastLogin' => null
    ];
    saveUserDB($users);

    // Create the user's home directory structure.
    global $config;
    $userDir = $config['filesystem']['user_dir'] . '/' . $username;
    if (!is_dir($userDir)) {
        mkdir($userDir . '/Desktop', 0755, true);
        mkdir($userDir . '/Documents', 0755, true);
    }

    return ['success' => true, 'message' => 'User created successfully.'];
}

/**
 * Updates an existing user's details (name, roles, quota).
 * @param array $params Requires 'username'.
 * @return array API response.
 */
function updateUser(array $params): array
{
    $username = $params['username'] ?? null;
    if (!$username) {
        return ['success' => false, 'message' => 'Username is required.'];
    }

    $users = loadUserDB();
    $found = false;
    foreach ($users as &$user) {
        if ($user['username'] === $username) {
            $found = true;
            if (isset($params['name'])) $user['name'] = htmlspecialchars($params['name']);
            if (isset($params['quota'])) $user['quota'] = intval($params['quota']);
            if (isset($params['roles']) && is_array($params['roles'])) {
                if ($user['username'] === 'admin' && !in_array('admin', $params['roles'])) {
                    return ['success' => false, 'message' => 'Cannot remove admin role from the primary administrator.'];
                }
                $user['roles'] = $params['roles'];
            }
            break;
        }
    }

    if ($found) {
        saveUserDB($users);
        return ['success' => true, 'message' => 'User updated successfully.'];
    }

    return ['success' => false, 'message' => 'User not found.'];
}

/**
 * Deletes a user account.
 * @param array $params Requires 'username'.
 * @return array API response.
 */
function deleteUser(array $params): array
{
    $username = $params['username'] ?? null;
    if (!$username) return ['success' => false, 'message' => 'Username is required.'];
    if ($username === 'admin') return ['success' => false, 'message' => 'Cannot delete the primary administrator account.'];

    $users = loadUserDB();
    $initialCount = count($users);
    $users = array_filter($users, fn($user) => $user['username'] !== $username);

    if (count($users) < $initialCount) {
        saveUserDB(array_values($users));
        // Note: Recursively deleting the user's directory is a destructive operation
        // and is omitted here for safety. It can be added if required.
        return ['success' => true, 'message' => 'User deleted successfully.'];
    }

    return ['success' => false, 'message' => 'User not found.'];
}

/**
 * Sets a new password for a user.
 * Can be called by an admin for any user, or by a user for themselves.
 * @param array $params Requires 'username' and 'newPassword'.
 * @return array API response.
 */
function setPassword(array $params): array
{
    $username = $params['username'] ?? null;
    $newPassword = $params['newPassword'] ?? null;
    $currentPassword = $params['currentPassword'] ?? null;

    if (!$username || !$newPassword) return ['success' => false, 'message' => 'Username and new password are required.'];
    if (strlen($newPassword) < 8) return ['success' => false, 'message' => 'New password must be at least 8 characters.'];

    $currentUser = getCurrentUser();
    $isSelfChange = $currentUser['username'] === $username;

    $users = loadUserDB();
    $found = false;
    foreach ($users as &$user) {
        if ($user['username'] === $username) {
            $found = true;
            // If a non-admin user is changing their own password, verify the current one.
            if ($isSelfChange && !isAdmin()) {
                if (!$currentPassword || !password_verify($currentPassword, $user['password'])) {
                    return ['success' => false, 'message' => 'Incorrect current password.'];
                }
            }
            // Admins can change passwords without the current one.
            $user['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
            break;
        }
    }

    if ($found) {
        saveUserDB($users);
        return ['success' => true, 'message' => 'Password updated successfully.'];
    }

    return ['success' => false, 'message' => 'User not found.'];
}
