<?php
/**
 * IP Lab Applications Module
 *
 * This module manages the application catalogue, including listing built-in and
 * installed applications, and handling the submission/approval process for
 * new developer applications.
 */

/* ============================================================
 * HELPER FUNCTIONS
 * ============================================================ */

/**
 * Loads the list of pending app submissions from its JSON file.
 * @return array A list of submission records.
 */
function loadAppSubmissions(): array {
    global $config;
    $file = $config['filesystem']['system_dir'] . '/app_submissions.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

/**
 * Saves the list of pending app submissions to its JSON file.
 * @param array $submissions The array of submissions to save.
 */
function saveAppSubmissions(array $submissions): void {
    global $config;
    $file = $config['filesystem']['system_dir'] . '/app_submissions.json';
    file_put_contents($file, json_encode($submissions, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

/**
 * Validates the structure of an application manifest.
 * @param array $data The manifest data to validate.
 * @return bool True if the manifest is valid.
 */
function validateAppManifest(array $data): bool {
    $required = ['id', 'title', 'entry'];
    foreach ($required as $key) {
        if (empty($data[$key]) || !is_string($data[$key])) return false;
    }
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $data['id'])) return false;
    if (isset($data['permissions']) && !is_array($data['permissions'])) return false;
    return true;
}

/**
 * Discovers application manifests from the filesystem.
 * @return array A list of manifest arrays from installed applications.
 */
function discoverAppManifests(): array {
    global $config;
    static $cache = null;
    if ($cache !== null) return $cache;

    $list = [];
    $appDir = $config['filesystem']['apps_dir'];
    if (!is_dir($appDir)) return [];

    foreach (new DirectoryIterator($appDir) as $dir) {
        if ($dir->isDot() || !$dir->isDir()) continue;
        $manifests = glob($dir->getPathname() . '/*.json');
        if (empty($manifests)) continue;
        
        $data = json_decode(file_get_contents($manifests[0]), true);
        $appId = $dir->getBasename();

        if (is_array($data) && validateAppManifest($data) && $data['id'] === $appId) {
            $data['_path'] = 'storage/apps/' . $appId . '/'; // Web-accessible path
            $list[] = $data;
        }
    }
    return $cache = $list;
}

/**
 * Loads a single application manifest by its ID.
 * @param string $id The ID of the application.
 * @return array|null The manifest data or null if not found.
 */
function loadAppManifest(string $id): ?array {
    global $config;
    $appDir = $config['filesystem']['apps_dir'] . "/$id";
    $manifests = glob($appDir . '/*.json');
    if (empty($manifests)) return null;

    $json = json_decode(file_get_contents($manifests[0]), true);
    return (is_array($json) && validateAppManifest($json)) ? $json : null;
}

/**
 * Defines the list of applications that are built-in to the OS.
 * @return array An associative array of built-in app manifests.
 */
function builtinApps(): array {
    // UPDATED: Streamlined the built-in apps to focus on the Terminal and core system utilities.
    return [
        'desktop' => ['id' => 'desktop', 'title' => 'Desktop', 'icon' => '🖥️', 'category' => 'System', 'entry' => 'desktopApp', 'window' => ['fullscreen' => true]],
        'terminal' => ['id' => 'terminal', 'title' => 'Terminal', 'icon' => '💻', 'category' => 'System', 'entry' => 'terminalApp', 'permissions' => ['filesystem.read.*', 'filesystem.write.*', 'process.exec', 'system.admin.*'], 'window' => ['width' => 800, 'height' => 550, 'resizable' => true]],
        'settings' => ['id' => 'settings', 'title' => 'Settings', 'icon' => '⚙️', 'category' => 'System', 'entry' => 'settingsApp', 'window' => ['width' => 600, 'height' => 500]],
        'appStore' => ['id' => 'appStore', 'title' => 'App Store', 'icon' => '🛒', 'category' => 'System', 'entry' => 'appStoreApp', 'window' => ['width' => 1000, 'height' => 700, 'resizable' => true]],
        'dev-center' => ['id' => 'dev-center', 'title' => 'Developer Center', 'icon' => '🧬', 'category' => 'Development', 'entry' => 'devCenterApp', 'permissions' => [], 'window' => ['width' => 800, 'height' => 700], 'developerOnly' => true],
    ];
}

/* ============================================================
 * API-CALLABLE FUNCTIONS
 * ============================================================ */

function listApps(): array {
    $catalogue = [];
    $user = getCurrentUser();
    $isDeveloper = $user && in_array('developer', $user['roles'] ?? []);

    foreach (builtinApps() as $appId => $app) {
        if (($app['developerOnly'] ?? false) && !$isDeveloper) continue;
        $catalogue[$appId] = $app;
    }
    
    foreach (discoverAppManifests() as $app) {
        if (($app['developerOnly'] ?? false) && !$isDeveloper) continue;
        $catalogue[$app['id']] = $app;
    }

    return array_values($catalogue);
}

function getAppInfo(array $params): ?array {
    $id = $params['id'] ?? null;
    if (!$id) return null;

    $builtInApps = builtinApps();
    if (isset($builtInApps[$id])) return $builtInApps[$id];

    $manifest = loadAppManifest($id);
    if ($manifest) {
        $manifest['_path'] = 'storage/apps/' . $id . '/';
        return $manifest;
    }

    return null;
}

function submitApp(array $params): array {
    $currentUser = getCurrentUser();
    $manifestJson = $params['manifest'] ?? '';
    $code = $params['code'] ?? '';

    if (empty($manifestJson) || empty($code)) return ['success' => false, 'message' => 'Manifest and code cannot be empty.'];
    $manifest = json_decode($manifestJson, true);
    if (!validateAppManifest($manifest)) return ['success' => false, 'message' => 'Manifest validation failed.'];

    $submissions = loadAppSubmissions();
    $submissions[] = [
        'manifest' => $manifest, 'code' => $code,
        'submitted_by' => $currentUser['username'], 'submitted_at' => date('c')
    ];
    saveAppSubmissions($submissions);

    return ['success' => true, 'message' => 'Application submitted successfully.'];
}

function approveSubmission(array $params): array {
    global $config;
    $id = $params['id'] ?? null;
    if (!$id) return ['success' => false, 'message' => 'Application ID not provided.'];

    $submissions = loadAppSubmissions();
    foreach ($submissions as $i => $sub) {
        if (($sub['manifest']['id'] ?? '') === $id) {
            $dir = $config['filesystem']['apps_dir'] . "/$id";
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            
            $scriptFilename = "$id.js";
            $manifestFilename = "$id.json";
            
            $sub['manifest']['entry'] = $scriptFilename;
            
            file_put_contents($dir . '/' . $manifestFilename, json_encode($sub['manifest'], JSON_PRETTY_PRINT));
            file_put_contents($dir . '/' . $scriptFilename, $sub['code'] ?? '');
            
            array_splice($submissions, $i, 1);
            saveAppSubmissions($submissions);
            return ['success' => true, 'message' => 'App approved'];
        }
    }
    return ['success' => false, 'message' => 'Submission not found'];
}

/* ============================================================
 * API ROUTER AND HANDLER
 * ============================================================ */

function handleAppsAPI(): array {
    $method = $_POST['method'] ?? $_GET['method'] ?? 'listApps';
    $params = $_POST['params'] ?? $_GET ?? [];
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }
    
    $response = null;
    
    try {
        switch ($method) {
            case 'listApps': $response = ['success' => true, 'data' => listApps()]; break;
            case 'getAppInfo':
                $data = getAppInfo($params);
                $response = $data ? ['success' => true, 'data' => $data] : ['success' => false, 'message' => 'App not found.'];
                break;
            case 'listSubmissions':
                if (!isAdmin()) throw new Exception('Access Denied');
                $response = ['success' => true, 'data' => loadAppSubmissions()];
                break;
            case 'submitApp':
                if (!hasPermission('app.submit')) throw new Exception('Access Denied');
                $response = submitApp($params);
                break;
            case 'approveSubmission':
                if (!isAdmin()) throw new Exception('Access Denied');
                $response = approveSubmission($params);
                break;
            default:
                $response = ['success' => false, 'message' => "Unknown method: $method"];
        }
    } catch (Throwable $e) {
        error_log("[AppsAPI] Exception: " . $e->getMessage());
        $response = ['success' => false, 'message' => $e->getMessage()];
    }

    return $response;
}
