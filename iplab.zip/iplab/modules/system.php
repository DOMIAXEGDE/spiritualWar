<?php
/**
 * IP Lab System Module
 *
 * This module provides API endpoints for general system-level operations,
 * including retrieving system information, running diagnostics, and handling
 * the initial setup of the OS environment.
 */

/* ============================================================
 * API HANDLER
 * ============================================================ */

/**
 * Handles all incoming API requests for the system module.
 * @return array The JSON response.
 */
function handleSystemAPI(): array
{
    global $config;
    $method = $_POST['method'] ?? $_GET['method'] ?? '';
    $params = $_POST['params'] ?? [];
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }

    try {
        switch ($method) {
            case 'getSystemInfo':
                return ['success' => true, 'data' => [
                    'name' => $config['system']['name'],
                    'version' => $config['system']['version'],
                    'debug_mode' => $config['system']['debug'],
                    'use_local_filesystem' => $config['filesystem']['use_local'],
                    'security'  => $config['security'] ?? [],
                ]];

            case 'logError':
                $entry = '[' . date('Y-m-d H:i:s') . "] JS Error: " . ($params['message'] ?? 'Unknown error');
                if (!empty($params['details'])) {
                    $entry .= "\n" . $params['details'];
                }
                error_log($entry);
                return ['success' => true];

            case 'runSelfTests':
                if (!isAdmin()) {
                    return ['success' => false, 'message' => 'Access denied'];
                }
                ob_start(); // Prevent any stray output from corrupting JSON
                $tests = [
                    'php_version_ok' => version_compare(PHP_VERSION, '7.4', '>='),
                    'storage_dir_writable' => is_writable($config['filesystem']['root_dir']),
                    'user_dir_writable' => is_writable($config['filesystem']['user_dir']),
                    'system_dir_writable' => is_writable($config['filesystem']['system_dir']),
                    'sessions_enabled' => session_status() === PHP_SESSION_ACTIVE,
                ];
                ob_end_clean();
                return ['success' => true, 'data' => $tests];

            default:
                return ['success' => false, 'message' => 'Invalid system method'];
        }
    } catch (Throwable $e) {
        error_log("[SystemAPI] Exception: " . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/* ============================================================
 * SYSTEM INITIALIZATION (Called from bootstrap.php)
 * ============================================================ */

/**
 * Initializes the system on first run by creating necessary files and directories.
 */
function initializeSystem(): void
{
    global $config;
    if (!$config['filesystem']['use_local']) {
        return;
    }

    $userDBFile = $config['filesystem']['system_dir'] . '/users.json';
    $appSubmissionsFile = $config['filesystem']['system_dir'] . '/app_submissions.json';

    // Create default user database if it doesn't exist.
    if (!file_exists($userDBFile)) {
        $defaultUsers = [
            [
                'username' => 'admin',
                'password' => password_hash('00EITA00', PASSWORD_DEFAULT),
                'roles' => ['admin', 'developer'],
                'name' => 'Administrator',
                'quota' => 20 * 1024 * 1024,
                'lastLogin' => null
            ],
            [
                'username' => 'guest',
                'password' => password_hash('dfcGigtm8*', PASSWORD_DEFAULT),
                'roles' => ['user'],
                'name' => 'Guest User',
                'quota' => 10 * 1024 * 1024,
                'lastLogin' => null
            ]
        ];
        file_put_contents($userDBFile, json_encode($defaultUsers, JSON_PRETTY_PRINT));
    }

    // Create empty app submissions file.
    if (!file_exists($appSubmissionsFile)) {
        file_put_contents($appSubmissionsFile, json_encode([], JSON_PRETTY_PRINT));
    }

    // Ensure user home directories exist for all users in the DB.
    $users = json_decode(file_get_contents($userDBFile), true);
    if (is_array($users)) {
        foreach ($users as $u) {
            if (empty($u['username'])) continue;
            $home = $config['filesystem']['user_dir'] . '/' . $u['username'];
            if (!is_dir($home)) mkdir($home, 0755, true);
            if (!is_dir($home . '/Desktop')) mkdir($home . '/Desktop', 0755, true);
            if (!is_dir($home . '/Documents')) mkdir($home . '/Documents', 0755, true);
        }
    }
}
