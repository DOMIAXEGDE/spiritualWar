<?php
/**
 * IP Lab Bootstrap
 *
 * This file is the first to execute. It sets up the environment, loads the
 * configuration, initializes error handling and sessions, and includes all
 * necessary kernel and module files for the OS to function.
 */

// Start output buffering to prevent header issues.
ob_start();

// Load Configuration
$config = require_once 'config.php';

// --- JSON Body Shim ---
// Automatically decodes JSON POST bodies into the $_POST superglobal.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !empty($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') === 0) {
    $raw = file_get_contents('php://input');
    if ($raw) {
        $json = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $_POST = array_merge($json, $_POST);
        }
    }
}

// --- Error & Exception Handling ---
$errorLogFile = $config['filesystem']['system_dir'] . '/error.log';
ini_set('log_errors', '1');
ini_set('error_log', $errorLogFile);

set_exception_handler(function($e) {
    error_log("Uncaught Exception: {$e->getMessage()} in {$e->getFile()}:{$e->getLine()}\n" . $e->getTraceAsString());
});

// --- Session Initialization ---
$secureCookie = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'secure' => $secureCookie,
    'httponly' => true, 'samesite' => 'Lax'
]);
session_start();

// --- Autoload Kernel & Modules ---
// Kernel components
require_once 'kernel/Kernel.php';
require_once 'kernel/EventManager.php';
require_once 'kernel/SecurityManager.php';
require_once 'kernel/FilesystemManager.php';
require_once 'kernel/ProcessManager.php';
require_once 'kernel/UIManager.php';

// API modules
require_once 'modules/auth.php';
require_once 'modules/filesystem.php';
require_once 'modules/apps.php';
require_once 'modules/users.php';
require_once 'modules/system.php';
require_once 'modules/sandbox.php';

// --- Filesystem Initialization ---
// Create required directories if they don't exist.
if ($config['filesystem']['use_local']) {
    foreach ($config['filesystem'] as $key => $dir) {
        if (str_ends_with($key, '_dir') && !is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

// --- Global Helper ---
function jsonHeader(): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
}
