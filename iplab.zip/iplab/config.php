<?php
/**
 * IP Lab Configuration File
 *
 * Defines all system-wide settings, paths, and security policies. This is the
 * central point of configuration for the entire operating system.
 */

return [
    'system' => [
        'name' => "God's Initialized Paper Lab",
        'short_name' => 'IP Lab',
        'version' => '1.0.0-genesis',
        'debug' => true,
    ],
    'security' => [
        'allow_developer_registration' => true,
        'sandbox_enabled' => true,
        'sandbox_memory_limit' => '64M',
        'sandbox_time_limit' => 5, // seconds
    ],
    'filesystem' => [
        // Set to true to use the server's filesystem, false for browser localStorage.
        'use_local' => true,
        // Define storage paths relative to the project root.
        'root_dir' => __DIR__ . '/storage',
        'user_dir' => __DIR__ . '/storage/users',
        'apps_dir' => __DIR__ . '/storage/apps',
        'system_dir' => __DIR__ . '/storage/system',
        'temp_dir' => __DIR__ . '/storage/temp',
    ],
    'ui' => [
        'theme' => 'vintage',
        'animations' => true,
        'fontSize' => 'medium',
        'language' => 'en',
    ],
];
