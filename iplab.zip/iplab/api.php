<?php
/**
 * IP Lab API Dispatcher
 *
 * This is the single, dedicated entry point for all backend API calls. It
 * routes requests to the appropriate module and method, ensuring a clean
 * and secure interface between the frontend and backend.
 */

require_once 'bootstrap.php';

jsonHeader();

$isAuthenticated = isAuthenticated();
$api = $_GET['api'] ?? null;
$method = $_POST['method'] ?? $_GET['method'] ?? null;
$response = null;

// Public endpoints that do not require authentication
$publicEndpoints = [
    'auth' => ['login', 'register', 'validateToken'],
    'system' => ['getSystemInfo', 'getLanguagePack']
];

$isPublicCall = isset($publicEndpoints[$api]) && in_array($method, $publicEndpoints[$api]);

if (!$isAuthenticated && !$isPublicCall) {
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

// Route to the appropriate handler
try {
    switch ($api) {
        case 'auth': $response = handleAuthAPI(); break;
        case 'filesystem': $response = handleFileSystemAPI(); break;
        case 'users': $response = handleUsersAPI(); break;
        case 'system': $response = handleSystemAPI(); break;
        case 'apps': $response = handleAppsAPI(); break; // MODIFIED: Capture response
        case 'sandbox': $response = handleSandboxAPI(); break;
        default:
            http_response_code(404);
            $response = ['success' => false, 'message' => 'Unknown API endpoint'];
            break;
    }
} catch (Throwable $e) {
    error_log("API Error in {$api}: " . $e->getMessage());
    http_response_code(500);
    $response = ['success' => false, 'message' => 'An internal server error occurred.'];
}

if ($response) {
    echo json_encode($response);
}

exit;
