<?php
/**
 * IP Lab Event Manager
 *
 * This kernel module provides a system-wide publish-subscribe mechanism. It allows
 * different parts of the OS to communicate with each other in a decoupled manner,
 * enhancing modularity and maintainability.
 */
final class EventManager
{
    private Kernel $kernel;
    private array $listeners = [];

    /**
     * EventManager constructor.
     * @param Kernel $kernel A reference to the main OS kernel.
     */
    public function __construct(Kernel $kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * Subscribes a handler to a specific event.
     *
     * @param string $eventName The name of the event to listen for (e.g., 'auth:login').
     * @param callable $handler The function to execute when the event is emitted.
     */
    public function on(string $eventName, callable $handler): void
    {
        if (!isset($this->listeners[$eventName])) {
            $this->listeners[$eventName] = [];
        }
        $this->listeners[$eventName][] = $handler;
    }

    /**
     * Unsubscribes a handler from a specific event.
     * If no handler is provided, all listeners for the event are removed.
     *
     * @param string $eventName The name of the event.
     * @param callable|null $handler The specific handler to remove.
     */
    public function off(string $eventName, ?callable $handler = null): void
    {
        if (!isset($this->listeners[$eventName])) {
            return;
        }

        if ($handler === null) {
            // Remove all listeners for this event.
            unset($this->listeners[$eventName]);
        } else {
            // Remove a specific listener.
            $this->listeners[$eventName] = array_filter(
                $this->listeners[$eventName],
                fn($h) => $h !== $handler
            );
            if (empty($this->listeners[$eventName])) {
                unset($this->listeners[$eventName]);
            }
        }
    }

    /**
     * Emits an event, triggering all subscribed handlers.
     *
     * @param string $eventName The name of the event to emit.
     * @param mixed|null $data Optional data to pass to the event handlers.
     */
    public function emit(string $eventName, $data = null): void
    {
        if (isset($this->listeners[$eventName])) {
            foreach ($this->listeners[$eventName] as $handler) {
                try {
                    // Call the handler with the provided data.
                    $handler($data);
                } catch (Throwable $e) {
                    // Log any errors that occur within an event handler
                    // to prevent one faulty listener from crashing the system.
                    error_log("Error in event handler for '{$eventName}': " . $e->getMessage());
                }
            }
        }
    }
}
