<?php
/**
 * IP Lab UI Manager
 *
 * This kernel module is responsible for managing the state and configuration of
 * the user interface. It handles settings such as themes, language packs, and
 * other user-specific presentational preferences, providing a consistent
 * experience across sessions.
 */
final class UIManager
{
    private Kernel $kernel;
    private array $uiConfig;

    /**
     * UIManager constructor.
     * @param Kernel $kernel A reference to the main OS kernel.
     */
    public function __construct(Kernel $kernel)
    {
        $this->kernel = $kernel;
        $this->uiConfig = $kernel->getConfig()['ui'] ?? [];
    }

    /**
     * Retrieves the current UI configuration settings.
     * This can be used during the initial page load to bootstrap the frontend
     * with the correct theme, language, etc.
     *
     * @return array The UI configuration array.
     */
    public function getUIConfig(): array
    {
        // In a more complex system, this could merge user-specific settings
        // from a database with the system defaults from config.php.
        return [
            'theme' => $_SESSION['ui_theme'] ?? $this->uiConfig['theme'] ?? 'vintage',
            'fontSize' => $_SESSION['ui_fontSize'] ?? $this->uiConfig['fontSize'] ?? 'medium',
            'animations' => $_SESSION['ui_animations'] ?? $this->uiConfig['animations'] ?? true,
            'language' => $_SESSION['ui_language'] ?? $this->uiConfig['language'] ?? 'en',
        ];
    }

    /**
     * Updates and persists a user's UI preferences in their session.
     *
     * @param array $preferences An associative array of preferences to update.
     * @return bool True on success.
     */
    public function updatePreferences(array $preferences): bool
    {
        /** @var SecurityManager $security */
        $security = $this->kernel->getModule('security');
        if (!$security->isAuthenticated()) {
            return false; // Cannot save preferences for a non-authenticated user.
        }

        if (isset($preferences['theme'])) {
            $_SESSION['ui_theme'] = $preferences['theme'];
        }
        if (isset($preferences['fontSize'])) {
            $_SESSION['ui_fontSize'] = $preferences['fontSize'];
        }
        if (isset($preferences['animations'])) {
            $_SESSION['ui_animations'] = (bool)$preferences['animations'];
        }
        if (isset($preferences['language'])) {
            $_SESSION['ui_language'] = $preferences['language'];
        }

        return true;
    }

    /**
     * Loads a language pack from the filesystem.
     *
     * @param string $code The language code (e.g., 'en', 'de').
     * @return array The associative array of translated strings.
     */
    public function loadLanguagePack(string $code): array
    {
        $config = $this->kernel->getConfig();
        $languageDir = $config['filesystem']['system_dir'] . '/lang';
        if (!is_dir($languageDir)) {
            mkdir($languageDir, 0755, true);
        }

        $file = "{$languageDir}/lang_{$code}.json";

        if (!file_exists($file)) {
            // If the requested language pack doesn't exist, fall back to English.
            // If the English pack also doesn't exist, create a default one.
            if ($code === 'en') {
                $defaultLang = [
                    'login_heading' => 'IP Lab Login',
                    'username' => 'Username',
                    'password' => 'Password',
                    'login_button' => 'Log In',
                ];
                file_put_contents($file, json_encode($defaultLang, JSON_PRETTY_PRINT));
                return $defaultLang;
            }
            return $this->loadLanguagePack('en'); // Fallback
        }

        $json = json_decode(file_get_contents($file), true);
        return is_array($json) ? $json : [];
    }
}
