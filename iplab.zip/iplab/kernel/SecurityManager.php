<?php
/**
 * IP Lab Security Manager
 *
 * This kernel module is the central authority for user authentication, session
 * state, and permission enforcement. It is responsible for determining what
 * actions the currently logged-in user is allowed to perform.
 */
final class SecurityManager
{
    private Kernel $kernel;
    private ?array $currentUser = null;
    private array $permissions = [];

    /**
     * SecurityManager constructor.
     * @param Kernel $kernel A reference to the main OS kernel.
     */
    public function __construct(Kernel $kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * Handles the state change after a successful user login.
     * This method is typically called by an event listener subscribed to 'auth:login'.
     *
     * @param array $loginData Data from the auth module, including 'user' and 'permissions'.
     */
    public function handleLogin(array $loginData): void
    {
        $this->currentUser = $loginData['user'] ?? null;
        $this->permissions = $loginData['permissions'] ?? [];
        error_log("Security context established for user: " . ($this->currentUser['username'] ?? 'N/A'));
    }

    /**
     * Handles the state change after a user logout.
     * This clears all session-specific security data.
     */
    public function handleLogout(): void
    {
        $username = $this->currentUser['username'] ?? 'Unknown';
        $this->currentUser = null;
        $this->permissions = [];
        error_log("Security context cleared for user: {$username}");
    }

    /**
     * Retrieves the currently authenticated user's data.
     * @return array|null The user's data array or null if not authenticated.
     */
    public function getCurrentUser(): ?array
    {
        return $this->currentUser;
    }

    /**
     * Checks if a user is currently authenticated.
     * @return bool True if a user is logged in.
     */
    public function isAuthenticated(): bool
    {
        return $this->currentUser !== null;
    }

    /**
     * Checks if the current user has the 'admin' role.
     * @return bool True if the user is an administrator.
     */
    public function isAdmin(): bool
    {
        return $this->currentUser && in_array('admin', $this->currentUser['roles'] ?? [], true);
    }

    /**
     * Checks if the current user has a specific permission. This is the central
     * permission-checking function for the entire OS.
     *
     * @param string $permission The permission string to check (e.g., 'filesystem.write.user').
     * @return bool True if the user has the permission.
     */
    public function hasPermission(string $permission): bool
    {
        if (!$this->isAuthenticated()) {
            return false;
        }

        // Admins have all permissions implicitly.
        if ($this->isAdmin()) {
            return true;
        }

        // Check for a direct permission match.
        if (in_array($permission, $this->permissions, true)) {
            return true;
        }

        // Check for wildcard permissions (e.g., 'filesystem.write.*' grants 'filesystem.write.user').
        $parts = explode('.', $permission);
        while (count($parts) > 1) {
            array_pop($parts);
            $wildcard = implode('.', $parts) . '.*';
            if (in_array($wildcard, $this->permissions, true)) {
                return true;
            }
        }

        return false;
    }
}
