<?php
/**
 * IP Lab Filesystem Manager
 *
 * This kernel module provides a comprehensive and secure API for interacting with
 * the operating system's virtual filesystem. It handles path resolution,
 * permission enforcement, and user quota management for all file operations.
 */
final class FilesystemManager
{
    private Kernel $kernel;
    private array $config;

    /**
     * FilesystemManager constructor.
     * @param Kernel $kernel A reference to the main OS kernel.
     */
    public function __construct(Kernel $kernel)
    {
        $this->kernel = $kernel;
        $this->config = $kernel->getConfig()['filesystem'];
    }

    /**
     * Lists the contents of a directory.
     * @param string $virtualPath The virtual path of the directory.
     * @return array A list of file and directory entries.
     * @throws Exception If access is denied or the path is not a directory.
     */
    public function listDirectory(string $virtualPath): array
    {
        if (!$this->canAccessPath($virtualPath, false)) {
            throw new Exception("Access Denied to path: {$virtualPath}");
        }

        $realPath = $this->resolvePath($virtualPath);
        if (!is_dir($realPath)) {
            throw new Exception("Directory not found: {$virtualPath}");
        }

        $items = array_diff(scandir($realPath), ['.', '..']);
        $files = [];
        $dirs = [];

        foreach ($items as $item) {
            $itemPath = $realPath . '/' . $item;
            $itemData = [
                'name' => $item,
                'path' => rtrim($virtualPath, '/') . '/' . $item,
                'modified' => filemtime($itemPath)
            ];
            if (is_file($itemPath)) {
                $itemData['type'] = 'file';
                $itemData['size'] = filesize($itemPath);
                $itemData['extension'] = pathinfo($item, PATHINFO_EXTENSION);
                $files[] = $itemData;
            } else {
                $itemData['type'] = 'directory';
                $dirs[] = $itemData;
            }
        }

        // Sort directories first, then files, alphabetically.
        usort($dirs, fn($a, $b) => strcmp($a['name'], $b['name']));
        usort($files, fn($a, $b) => strcmp($a['name'], $b['name']));

        return array_merge($dirs, $files);
    }

    /**
     * Reads the content of a file.
     * @param string $virtualPath The virtual path of the file.
     * @return string The content of the file.
     * @throws Exception If access is denied or the file is not found.
     */
    public function readFile(string $virtualPath): string
    {
        if (!$this->canAccessPath($virtualPath, false)) {
            throw new Exception("Access Denied to path: {$virtualPath}");
        }

        $realPath = $this->resolvePath($virtualPath);
        if (!is_file($realPath)) {
            throw new Exception("File not found: {$virtualPath}");
        }

        return file_get_contents($realPath);
    }

    /**
     * Writes content to a file, creating it if it doesn't exist.
     * @param string $virtualPath The virtual path of the file.
     * @param string $content The content to write.
     * @return bool True on success.
     * @throws Exception If access is denied, quota is exceeded, or write fails.
     */
    public function writeFile(string $virtualPath, string $content): bool
    {
        if (!$this->canAccessPath($virtualPath, true)) {
            throw new Exception("Write Access Denied to path: {$virtualPath}");
        }

        $realPath = $this->resolvePath($virtualPath);
        $this->checkQuota($realPath, strlen($content));

        $dir = dirname($realPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        if (file_put_contents($realPath, $content) === false) {
            throw new Exception("Failed to write to file: {$virtualPath}");
        }

        return true;
    }

    /**
     * Creates a new directory.
     * @param string $virtualPath The virtual path of the new directory.
     * @return bool True on success.
     * @throws Exception If access is denied or the directory already exists.
     */
    public function createDirectory(string $virtualPath): bool
    {
        if (!$this->canAccessPath($virtualPath, true)) {
            throw new Exception("Write Access Denied to path: {$virtualPath}");
        }

        $realPath = $this->resolvePath($virtualPath);
        if (file_exists($realPath)) {
            throw new Exception("Directory or file already exists: {$virtualPath}");
        }

        if (!mkdir($realPath, 0755, true)) {
            throw new Exception("Failed to create directory: {$virtualPath}");
        }

        return true;
    }

    /**
     * Deletes a file or an empty directory.
     * @param string $virtualPath The virtual path to delete.
     * @return bool True on success.
     * @throws Exception If access is denied, path not found, or directory is not empty.
     */
    public function delete(string $virtualPath): bool
    {
        if (!$this->canAccessPath($virtualPath, true)) {
            throw new Exception("Delete Access Denied to path: {$virtualPath}");
        }

        $realPath = $this->resolvePath($virtualPath);
        if (!file_exists($realPath)) {
            throw new Exception("File or directory not found: {$virtualPath}");
        }

        if (is_file($realPath)) {
            if (!unlink($realPath)) {
                throw new Exception("Failed to delete file: {$virtualPath}");
            }
        } elseif (is_dir($realPath)) {
            if (count(scandir($realPath)) > 2) {
                throw new Exception("Directory is not empty: {$virtualPath}");
            }
            if (!rmdir($realPath)) {
                throw new Exception("Failed to delete directory: {$virtualPath}");
            }
        }

        return true;
    }

    /**
     * Resolves a virtual OS path to a real server path.
     * @param string $virtualPath The virtual path (e.g., /users/admin/Desktop).
     * @return string The corresponding absolute path on the server's filesystem.
     */
    private function resolvePath(string $virtualPath): string
    {
        // Normalize to remove '..' and '.' segments.
        $parts = explode('/', $virtualPath);
        $absolutes = [];
        foreach ($parts as $part) {
            if ($part === '' || $part === '.') continue;
            if ($part === '..') {
                array_pop($absolutes);
            } else {
                $absolutes[] = $part;
            }
        }
        $normalizedPath = '/' . implode('/', $absolutes);

        // Map virtual root directories to physical storage locations.
        if (strpos($normalizedPath, '/users/') === 0) return $this->config['user_dir'] . substr($normalizedPath, 6);
        if (strpos($normalizedPath, '/apps/') === 0) return $this->config['apps_dir'] . substr($normalizedPath, 5);
        if (strpos($normalizedPath, '/system/') === 0) return $this->config['system_dir'] . substr($normalizedPath, 7);
        if (strpos($normalizedPath, '/temp/') === 0) return $this->config['temp_dir'] . substr($normalizedPath, 5);
        
        // Fallback for root-level items.
        return $this->config['root_dir'] . $normalizedPath;
    }

    /**
     * Checks if the current user has permission to access a given path.
     * @param string $virtualPath The virtual path being accessed.
     * @param bool $writeAccess True if the operation is destructive (write, delete).
     * @return bool True if access is granted.
     */
    private function canAccessPath(string $virtualPath, bool $writeAccess): bool
    {
        /** @var SecurityManager $security */
        $security = $this->kernel->getModule('security');
        $user = $security->getCurrentUser();

        if (!$user) return false;
        if ($security->isAdmin()) return true;

        $permission = $writeAccess ? 'filesystem.write.' : 'filesystem.read.';

        if (strpos($virtualPath, '/users/' . $user['username']) === 0) {
            return $security->hasPermission($permission . 'user.*');
        }
        if (strpos($virtualPath, '/apps/' . $user['username']) === 0) {
            return $security->hasPermission($permission . 'apps.self');
        }
        
        // General read access check for other areas.
        if (!$writeAccess) {
            return $security->hasPermission($permission . '*');
        }

        return false;
    }

    /**
     * Checks if a write operation would exceed the user's quota.
     * @param string $realPath The real path of the file being written.
     * @param int $newSize The size of the new content.
     * @throws Exception if the quota is exceeded.
     */
    private function checkQuota(string $realPath, int $newSize): void
    {
        /** @var SecurityManager $security */
        $security = $this->kernel->getModule('security');
        $user = $security->getCurrentUser();

        if (!$user || $security->isAdmin()) {
            return; // No quota for admins or guests.
        }

        $quota = $user['quota'] ?? 0;
        $usageBefore = $this->getUserDiskUsage($user['username']);
        $existingSize = file_exists($realPath) ? filesize($realPath) : 0;

        if (($usageBefore - $existingSize + $newSize) > $quota) {
            throw new Exception('User storage quota exceeded.');
        }
    }

    /**
     * Calculates the total disk usage for a specific user.
     * @param string $username The user's username.
     * @return int The total size of the user's files in bytes.
     */
    private function getUserDiskUsage(string $username): int
    {
        $userDir = $this->config['user_dir'] . '/' . $username;
        if (!is_dir($userDir)) return 0;

        $totalSize = 0;
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($userDir, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $totalSize += $file->getSize();
            }
        }
        return $totalSize;
    }
}
