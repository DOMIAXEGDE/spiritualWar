<?php
/**
 * IP Lab Process Manager
 *
 * This kernel module is responsible for creating, managing, and terminating
 * application processes. It acts as the central authority for all running
 * applications within the operating system, assigning unique process IDs (PIDs)
 * and tracking their state.
 */
final class ProcessManager
{
    private Kernel $kernel;
    private array $processes = [];
    private int $nextPid = 1000;

    /**
     * ProcessManager constructor.
     * @param Kernel $kernel A reference to the main OS kernel.
     */
    public function __construct(Kernel $kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * Creates a new process for an application.
     *
     * @param string $appId The unique ID of the application to launch.
     * @param array $appInfo The application's manifest data.
     * @param array $params Optional parameters to pass to the application on launch.
     * @return array The newly created process object.
     * @throws Exception If the user lacks permission to launch the app.
     */
    public function createProcess(string $appId, array $appInfo, array $params = []): array
    {
        /** @var SecurityManager $security */
        $security = $this->kernel->getModule('security');
        
        // Enforce launch permissions.
        if (!$security->hasPermission('app.launch.' . $appId)) {
            // Check for wildcard permission as a fallback.
            if (!$security->hasPermission('app.launch.*')) {
                throw new Exception("Permission denied: Cannot launch application '{$appId}'.");
            }
        }

        $pid = $this->nextPid++;

        $process = [
            'id' => $pid,
            'appId' => $appId,
            'appInfo' => $appInfo,
            'startTime' => microtime(true),
            'status' => 'running',
            'params' => $params,
        ];

        $this->processes[$pid] = $process;

        /** @var EventManager $events */
        $events = $this->kernel->getModule('events');
        $events->emit('process:created', $process);

        error_log("Created process {$pid} for application '{$appId}'.");

        return $process;
    }

    /**
     * Terminates a running process.
     *
     * @param int $pid The ID of the process to terminate.
     * @return bool True on success.
     * @throws Exception If the process is not found.
     */
    public function terminateProcess(int $pid): bool
    {
        if (!isset($this->processes[$pid])) {
            throw new Exception("Process with ID {$pid} not found.");
        }

        $process = $this->processes[$pid];
        unset($this->processes[$pid]);

        /** @var EventManager $events */
        $events = $this->kernel->getModule('events');
        $events->emit('process:terminated', $process);

        error_log("Terminated process {$pid} for application '{$process['appId']}'.");

        return true;
    }

    /**
     * Retrieves a process by its ID.
     *
     * @param int $pid The process ID.
     * @return array|null The process data or null if not found.
     */
    public function getProcessById(int $pid): ?array
    {
        return $this->processes[$pid] ?? null;
    }

    /**
     * Retrieves a list of all currently running processes.
     *
     * @return array A list of process objects.
     */
    public function getRunningProcesses(): array
    {
        return array_values($this->processes);
    }
}
