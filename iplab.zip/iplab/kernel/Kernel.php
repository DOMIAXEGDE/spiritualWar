<?php
/**
 * IP Lab Kernel
 *
 * This is the core class of the IP Lab operating system. It orchestrates the
 * entire boot process, manages core modules (like security and filesystem),
 * handles the application lifecycle, and serves as the central hub for all
 * system operations.
 */
final class Kernel
{
    private static ?Kernel $instance = null;
    private array $config;
    private array $modules = [];
    private array $services = [];

    /**
     * Kernel constructor. Made private to enforce singleton pattern.
     */
    private function __construct()
    {
        // The bootstrap file has already loaded the config.
        global $config;
        $this->config = $config;
    }

    /**
     * Get the single instance of the Kernel.
     * @return Kernel
     */
    public static function getInstance(): Kernel
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initializes the kernel and all core system modules. This is the main
     * entry point for starting the OS on the backend.
     */
    public function initialize(): void
    {
        // Initialize core modules in the correct dependency order.
        $this->modules['security'] = new SecurityManager($this);
        $this->modules['filesystem'] = new FilesystemManager($this);
        $this->modules['process'] = new ProcessManager($this);
        $this->modules['ui'] = new UIManager($this);
        $this->modules['events'] = new EventManager($this);

        // Perform initial system setup (e.g., creating default user DB).
        $this->runInitialSetup();
    }

    /**
     * Retrieves a loaded module by its name.
     * @param string $name The name of the module (e.g., 'security').
     * @return mixed The module instance.
     * @throws Exception if the module is not found.
     */
    public function getModule(string $name)
    {
        if (!isset($this->modules[$name])) {
            throw new Exception("Module '{$name}' not found.");
        }
        return $this->modules[$name];
    }

    /**
     * Retrieves the system configuration array.
     * @return array
     */
    public function getConfig(): array
    {
        return $this->config;
    }

    /**
     * Performs the initial setup for the OS, creating necessary system files
     * and directories if they don't already exist. This is a direct evolution
     * of the `initializeSystem` function from the prototype.
     */
    private function runInitialSetup(): void
    {
        if (!$this->config['filesystem']['use_local']) {
            return; // Skip if not using local filesystem.
        }

        $userDBFile = $this->config['filesystem']['system_dir'] . '/users.json';
        $appSubmissionsFile = $this->config['filesystem']['system_dir'] . '/app_submissions.json';

        // Create default user database if it doesn't exist.
        if (!file_exists($userDBFile)) {
            $defaultUsers = [
                [
                    'username' => 'admin',
                    'password' => password_hash('00EITA00', PASSWORD_DEFAULT),
                    'roles' => ['admin', 'developer'],
                    'name' => 'Administrator',
                    'quota' => 20 * 1024 * 1024,
                    'lastLogin' => null
                ],
                [
                    'username' => 'guest',
                    'password' => password_hash('dfcGigtm8*', PASSWORD_DEFAULT),
                    'roles' => ['user'],
                    'name' => 'Guest User',
                    'quota' => 10 * 1024 * 1024,
                    'lastLogin' => null
                ]
            ];
            file_put_contents($userDBFile, json_encode($defaultUsers, JSON_PRETTY_PRINT));
        }

        // Create empty app submissions file.
        if (!file_exists($appSubmissionsFile)) {
            file_put_contents($appSubmissionsFile, json_encode([], JSON_PRETTY_PRINT));
        }

        // Ensure user home directories exist.
        $users = json_decode(file_get_contents($userDBFile), true);
        foreach ($users as $user) {
            $home = $this->config['filesystem']['user_dir'] . '/' . $user['username'];
            if (!is_dir($home)) mkdir($home, 0755, true);
            if (!is_dir($home . '/Desktop')) mkdir($home . '/Desktop', 0755, true);
            if (!is_dir($home . '/Documents')) mkdir($home . '/Documents', 0755, true);
        }
    }

    // Prevent cloning and unserialization to preserve the singleton pattern.
    private function __clone() {}
    public function __wakeup() {
        throw new Exception("Cannot unserialize a singleton.");
    }
}
