<?php
/**
 * Genesis Operating System (GOS)
 * System Module
 */

/* ============================================================
 *  SYSTEM MODULE
 * ============================================================ */

/**
 * Handle system API requests
 */
function handleSystemAPI() {
    global $config;
    $method = $_POST['method'] ?? '';
    $params = $_POST['params'] ?? [];

    // Parse params if it's a JSON string
    if (is_string($params)) {
        $params = json_decode($params, true) ?? [];
    }
    
    switch ($method) {
        case 'getSystemInfo':
            return [
                'success' => true,
                'data' => [
                    'name' => $config['system']['name'],
                    'version' => $config['system']['version'],
                    'build' => $config['system']['build'],
                    'php_version' => PHP_VERSION,
                    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                    'debug_mode' => $config['system']['debug'],
                    'uptime' => time() - $_SERVER['REQUEST_TIME_FLOAT'],
                    'use_local_filesystem' => $config['filesystem']['use_local']
                ]
            ];
            
        case 'updateConfig':
            // Only admins can update config
            if (!isAdmin()) {
                return ['success' => false, 'message' => 'Access denied'];
            }
            
            if (isset($params['key']) && isset($params['value'])) {
                $key = $params['key'];
                $value = $params['value'];
                
                // Update config (in a real system, would save to a file/database)
                $keys = explode('.', $key);
                $ref = &$config;
                
                foreach ($keys as $k) {
                    if (!isset($ref[$k])) {
                        return ['success' => false, 'message' => 'Invalid config key'];
                    }
                    $ref = &$ref[$k];
                }
                
                $ref = $value;
                
                return ['success' => true, 'message' => 'Configuration updated'];
            }
            break;

        case 'logError':
            global $errorLogFile;
            if (isset($params['message'])) {
                $details = $params['details'] ?? '';
                $entry = '['.date('Y-m-d H:i:s')."] JS {$params['message']}";
                if ($details) { $entry .= "\n$details"; }
                file_put_contents($errorLogFile, $entry."\n", FILE_APPEND);
                return ['success' => true];
            }
            break;

        case 'getLanguagePack':
            $lang = $params['lang'] ?? ($config['ui']['language'] ?? 'en');
            $pack = loadLanguagePack($lang);
            if (empty($pack) && $lang !== 'en') {
                $pack = loadLanguagePack('en');
            }
            return ['success' => true, 'data' => $pack];

		case 'runSelfTests':
			if (!isAdmin()) {
				return ['success' => false, 'message' => 'Access denied'];
			}

			// This captures any stray output to prevent corrupting the JSON response.
			ob_start();

			$tests = [];
			$tests['php_version_ok'] = version_compare(PHP_VERSION, '7.4', '>=');
			$tests['user_dir_writable'] = is_writable($config['filesystem']['user_dir']);
			$tests['error_log_writable'] = is_writable($config['filesystem']['system_dir'] . '/error.log') || is_writable($config['filesystem']['system_dir']);
			$tests['sessions_enabled'] = session_status() === PHP_SESSION_ACTIVE;

			// Clean the buffer before returning the result.
			ob_end_clean();

			return ['success' => true, 'data' => $tests];
    }
    
    return ['success' => false, 'message' => 'Invalid method or parameters'];
}

/* ============================================================
 *  SYSTEM INITIALIZATION
 * ============================================================ */
// In system.php
function initializeSystem() {
    global $config; // Only need config

    if ($config['filesystem']['use_local']) {
        // Get all paths from the config array
        $readmePath = $config['filesystem']['root_dir'] . '/README.txt';
        $userDBFile = $config['filesystem']['system_dir'] . '/users.json';
        $appSubmissionsFile = $config['filesystem']['system_dir'] . '/app_submissions.json';
        $errorLogFile = $config['filesystem']['system_dir'] . '/error.log';
        $langFile = $config['filesystem']['system_dir'] . '/lang_en.json';
		
        if (!file_exists($readmePath)) {
            $readme = <<<TXT
Welcome to Genesis OS


This is a self-contained web-based operating system that provides:
- A desktop interface with window management
- Mathematical sandbox for calculations and visualizations
- File management capabilities
- Terminal with command execution
- Application installation system

To get started, log in with one of these demo accounts:
- admin / 00EITA00 (Administrator)
- guest / dfcGigtm8* (Regular user)

Enjoy exploring Genesis OS!
TXT;
            file_put_contents($readmePath, $readme);
        }

        // Create default user database if missing
        if (!file_exists($userDBFile)) {
			// system.php -> initializeSystem()

			$defaultUsers = [
				[
					'username' => 'admin',
					'password' => password_hash('00EITA00', PASSWORD_DEFAULT),
					'roles' => ['admin', 'developer'], // <-- CHANGED: Now 'roles' array
					'name' => 'Administrator',
					'quota' => 20 * 1024 * 1024,
					'lastLogin' => null
				],
				[
					'username' => 'guest',
					'password' => password_hash('dfcGigtm8*', PASSWORD_DEFAULT),
					'roles' => ['user'], // <-- CHANGED: Now 'roles' array for consistency
					'name' => 'Guest User',
					'quota' => 10 * 1024 * 1024,
					'lastLogin' => null
				]
			];
            file_put_contents($userDBFile, json_encode($defaultUsers, JSON_PRETTY_PRINT));
        }

        // Create empty submissions file if missing
        if (!file_exists($appSubmissionsFile)) {
            file_put_contents($appSubmissionsFile, json_encode([], JSON_PRETTY_PRINT));
        }

        // Ensure error log file exists
        global $errorLogFile, $languageDir;
        if (!file_exists($errorLogFile)) {
            file_put_contents($errorLogFile, "");
        }

        // Ensure default language pack exists
        $langFile = $languageDir . '/lang_en.json';
        if (!file_exists($langFile)) {
            $defaultLang = [
                'login_heading' => 'Genesis OS',
                'username' => 'Username',
                'password' => 'Password',
                'login_button' => 'Log In',
                'login_missing' => 'Please enter both username and password'
            ];
            file_put_contents($langFile, json_encode($defaultLang, JSON_PRETTY_PRINT));
        }

		// system.php -> initializeSystem()

		// ... inside the function
		// Ensure home directories and subdirectories exist
		$users = loadUserDB();
		foreach ($users as $u) {
			$home = $config['filesystem']['user_dir'] . '/' . $u['username'];
			$desktop = $home . '/Desktop';
			$documents = $home . '/Documents';

			// Check and create each directory individually for consistency
			if (!is_dir($home)) {
				mkdir($home, 0755, true);
			}
			if (!is_dir($desktop)) {
				mkdir($desktop, 0755, true);
			}
			if (!is_dir($documents)) {
				mkdir($documents, 0755, true);
			}
		}
    }
}

/**
 * Load a language pack
 */
function loadLanguagePack(string $code): array {
    global $languageDir;
    $file = "$languageDir/lang_{$code}.json";
    if (!file_exists($file)) {
        return [];
    }
    $json = json_decode(file_get_contents($file), true);
    return is_array($json) ? $json : [];
}