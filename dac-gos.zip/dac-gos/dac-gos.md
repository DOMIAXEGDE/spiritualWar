# Prompt x1

# Prompt 1 (Google Gemini, 2.5 Pro)



```

What is the full feature-list of a fully operable (client-side and developer backend) enterprise grade web kernel that powers an enterprise grade web OS?

```



# Response 1 (Google Gemini, 2.5 Pro)



An enterprise-grade web kernel, the core of a web operating system (Web OS), provides a comprehensive suite of features that cater to both end-users (client-side) and developers (backend). This sophisticated software architecture is designed to deliver a secure, scalable, and manageable computing environment entirely through a web browser. The feature set can be broadly categorized into client-side functionalities that define the user experience and developer backend services that enable the creation and management of applications and services.



---



## **Client-Side Features**



The client-side of an enterprise-grade web OS is focused on providing a rich, intuitive, and secure user experience that mirrors a traditional desktop environment but operates within the confines of a web browser.



### **Core UI and Windowing Engine**

* **Virtual Desktop Environment:** A fully rendered graphical user interface within the browser, supporting desktop metaphors like wallpapers, icons, and a taskbar or dock.

* **Window Manager:** Enables the opening, closing, resizing, and management of multiple application windows simultaneously. This includes support for overlapping and tiled window layouts.

* **Application Launcher:** A centralized interface for users to find and launch installed web applications, similar to a "Start Menu" or "Launchpad."

* **Notification Center:** A unified system for applications to push notifications to the user, with options for user control and do-not-disturb modes.

* **Search Functionality:** A system-wide search capability that can index and search through local (in-browser) storage, applications, and potentially connected cloud storage.



### **Application and Process Management**

* **Application Runtime Environment:** A sandboxed environment for running web applications built on standard web technologies like HTML5, CSS3, and JavaScript.

* **Process Manager:** A user-facing utility to view and manage running applications and background processes, including the ability to terminate unresponsive apps.

* **Multitasking Capabilities:** The ability to run multiple applications concurrently with efficient resource allocation to ensure smooth performance.

* **Inter-App Communication:** A secure mechanism for different web applications to communicate and share data with each other, with user consent.



### **File System and Storage**

* **Virtual File System:** An abstraction layer for managing files and folders, providing a familiar hierarchical structure.

* **Local Storage Integration:** Seamless integration with browser-based storage technologies like IndexedDB for offline file access.

* **Cloud Storage Integration:** Native support for connecting and managing files from major cloud storage providers (e.g., Google Drive, OneDrive, Dropbox) as if they were local drives.

* **File and Data Synchronization:** Automatic synchronization of files and application data between the local cache and connected cloud storage.



### **Security and User Management**

* **User Authentication:** Secure login and session management, with support for multi-factor authentication (MFA) and single sign-on (SSO) integration with enterprise identity providers.

* **Access Control:** Granular permissions for applications to access system resources, user data, and hardware APIs, all managed through user-facing consent dialogues.

* **Sandboxing:** Strict isolation of application processes to prevent malicious applications from affecting the host system or other applications.

* **Data Encryption:** Encryption of all data at rest in the local storage and in transit when communicating with backend services.



### **Hardware and Peripheral Access**

* **Hardware Abstraction Layer (HAL):** A standardized way for web applications to access device hardware such as webcams, microphones, USB devices, and printers, subject to user permissions.

* **Display Management:** Support for multiple monitors and display configurations.

* **Input Device Management:** Robust handling of various input devices, including keyboards, mice, touchscreens, and styluses.



---



## **Developer Backend Features**



The developer backend provides the necessary tools, services, and infrastructure for creating, deploying, and managing applications on the web OS.



### **Core Kernel Services**

* **Kernel API:** A comprehensive and well-documented set of APIs that expose the kernel's functionalities to developers, enabling them to build powerful applications.

* **Service Architecture:** A modular architecture that allows for the independent development, deployment, and scaling of backend services.

* **Process and Thread Management:** Robust management of server-side processes and threads to ensure efficient resource utilization and application performance.

* **Memory Management:** Advanced memory management to handle large-scale applications and prevent memory leaks.



### **Application Development and Deployment**

* **Software Development Kit (SDK):** A complete SDK with libraries, code samples, and documentation to facilitate application development.

* **Application Packaging and Distribution:** A standardized format for packaging applications and a secure mechanism for distributing them to users, often through an enterprise app store.

* **Continuous Integration and Continuous Deployment (CI/CD) Pipeline:** Integrated tools to automate the building, testing, and deployment of applications.

* **Versioning and Rollback:** Support for multiple application versions and the ability to roll back to a previous version in case of issues.



### **Data and Storage Management**

* **Database as a Service (DBaaS):** Managed database services, supporting both SQL and NoSQL databases, to simplify data storage for applications.

* **File Storage Service:** A scalable and secure object storage service for applications to store and retrieve large files.

* **Data Caching Services:** In-memory data caching services to improve application performance.



### **User and Identity Management**

* **Identity and Access Management (IAM):** A centralized system for managing user identities, roles, and permissions across all applications and services.

* **Authentication as a Service:** A managed authentication service that supports various protocols like OAuth 2.0 and OpenID Connect.

* **User Group Management:** The ability to create and manage user groups with different access levels and permissions.



### **Networking and Communication**

* **API Gateway:** A centralized entry point for all API requests, providing features like request routing, rate limiting, and authentication.

* **Real-time Communication:** Support for real-time communication between the client and server using technologies like WebSockets.

* **Service Discovery:** A mechanism for services to find and communicate with each other within the backend infrastructure.



### **Security and Compliance**

* **Intrusion Detection and Prevention Systems (IDPS):** Tools to monitor for and block security threats.

* **Logging and Auditing:** A centralized logging and auditing system to track all system and application activities for security and compliance purposes.

* **Compliance Certifications:** Adherence to industry-standard security and data privacy regulations (e.g., GDPR, HIPAA, SOC 2).



### **Scalability and Reliability**

* **Load Balancing:** Automatic distribution of incoming traffic across multiple servers to ensure high availability and reliability.

* **Auto-scaling:** The ability to automatically scale resources up or down based on application load.

* **Disaster Recovery and Backup:** Robust backup and disaster recovery mechanisms to ensure business continuity.



### **Analytics and Monitoring**

* **Performance Monitoring:** Tools to monitor the performance of applications and the underlying infrastructure in real-time.

* **Log Analysis:** Advanced tools for analyzing logs to identify and troubleshoot issues.

* **Usage Analytics:** The ability to gather and analyze data on application usage to inform future development.



# Prompt 2



```

Similarly, fully detail how this complete (Web OS) kerenl feature list (Prompt 2) influences the discipline of 'language independent software development' or 'universal language software development'.

```



# Response 2 (Google Gemini, 2.5 Pro)



A fully-featured enterprise web OS kernel profoundly influences and enables **language-independent software development** by establishing a universal, standards-based abstraction layer between the underlying system and the applications running upon it. It shifts the development paradigm from platform-specific languages and toolchains to a model where services and interfaces are the primary focus, allowing any programming language to be used so long as it can communicate via web standards.



***



### **Decoupling Through Standardized Interfaces (APIs)**



The most significant influence is the enforcement of **decoupling** through a comprehensive **API-first architecture**.



* **API Gateway and Service Discovery**: The backend feature list mandates an **API Gateway** as the central nervous system for all client-server and inter-service communication. This gateway routes requests to the appropriate microservices. These services are registered with a **Service Discovery** mechanism.

    * **Influence**: This architecture makes the programming language of an individual microservice irrelevant to the rest of the system. A developer can write a user management service in **Go**, a data processing service in **Python**, and a real-time notification service in **Node.js**. As long as each service exposes a compatible API (e.g., RESTful endpoints communicating with JSON, or a GraphQL schema) and registers itself, the kernel and other services can interact with it seamlessly. The implementation detail (the language) is hidden behind the universal interface (the API).



* **Kernel API**: The developer-facing **Kernel API** for accessing system-level functions (like storage, authentication, or notifications) is, by design, language-agnostic. It is exposed via web protocols.

    * **Influence**: An application developer doesn't need to write code in the same language as the kernel itself. They simply make authenticated HTTP requests to the kernel's API endpoints from whatever language or framework they are using to build their application's backend logic. This creates a clean separation of concerns and frees the developer from platform-specific constraints.



***



### **Universal Client-Side Runtime Environment**



The client-side of the web OS is, by definition, a universal runtime environment.



* **Application Runtime and Windowing Engine**: The client-side environment executes code built on the universal trifecta of **HTML5, CSS3, and JavaScript**. The windowing engine simply renders the output of these technologies.

    * **Influence**: This creates a universal target for any development toolchain. Developers can use frameworks like **React** (JavaScript), **Angular** (TypeScript), **Svelte**, or even compile code from other languages like **Dart** (Flutter) or **C#** (Blazor) into WebAssembly. The web OS kernel doesn't care how the client-side code was generated; it only cares that the final output is standards-compliant web content. The backend service feeding data to this UI can be written in any language, as it only needs to send data (typically JSON) that the JavaScript/WebAssembly client can understand.



***



### **Abstraction of Infrastructure and Services**



The feature list includes numerous managed services that abstract away complex infrastructure, further promoting language independence.



* **Database as a Service (DBaaS) and Managed Storage**: The kernel provides access to databases and file storage through service APIs.

    * **Influence**: Developers do not need to concern themselves with installing or managing a specific database or linking a language-specific database driver directly into their application. They simply use a generic HTTP client or a provided SDK library to interact with the storage service's API. A Python script can write a file to the storage service, and a Java application can read it moments later, as both are interacting with the same universal endpoint, not with each other's language-specific code.



* **Sandboxing and Application Packaging**: Applications are deployed in sandboxed containers (conceptually similar to Docker). The packaging standard requires specifying how to run the application, not what it's made of.

    * **Influence**: This containerization is the epitome of language independence. The deployment manifest for a service might specify `node server.js` or `python app.py` or `./my-compiled-rust-binary`. The web OS kernel's deployment and orchestration system simply executes the specified command within the container, entirely agnostic to the language or binary being run. It only manages the container's lifecycle, resources, and network connections.



In summary, the feature list of an enterprise-grade web OS kernel systematically dismantles the barriers that traditionally lock developers into specific technology stacks. By enforcing communication through universal standards (HTTP, JSON, WebSockets) and providing a universal client runtime (the browser), it creates a polyglot ecosystem where the best language can be chosen for each specific task, fostering a truly **language-independent** and **universal** software development discipline.



The operating system we need to create, needs to be generic but memory-dynamic in data structures, objects and algorithms: with 'admin', 'developer', 'registered-user', 'admin-developer' roles. It needs to be constructed using the modular software architecture approach of codebase-builder.php, cidd.php, and jisc.php (see documentation in jisc.pdf and readme-msa2.pdf). Each modular file should not exceed 920 lines of code (no exceptions). So the PHP system we are building should be a kin to a PHP sandbox with session checking and authentication for a micro-modular software architectural PHP Web Operating System. Where it is both http and https, compatible with auto detection to known which to use.



- The OS will be kernel based with a graphical Desktop-like user interface

- The OS will be .json database driven

- The OS 'admin-developer' will have the highest levels of access

- The OS will be application driven



- The OS will the following (fully featured applications: by modular means) applications with role detection (for security and permission granting based on user-role):



Desktop ('admin' and 'admin-developer'), File Manager ('admin' and 'admin-developer') , Interactive Development Environment (for 'developer' and 'admin-developer'), Terminal ('admin-developer'), Settings ('admin', 'admin-developer', 'developer'), Diagnostics ('admin-developer', 'developer'), AppStore ('admin', 'admin-developer', 'developer', 'registered-user').



Where the kernel API should be so generic, memory-dynamic and extensible that the entry point PHP file (dac-gos.php) requires no edditting in the future. Hence the kernel in all its glory needs to be future proof and needs to enable the full scale building of dac-gos.php Web OS applications by the 'developer' and the 'admin' developer within the dac-gos.php Web OS itself. Where applications are submitted to the Appstore via the Interactive Development Environment by the 'developer' or the 'admin-developer' and approved by the 'admin-developer' via a secure 'admin-developer' only visible TAB in the Appstore. This dac-gos.php needs to meet the MIT standard. Where the only monetary features are for the 'registered-user' ('Low one-time fee') and the 'developer' (medium monthly subscription fee).



Hence we are building an enterprise grade Web Operating System. Where the only purpose of the money is to cover my living expenses and to continue the sustainable and efficient propulsion of the dac-gos.php Web Operating System (A life long endeavour).

Of course. Based on the comprehensive documentation and codebases you have provided, I have synthesized an architectural and implementation blueprint for **dac-gos.php**.

This plan is designed to realize your vision of an enterprise-grade, modular Web Operating System. It adheres strictly to the **Bidirectional, Compositional Software Architecture** philosophy established by `cidd.php`, `codebase-composer.php`, and `jisc.php`, and respects all specified constraints, including the 920-line limit per module and the defined user roles.

---

# Response x1

## **Architectural and Implementation Blueprint: dac-gos.php**

### **1.0 Guiding Philosophy**

[cite_start]The construction of `dac-gos.php` will be a direct embodiment of the **Bidirectional, Compositional Engineering Workflow**[cite: 3]. [cite_start]It is not a traditional software project but a database-driven engineering discipline[cite: 76]. The fundamental principles are:

* [cite_start]**The Primacy of the Definition**: The atomic unit of the entire OS, from a single UI icon to a complex kernel function, will be a "Definition"[cite: 30].
* [cite_start]**Composition over Construction**: The OS and its applications will be *assembled* from libraries of canonical definitions, not coded in monolithic files[cite: 63]. [cite_start]The `.composition.json` file is the true source code[cite: 67].
* **The Cyclical Workflow**: The system will be self-hosting. [cite_start]The built-in Interactive Development Environment (IDE) will use `cidd.php` for analysis and `codebase-composer.php` for composition, perpetuating the cycle of improvement internally[cite: 68].

### **2.0 Core Architecture**

The OS is architected around a central, future-proof kernel that orchestrates modular, composed applications within a secure, session-aware environment.

#### **2.1 The Kernel (`kernel.php`)**

The kernel will be the central, immutable brain of the OS. It is the one component designed to be edited minimally in the future. Its sole responsibilities are:

* **Bootstrapping**: Initialize the OS environment.
* **Session Management**: Handle user login, logout, and session validation on every request.
* **Security & Permissions**: Act as the central authority for checking user roles (`admin`, `admin-developer`, `developer`, `registered-user`) against every requested action.
* **API Routing**: Expose a single, secure API endpoint (`/api.php`) that routes requests to the appropriate application logic compositions.
* **Protocol Detection**: Automatically detect `http` vs `httpshttps` and enforce the appropriate scheme.

#### **2.2 The Entry Point (`dac-gos.php`)**

This file will be exceptionally lean. Its only purpose is to:
1.  Include and instantiate the `kernel.php`.
2.  Request the kernel to load the user's primary interface (e.g., the 'Desktop' composition for an authenticated user or the 'Login' composition for a guest).

#### **2.3 The Data Structure (`/dac_os_data`)**

A new root directory, `/dac_os_data`, will be created to house the OS's own source of truth, mirroring the structure of `codebase-composer.php`:

* `/dac_os_data/main/definitions/`: Contains the JSON Definition Libraries for the entire OS (e.g., `kernel_services.json`, `ui_components.json`, `vfs_logic.json`).
* `/dac_os_data/main/compositions/`: Contains the JSON Composition files that define the OS applications (e.g., `desktop.composition.json`, `file_manager.composition.json`).
* `/dac_os_data/users/`: A directory containing user-specific data, including their file systems (`/users/{username}/fs/`) and installed application preferences.

#### **2.4 Modularity and the 920-Line Limit**

This constraint is met by design. No single `.php` file will contain significant logic. Instead, they act as loaders. For example, `file_manager.php` would be a small file that simply tells the kernel: "Load and render the `file_manager.composition.json` for the current user." The complexity resides within the version-controlled, highly granular Definitions, which are assembled by the thousands to create the application.

### **3.0 Implementation Roadmap**

This project will be executed in logical, sequential phases.

#### **Phase 1: Kernel, Contracts, and Identity (Weeks 1-3)**

* **Objective**: Establish the secure foundation of the OS.
* **Tasks**:
    1.  **Develop `kernel.php`**: Implement the core session management, role-based access control (RBAC) logic, and API router.
    2.  [cite_start]**Define Core Contracts**: Using the principles from `Prompt Engineering DOCS1.md`[cite: 80], create the foundational JSON-Schema definitions for:
        * `User.json`: (username, password_hash, role, profile_data)
        * `Session.json`: (session_id, user_id, timestamp, is_valid)
        * `AppManifest.json`: (appName, version, entry_composition, required_permissions)
    3.  **Implement User Management**: Create the backend compositions for user creation, authentication, and role assignment.
    4.  **Build Login UI**: Create the first UI composition: `login.composition.json`, using simple HTML and JS definitions.

#### **Phase 2: The Desktop Shell & Window Manager (Weeks 4-6)**

* **Objective**: Create the primary graphical user interface.
* **Tasks**:
    1.  **Develop UI Definitions**: Use `jisc.php` to batch-generate foundational UI definitions (`ui_core.json`, `icons.json`).
    2.  **Compose the Window Manager**: Create compositions for `window.composition.json`, `taskbar.composition.json`, and `desktop_icon.composition.json`.
    3.  **Build the Desktop**: Assemble the final `desktop.composition.json` which will be the main interface for `admin` and `admin-developer` roles. It will orchestrate the window manager and load user icons.

#### **Phase 3: Foundational Applications (Weeks 7-10)**

* **Objective**: Build the essential utilities for OS management.
* **Tasks**:
    1.  **File Manager**:
        * **Role Access**: `admin`, `admin-developer`.
        * **Implementation**: Compose a `file_manager.composition.json` that uses a Virtual File System (VFS) API exposed by the kernel. The VFS will interact with the `/dac_os_data/users/{username}/fs/` directory. All UI elements (tree view, file grid, context menus) will be separate, reusable compositions.
    2.  **Settings**:
        * **Role Access**: `admin`, `admin-developer`, `developer`.
        * **Implementation**: Create `settings.composition.json`. It will present different child-compositions based on the user's role (e.g., an `admin` sees user management settings, while a `developer` only sees IDE settings).
    3.  **Diagnostics**:
        * **Role Access**: `admin-developer`, `developer`.
        * **Implementation**: Create `diagnostics.composition.json` to view kernel performance logs and application health.

#### **Phase 4: The Developer Ecosystem (Weeks 11-14)**

* **Objective**: Enable self-hosting and application development within the OS.
* **Tasks**:
    1.  **Interactive Development Environment (IDE)**:
        * **Role Access**: `developer`, `admin-developer`.
        * **Implementation**: This is the keystone application. It will be a composed UI that directly integrates the functionality of `cidd.php`, `codebase-composer.php`, and `jisc.php` as modular panes within the IDE window. Developers will use it to create and manage their own `definitions` and `compositions`.
    2.  **Terminal**:
        * **Role Access**: `admin-developer`.
        * **Implementation**: A `terminal.composition.json` that provides a command-line interface to the kernel's API for advanced system management.

#### **Phase 5: The App Store & Monetization (Weeks 15-16)**

* **Objective**: Launch the application ecosystem and secure project sustainability.
* **Tasks**:
    1.  **Build the App Store**:
        * **Role Access**: All roles.
        * **Implementation**: A `app_store.composition.json` that lists applications. Developers use the IDE to submit their `AppManifest.json` for review.
        * The `admin-developer` will have an exclusive "Submissions" tab within their view of the App Store composition to approve or reject new applications.
    2.  **Integrate Payments**:
        * Implement payment processing logic for the two tiers:
            * **Registered User**: Low one-time fee for basic OS access.
            * **Developer**: Monthly subscription for access to the IDE and app submission capabilities.
    3.  **Finalize Licensing**: Add the `MIT License` file to the project root and ensure all open-source components are compliant.

This blueprint provides a clear, phased, and philosophically consistent path toward building the `dac-gos.php` Web Operating System. [cite_start]By rigorously adhering to the compositional method, the result will be a system that is not only powerful but also radically reusable, self-documenting, and maintainable for the lifelong endeavor you envision[cite: 78].

# cidd.php
```php
<?php
// cidd.php - Codebase Interactive Dictionary Database v4.1
// Implements robust name-uniqueness validation when promoting definitions
// to ensure full compatibility with the finalized codebase-composer.php.

// --- CONFIGURATION ---
define('LINES_PER_PAGE', 1000);
define('CIDD_UPLOAD_DIR', __DIR__ . '/uploads');
define('CIDD_DB_FILE', __DIR__ . '/cidd_db.json');
define('COMPOSER_DATA_DIR', __DIR__ . '/composer_data'); // Integration point

// --- INITIALIZATION ---
if (!is_dir(CIDD_UPLOAD_DIR)) mkdir(CIDD_UPLOAD_DIR, 0777, true);
if (!file_exists(CIDD_DB_FILE)) file_put_contents(CIDD_DB_FILE, json_encode([]));

// --- API ROUTER ---
if (isset($_REQUEST['action'])) {
    header('Content-Type: application/json');
    $action = $_REQUEST['action'];
    $data = json_decode(file_get_contents(CIDD_DB_FILE), true);
    if (!is_array($data)) $data = [];

    switch ($action) {
        // Standard CIDD Actions
        case 'add_entry':
        case 'update_entry':
        case 'delete_entry':
            handle_cidd_crud($action, $data);
            break;
        // File Upload & Chunk Loading
        case 'get_codebase_chunk':
            handle_chunk_request();
            break;
        // Composer Integration Actions
        case 'list_composer_projects':
            echo json_encode(list_composer_projects());
            break;
        case 'list_composer_libs':
            $project = $_GET['project'] ?? '';
            echo json_encode(list_composer_definition_libs($project));
            break;
        case 'promote_to_composer':
            handle_promotion($data);
            break;
    }
    exit;
}

// --- BACKEND HANDLERS & FUNCTIONS ---

function handle_cidd_crud($action, &$data) {
    if ($action === 'add_entry') {
        $new_entry = [
            'id' => uniqid('entry_'),
            'codebase' => $_POST['codebase'],
            'selection' => $_POST['selection'],
            'selection_type' => $_POST['selection_type'],
            'start_line' => (int)$_POST['start_line'],
            'end_line' => (int)$_POST['end_line'],
            'start_char' => isset($_POST['start_char']) && $_POST['start_char'] !== '' ? (int)$_POST['start_char'] : null,
            'end_char' => isset($_POST['end_char']) && $_POST['end_char'] !== '' ? (int)$_POST['end_char'] : null,
            'definition' => $_POST['definition'],
            'context' => $_POST['context'],
            'notes' => $_POST['notes'],
            'created_at' => date('c'),
            'composer_definition_id' => null // New field for integration
        ];
        $data[] = $new_entry;
        file_put_contents(CIDD_DB_FILE, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(['status' => 'success', 'entry' => $new_entry]);
    } elseif ($action === 'update_entry') {
        $id = $_POST['id'];
        foreach ($data as &$entry) {
            if ($entry['id'] === $id) {
                $entry['definition'] = $_POST['definition'];
                $entry['context'] = $_POST['context'];
                $entry['notes'] = $_POST['notes'];
                file_put_contents(CIDD_DB_FILE, json_encode($data, JSON_PRETTY_PRINT));
                echo json_encode(['status' => 'success', 'entry' => $entry]);
                return;
            }
        }
        echo json_encode(['status' => 'error', 'message' => 'Entry not found.']);
    } elseif ($action === 'delete_entry') {
        $id = $_POST['id'];
        $data = array_filter($data, fn($entry) => $entry['id'] !== $id);
        file_put_contents(CIDD_DB_FILE, json_encode(array_values($data), JSON_PRETTY_PRINT));
        echo json_encode(['status' => 'success']);
    }
}

function handle_chunk_request() {
    $filePath = $_GET['filepath'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    
    if (empty($filePath) || !file_exists($filePath) || strpos(realpath($filePath), realpath(CIDD_UPLOAD_DIR)) !== 0) {
        echo json_encode(['error' => 'Invalid file path.']);
        exit;
    }

    $start_line = (($page - 1) * LINES_PER_PAGE) + 1;
    $end_line = $start_line + LINES_PER_PAGE - 1;
    $content = [];
    $line_number = 0;
    
    $handle = fopen($filePath, "r");
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $line_number++;
            if ($line_number >= $start_line && $line_number <= $end_line) {
                $content[] = $line;
            }
            if ($line_number > $end_line) break;
        }
        fclose($handle);
    }
    echo json_encode(['content' => $content, 'page' => $page]);
}

function handle_promotion(&$cidd_data) {
    $cidd_id = $_POST['cidd_id'];
    $project = $_POST['project'];
    $library = $_POST['library'];

    // Find the CIDD entry
    $source_entry = null;
    foreach ($cidd_data as $entry) {
        if ($entry['id'] === $cidd_id) {
            $source_entry = $entry;
            break;
        }
    }
    if (!$source_entry) {
        echo json_encode(['status' => 'error', 'message' => 'Source dictionary entry not found.']);
        return;
    }
    if (!empty($source_entry['composer_definition_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'This entry has already been promoted.']);
        return;
    }

    // Read the Composer library file to check for name collisions
    $lib_path = COMPOSER_DATA_DIR . "/$project/definitions/" . sanitize_filename($library);
    if (!file_exists($lib_path)) {
        echo json_encode(['status' => 'error', 'message' => 'Composer library not found.']);
        return;
    }
    $composer_defs = json_decode(file_get_contents($lib_path), true);
    if (!is_array($composer_defs)) $composer_defs = [];

    // COMPATIBILITY FIX: Ensure unique name for the new definition
    $base_name = sanitize_filename($source_entry['context'] . '_' . $source_entry['selection_type']);
    $final_name = $base_name;
    $counter = 2;
    while (true) {
        $name_exists = false;
        foreach ($composer_defs as $def) {
            if ($def['name'] === $final_name) {
                $name_exists = true;
                break;
            }
        }
        if (!$name_exists) {
            break;
        }
        $final_name = $base_name . '_' . $counter++;
    }

    // Prepare the new Composer definition
    $composer_def_id = 'def_' . uniqid();
    $new_def = [
        'id' => $composer_def_id,
        'name' => $final_name, // Use the unique name
        'content' => $source_entry['selection'],
        'notes' => $source_entry['notes']
    ];
    
    $composer_defs[] = $new_def;
    file_put_contents($lib_path, json_encode($composer_defs, JSON_PRETTY_PRINT));

    // Update the CIDD entry to link it
    foreach ($cidd_data as &$entry) {
        if ($entry['id'] === $cidd_id) {
            $entry['composer_definition_id'] = $composer_def_id;
            break;
        }
    }
    file_put_contents(CIDD_DB_FILE, json_encode($cidd_data, JSON_PRETTY_PRINT));

    echo json_encode(['status' => 'success', 'message' => 'Promoted to Composer definition ' . $composer_def_id]);
}

// --- Composer Integration Read Functions ---
function list_composer_projects() {
    $projects = [];
    if (!is_dir(COMPOSER_DATA_DIR)) return ['status' => 'success', 'projects' => []];
    $items = array_diff(scandir(COMPOSER_DATA_DIR), ['..', '.']);
    foreach ($items as $item) {
        if (is_dir(COMPOSER_DATA_DIR . '/' . $item)) {
            $projects[] = $item;
        }
    }
    return ['status' => 'success', 'projects' => $projects];
}

function list_composer_definition_libs($project) {
    $project = sanitize_filename($project);
    $dir_path = COMPOSER_DATA_DIR . "/$project/definitions";
    $files = [];
    if (!is_dir($dir_path)) return ['status' => 'success', 'files' => []];
    
    $items = array_diff(scandir($dir_path), ['..', '.']);
    foreach ($items as $item) {
        if (pathinfo($item, PATHINFO_EXTENSION) === 'json') {
             $files[] = $item;
        }
    }
    return ['status' => 'success', 'files' => $files];
}

function sanitize_filename($filename) {
    return preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $filename);
}

// --- PAGE LOAD LOGIC (File Upload) ---
$uploaded_file = null;
$error_message = '';
$total_lines = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['codebase_file'])) {
    if ($_FILES['codebase_file']['error'] === UPLOAD_ERR_OK) {
        $file_extension = pathinfo($_FILES['codebase_file']['name'], PATHINFO_EXTENSION);
        if (strtolower($file_extension) === 'txt') {
            $uploaded_file = CIDD_UPLOAD_DIR . '/' . basename($_FILES['codebase_file']['name']);
            if (move_uploaded_file($_FILES['codebase_file']['tmp_name'], $uploaded_file)) {
                $total_lines = 0;
                $handle = fopen($uploaded_file, "r");
                if ($handle) {
                    while (fgets($handle) !== false) $total_lines++;
                    fclose($handle);
                }
            } else {
                $error_message = 'Failed to move uploaded file.';
                $uploaded_file = null;
            }
        } else {
            $error_message = 'Only .txt files are allowed.';
        }
    } else {
        $error_message = 'Error uploading file.';
    }
}

$dictionary_data = json_decode(file_get_contents(CIDD_DB_FILE), true);
if (!is_array($dictionary_data)) $dictionary_data = [];
$is_composer_present = is_dir(COMPOSER_DATA_DIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CIDD - Codebase Interactive Dictionary</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f7f8fc; --container-bg: #ffffff; --text-color: #333333; --heading-color: #111111;
            --border-color: #e0e0e0; --primary-color: #4a90e2; --primary-hover: #357abd; --secondary-color: #6c757d;
            --secondary-hover: #5a6268; --danger-color: #e94e77; --danger-hover: #d6336c; --code-bg: #f1f3f5;
            --shadow-color: rgba(0, 0, 0, 0.08); --line-number-color: #999; --success-color: #28a745;
        }
        body { font-family: 'Inter', sans-serif; line-height: 1.6; margin: 0; background-color: var(--bg-color); color: var(--text-color); }
        .container { max-width: 1600px; margin: 20px auto; padding: 20px 40px; background-color: var(--container-bg); border-radius: 12px; box-shadow: 0 4px 12px var(--shadow-color); }
        h1, h2, h3 { color: var(--heading-color); font-weight: 700; }
        h1 { font-size: 2.25rem; } h2 { font-size: 1.75rem; margin-top: 0; } h3 { font-size: 1.25rem; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px; }
        .grid-container { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
        .panel { border: 1px solid var(--border-color); border-radius: 8px; height: 75vh; display: flex; flex-direction: column; }
        .panel-header { padding: 15px 20px; border-bottom: 1px solid var(--border-color); }
        #codebase-viewer-container { padding: 0; overflow-y: auto; flex-grow: 1; font-family: "SF Mono", monospace; font-size: 14px; }
        .code-line { display: flex; white-space: pre-wrap; }
        .line-number { text-align: right; padding: 0 10px; color: var(--line-number-color); background-color: var(--code-bg); user-select: none; min-width: 50px; box-sizing: border-box; }
        .line-content { flex-grow: 1; padding-left: 10px; }
        #dictionary-manager { padding: 20px; overflow-y: auto; flex-grow: 1; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: 500; margin-bottom: 8px; }
        input[type="text"], input[type="file"], textarea, select { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 6px; box-sizing: border-box; font-family: 'Inter', sans-serif; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        input[type="text"]:focus, textarea:focus, select:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.25); }
        textarea { resize: vertical; min-height: 100px; }
        textarea#selection { background-color: #f8f9fa; cursor: not-allowed; }
        .btn { padding: 12px 20px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 500; text-decoration: none; display: inline-block; transition: all 0.2s ease-in-out; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 2px 8px var(--shadow-color); }
        .btn-primary { background-color: var(--primary-color); color: white; } .btn-primary:hover { background-color: var(--primary-hover); }
        .btn-secondary { background-color: var(--secondary-color); color: white; } .btn-secondary:hover { background-color: var(--secondary-hover); }
        .btn-danger { background-color: var(--danger-color); color: white; } .btn-danger:hover { background-color: var(--danger-hover); }
        .btn-success { background-color: var(--success-color); color: white; }
        .entry { border: 1px solid transparent; border-bottom: 1px solid var(--border-color); padding: 15px; margin: 0 -15px 10px; transition: background-color 0.2s ease, border-color 0.2s ease; }
        .entry:hover { background-color: #fcfdff; border-color: #d0e3f8; }
        .entry-code { background-color: var(--code-bg); padding: 8px 12px; border-radius: 4px; font-family: "SF Mono", monospace; display: block; margin-bottom: 10px; word-break: break-all; }
        .entry p { margin: 5px 0; } .entry-actions { margin-top: 15px; }
        .entry-actions .btn { padding: 6px 12px; font-size: 14px; margin-right: 10px; }
        .error { color: var(--danger-color); font-weight: bold; } .hidden { display: none; }
        .upload-form { display: flex; align-items: center; gap: 15px; margin-bottom: 20px; }
        #loader { text-align: center; padding: 20px; }
        .modal { display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4); }
        .modal-content { background-color: #fff; margin: 10% auto; padding: 2rem; border-radius: 0.5rem; width: 80%; max-width: 600px; }
        .linked-status { font-size: 0.8rem; font-weight: bold; color: var(--success-color); background-color: #e9f7ef; padding: 2px 6px; border-radius: 4px; display: inline-block; }
        @media (max-width: 992px) { .grid-container { grid-template-columns: 1fr; } .panel { height: auto; min-height: 50vh; } .container { padding: 20px; } }
    </style>
</head>
<body>

<div class="container">
    <h1>CIDD - Codebase Interactive Dictionary</h1>
    <div class="form-group">
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <input type="file" name="codebase_file" id="codebase_file" accept=".txt" required>
            <button type="submit" class="btn btn-primary">Load Codebase</button>
        </form>
        <?php if ($error_message): ?><p class="error"><?= htmlspecialchars($error_message) ?></p><?php endif; ?>
    </div>

    <div class="grid-container">
        <div class="panel">
            <div class="panel-header"><h2>Codebase Viewer</h2></div>
            <div id="codebase-viewer-container" data-codebase-path="<?= htmlspecialchars($uploaded_file ?? '') ?>" data-total-lines="<?= $total_lines ?>">
                <div id="codebase-viewer">
                    <?php
                    if ($uploaded_file && file_exists($uploaded_file)) {
                        $handle = fopen($uploaded_file, "r");
                        if ($handle) {
                            for ($i = 1; $i <= min($total_lines, LINES_PER_PAGE); $i++) {
                                if (($line = fgets($handle)) === false) break;
                                echo '<div class="code-line"><div class="line-number">' . $i . '</div><div class="line-content">' . htmlspecialchars($line) . '</div></div>';
                            }
                            fclose($handle);
                        }
                    } else { echo '<p style="padding: 20px;">Please upload a codebase file to begin.</p>'; }
                    ?>
                </div>
                 <div id="loader" class="hidden"><p>Loading...</p></div>
            </div>
        </div>

        <div class="panel">
            <div class="panel-header"><h2>Dictionary Manager</h2></div>
            <div id="dictionary-manager">
                <form id="entry-form" class="hidden">
                    <h3 id="form-title">New Entry</h3>
                    <input type="hidden" id="entry-id" name="id">
                    <div class="form-group">
                        <label for="selection" id="selection-label">Selected Code</label>
                        <textarea id="selection" name="selection" readonly rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="definition">Definition:</label>
                        <textarea id="definition" name="definition" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="context">Context:</label>
                        <textarea id="context" name="context"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="notes">Notes:</label>
                        <textarea id="notes" name="notes"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Entry</button>
                    <button type="button" id="cancel-edit" class="btn btn-secondary">Cancel</button>
                </form>
                <div id="dictionary-entries"><h3>Entries</h3></div>
            </div>
        </div>
    </div>
</div>

<!-- Promotion Modal -->
<div id="promotion-modal" class="modal">
    <div class="modal-content">
        <h3>Promote to Composer Definition</h3>
        <input type="hidden" id="promote-cidd-id">
        <div class="form-group">
            <label for="composer-projects">Select Composer Project:</label>
            <select id="composer-projects"></select>
        </div>
        <div class="form-group">
            <label for="composer-libs">Select Definition Library:</label>
            <select id="composer-libs"></select>
        </div>
        <button id="btn-confirm-promotion" class="btn btn-primary">Confirm Promotion</button>
        <button class="btn btn-secondary" onclick="closeModal('promotion-modal')">Cancel</button>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // --- STATE & DOM ---
    const state = {
        dictionary: <?= json_encode($dictionary_data) ?>,
        codebasePath: document.getElementById('codebase-viewer-container').dataset.codebasePath,
        totalLines: parseInt(document.getElementById('codebase-viewer-container').dataset.totalLines, 10),
        currentPage: 1,
        isLoading: false,
        isComposerPresent: <?= json_encode($is_composer_present) ?>,
    };
    const D = { // DOM Elements
        viewerContainer: document.getElementById('codebase-viewer-container'),
        viewer: document.getElementById('codebase-viewer'),
        loader: document.getElementById('loader'),
        entryForm: document.getElementById('entry-form'),
        formTitle: document.getElementById('form-title'),
        dictionaryEntries: document.getElementById('dictionary-entries'),
        selectionTextarea: document.getElementById('selection'),
        selectionLabel: document.getElementById('selection-label'),
        entryIdInput: document.getElementById('entry-id'),
        definitionInput: document.getElementById('definition'),
        contextInput: document.getElementById('context'),
        notesInput: document.getElementById('notes'),
        cancelEditBtn: document.getElementById('cancel-edit'),
        promotionModal: document.getElementById('promotion-modal'),
        composerProjectsSelect: document.getElementById('composer-projects'),
        composerLibsSelect: document.getElementById('composer-libs'),
        promoteCiddIdInput: document.getElementById('promote-cidd-id'),
        btnConfirmPromotion: document.getElementById('btn-confirm-promotion'),
    };

    // --- RENDER FUNCTIONS ---
    function renderDictionary() {
        const container = document.createElement('div');
        const filtered = state.dictionary.filter(e => e.codebase === state.codebasePath);

        if (filtered.length === 0) {
            container.innerHTML = '<p>No entries for this codebase yet.</p>';
        } else {
            filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).forEach(entry => {
                const el = document.createElement('div');
                el.className = 'entry';
                el.dataset.id = entry.id;
                
                let lineInfo = '';
                switch(entry.selection_type) {
                    case 'character': lineInfo = `Line ${entry.start_line}, Chars ${entry.start_char}-${entry.end_char}`; break;
                    case 'line': lineInfo = `Line ${entry.start_line}`; break;
                    case 'block': lineInfo = `Lines ${entry.start_line}-${entry.end_line}`; break;
                }

                let linkedStatus = entry.composer_definition_id ? `<span class="linked-status">Linked to Composer</span>` : '';
                let promoteBtn = !entry.composer_definition_id && state.isComposerPresent ? `<button class="btn btn-success promote-btn">Promote to Composer</button>` : '';

                el.innerHTML = `
                    <p><strong>${lineInfo}</strong> ${linkedStatus}</p>
                    <code class="entry-code">${escapeHtml(entry.selection)}</code>
                    <p><strong>Definition:</strong> ${escapeHtml(entry.definition)}</p>
                    <p><strong>Context:</strong> ${escapeHtml(entry.context || 'N/A')}</p>
                    <p><strong>Notes:</strong> ${escapeHtml(entry.notes || 'N/A')}</p>
                    <div class="entry-actions">
                        <button class="btn btn-secondary edit-btn">Edit</button>
                        <button class="btn btn-danger delete-btn">Delete</button>
                        ${promoteBtn}
                    </div>`;
                container.appendChild(el);
            });
        }
        const h3 = D.dictionaryEntries.querySelector('h3');
        D.dictionaryEntries.innerHTML = '';
        if(h3) D.dictionaryEntries.appendChild(h3);
        D.dictionaryEntries.appendChild(container);
    }

    // --- API & ASYNC LOGIC ---
    async function apiCall(action, params = {}, method = 'GET') {
        let url = `?action=${action}`;
        let options = { method };
        if (method === 'GET') {
            url += '&' + new URLSearchParams(params).toString();
        } else {
            const formData = new FormData();
            for (const key in params) {
                formData.append(key, params[key]);
            }
            options.body = formData;
        }
        try {
            const response = await fetch(url, options);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            alert('An error occurred. Check console.');
        }
    }

    async function fetchNextPage() {
        if (state.isLoading || (state.currentPage * LINES_PER_PAGE) >= state.totalLines) return;
        state.isLoading = true;
        D.loader.classList.remove('hidden');
        const data = await apiCall('get_codebase_chunk', { filepath: state.codebasePath, page: state.currentPage + 1 });
        if (data && data.content) {
            state.currentPage++;
            const startLineNum = ((data.page - 1) * LINES_PER_PAGE) + 1;
            data.content.forEach((line, index) => {
                const lineNum = startLineNum + index;
                const lineEl = document.createElement('div');
                lineEl.className = 'code-line';
                lineEl.innerHTML = `<div class="line-number">${lineNum}</div><div class="line-content">${escapeHtml(line)}</div>`;
                D.viewer.appendChild(lineEl);
            });
        }
        state.isLoading = false;
        D.loader.classList.add('hidden');
    }

    // --- EVENT HANDLERS ---
    D.viewerContainer.addEventListener('scroll', () => {
        const { scrollTop, scrollHeight, clientHeight } = D.viewerContainer;
        if (scrollTop + clientHeight >= scrollHeight - 200) fetchNextPage();
    });

    D.viewer.addEventListener('mouseup', () => {
        const selection = window.getSelection();
        if (!selection.rangeCount || selection.isCollapsed) return;
        
        const range = selection.getRangeAt(0);
        const startLineEl = findParentCodeLine(range.startContainer);
        const endLineEl = findParentCodeLine(range.endContainer);
        if (!startLineEl || !endLineEl) return;

        const startLine = parseInt(startLineEl.querySelector('.line-number').textContent, 10);
        const endLine = parseInt(endLineEl.querySelector('.line-number').textContent, 10);
        
        let reconstructedText = range.toString();
        if (reconstructedText.trim() === '') return;

        let selectionType, startChar = null, endChar = null;
        if (startLine === endLine) {
            const fullLineText = startLineEl.querySelector('.line-content').textContent;
            selectionType = (reconstructedText.trim() === fullLineText.trim()) ? 'line' : 'character';
            if (selectionType === 'character') {
                const tempRange = document.createRange();
                tempRange.selectNodeContents(startLineEl.querySelector('.line-content'));
                tempRange.setEnd(range.startContainer, range.startOffset);
                startChar = tempRange.toString().length;
                endChar = startChar + reconstructedText.length;
            }
        } else {
            selectionType = 'block';
        }

        resetForm();
        D.entryForm.classList.remove('hidden');
        D.selectionTextarea.value = reconstructedText;
        D.selectionTextarea.dataset.selectionType = selectionType;
        D.selectionTextarea.dataset.startLine = startLine;
        D.selectionTextarea.dataset.endLine = endLine;
        D.selectionTextarea.dataset.startChar = startChar ?? '';
        D.selectionTextarea.dataset.endChar = endChar ?? '';

        switch(selectionType) {
            case 'character': D.formTitle.textContent = 'New Character Entry'; D.selectionLabel.textContent = `Selected Code (Line ${startLine}, Chars ${startChar}-${endChar})`; break;
            case 'line': D.formTitle.textContent = 'New Line Entry'; D.selectionLabel.textContent = `Selected Code (Line ${startLine})`; break;
            case 'block': D.formTitle.textContent = 'New Block Entry'; D.selectionLabel.textContent = `Selected Code (Lines ${startLine}-${endLine})`; break;
        }
        D.definitionInput.focus();
    });
    
    D.entryForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = D.entryIdInput.value;
        const action = id ? 'update_entry' : 'add_entry';
        const params = {
            id: id,
            codebase: state.codebasePath,
            selection: D.selectionTextarea.value,
            selection_type: D.selectionTextarea.dataset.selectionType,
            start_line: D.selectionTextarea.dataset.startLine,
            end_line: D.selectionTextarea.dataset.endLine,
            start_char: D.selectionTextarea.dataset.startChar,
            end_char: D.selectionTextarea.dataset.endChar,
            definition: D.definitionInput.value,
            context: D.contextInput.value,
            notes: D.notesInput.value,
        };
        const data = await apiCall(action, params, 'POST');
        if (data.status === 'success') {
            if (action === 'add_entry') {
                state.dictionary.push(data.entry);
            } else {
                const index = state.dictionary.findIndex(entry => entry.id === id);
                if (index !== -1) state.dictionary[index] = data.entry;
            }
            renderDictionary();
            resetForm();
        } else {
            alert('Error: ' + (data.message || 'Could not save entry.'));
        }
    });

    D.dictionaryEntries.addEventListener('click', async (e) => {
        const entryEl = e.target.closest('.entry');
        if (!entryEl) return;
        const id = entryEl.dataset.id;
        const entry = state.dictionary.find(e => e.id === id);

        if (e.target.classList.contains('edit-btn')) {
            D.formTitle.textContent = 'Edit Entry';
            D.entryForm.classList.remove('hidden');
            D.entryIdInput.value = entry.id;
            D.selectionTextarea.value = entry.selection;
            D.definitionInput.value = entry.definition;
            D.contextInput.value = entry.context;
            D.notesInput.value = entry.notes;
            D.entryForm.scrollIntoView({ behavior: 'smooth' });
        } else if (e.target.classList.contains('delete-btn')) {
            if (confirm('Are you sure?')) {
                const data = await apiCall('delete_entry', { id }, 'POST');
                if (data.status === 'success') {
                    state.dictionary = state.dictionary.filter(e => e.id !== id);
                    renderDictionary();
                }
            }
        } else if (e.target.classList.contains('promote-btn')) {
            D.promoteCiddIdInput.value = id;
            const projectsData = await apiCall('list_composer_projects');
            if (projectsData.status === 'success' && projectsData.projects.length > 0) {
                D.composerProjectsSelect.innerHTML = projectsData.projects.map(p => `<option value="${p}">${p}</option>`).join('');
                await updateComposerLibsDropdown();
                openModal('promotion-modal');
            } else {
                alert('No Composer projects found.');
            }
        }
    });

    D.composerProjectsSelect.addEventListener('change', updateComposerLibsDropdown);
    D.btnConfirmPromotion.addEventListener('click', async () => {
        const params = {
            cidd_id: D.promoteCiddIdInput.value,
            project: D.composerProjectsSelect.value,
            library: D.composerLibsSelect.value,
        };
        const data = await apiCall('promote_to_composer', params, 'POST');
        if (data.status === 'success') {
            const index = state.dictionary.findIndex(e => e.id === params.cidd_id);
            if (index !== -1) state.dictionary[index].composer_definition_id = data.message.split(' ').pop();
            renderDictionary();
            closeModal('promotion-modal');
            alert('Promotion successful!');
        } else {
            alert('Error: ' + (data.message || 'Promotion failed.'));
        }
    });

    // --- UTILITY FUNCTIONS ---
    async function updateComposerLibsDropdown() {
        const project = D.composerProjectsSelect.value;
        const libsData = await apiCall('list_composer_libs', { project });
        if (libsData.status === 'success') {
            D.composerLibsSelect.innerHTML = libsData.files.map(f => `<option value="${f}">${f}</option>`).join('');
        }
    }
    function findParentCodeLine(node) {
        if (!node) return null;
        if (node.nodeType === 1 && node.classList.contains('code-line')) return node;
        return findParentCodeLine(node.parentElement);
    }
    function resetForm() {
        D.entryForm.reset();
        D.entryIdInput.value = '';
        D.entryForm.classList.add('hidden');
    }
    function escapeHtml(unsafe) {
        if (typeof unsafe !== 'string') return '';
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
    function openModal(id) { document.getElementById(id).style.display = 'block'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    D.cancelEditBtn.addEventListener('click', resetForm);

    // --- INITIALIZATION ---
    if(state.codebasePath) {
        renderDictionary();
    }
});
</script>

</body>
</html>
```
# codebase-composer.php
```php
<?php
// codebase-composer.php - A Modular Software Architecture Composer
// Version 1.7
// Implements accessibility improvements by adding programmatic labels to
// form controls, ensuring compliance with WCAG standards.

// --- INITIALIZATION & CONFIGURATION ---
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DATA_DIR', __DIR__ . '/composer_data');

// Ensure the base data directory exists
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0777, true);
}

// Handle Tab Size Setting
if (isset($_POST['action']) && $_POST['action'] === 'set_tab_size') {
    $tabSize = (int)$_POST['tab_size'];
    if ($tabSize > 0 && $tabSize <= 16) {
        $_SESSION['tab_size'] = $tabSize;
    }
    echo json_encode(['status' => 'success', 'tab_size' => $_SESSION['tab_size']]);
    exit;
}
$TAB_SIZE = $_SESSION['tab_size'] ?? 4;


// --- API ROUTER ---
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $project = $_POST['project'] ?? null;
    $payload = $_POST['payload'] ?? [];

    // Basic validation for project name to prevent directory traversal
    if ($project && (strpos($project, '/') !== false || strpos($project, '..') !== false)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid project name.']);
        exit;
    }

    switch ($action) {
        // Project Management
        case 'list_projects':
            echo json_encode(list_projects());
            break;
        case 'create_project':
            echo json_encode(create_project($payload['name']));
            break;
        // Definition Library Management
        case 'list_definition_libs':
            echo json_encode(list_files($project, 'definitions', 'json'));
            break;
        case 'create_definition_lib':
            echo json_encode(create_file($project, 'definitions', $payload['name'], 'json', []));
            break;
        case 'get_definitions':
            echo json_encode(get_definitions($project, $payload['lib']));
            break;
        case 'save_definition':
            echo json_encode(save_definition($project, $payload));
            break;
        case 'delete_definition':
            echo json_encode(delete_definition($project, $payload));
            break;
        // Composition Management
        case 'list_compositions':
            echo json_encode(list_files($project, 'compositions', 'composition.json'));
            break;
        case 'create_composition':
            echo json_encode(create_file($project, 'compositions', $payload['name'], 'composition.json', ['definitions' => []]));
            break;
        case 'get_composition':
            echo json_encode(get_composition($project, $payload['name']));
            break;
        case 'save_composition':
            echo json_encode(save_composition($project, $payload));
            break;
    }
    exit;
}

// --- BACKEND FUNCTIONS ---

function sanitize_filename($filename) {
    // The period character (.) must be included in the allowed character set.
    $sanitized = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $filename);
    // Prevent multiple consecutive underscores
    $sanitized = preg_replace('/_+/', '_', $sanitized);
    return $sanitized;
}


// --- Project Functions ---
function list_projects() {
    $projects = [];
    $items = array_diff(scandir(DATA_DIR), ['..', '.']);
    foreach ($items as $item) {
        if (is_dir(DATA_DIR . '/' . $item)) {
            $projects[] = $item;
        }
    }
    return ['status' => 'success', 'projects' => $projects];
}

function create_project($name) {
    $name = sanitize_filename($name);
    if (empty($name)) return ['status' => 'error', 'message' => 'Project name cannot be empty.'];
    $project_path = DATA_DIR . '/' . $name;
    if (is_dir($project_path)) return ['status' => 'error', 'message' => 'Project already exists.'];
    
    mkdir($project_path, 0777, true);
    mkdir($project_path . '/definitions', 0777, true);
    mkdir($project_path . '/compositions', 0777, true);
    
    return ['status' => 'success', 'project' => $name];
}

// --- Generic File/Dir Functions ---
function list_files($project, $type, $extension) {
    $dir_path = DATA_DIR . "/$project/$type";
    $files = [];
    if (!is_dir($dir_path)) return ['status' => 'success', 'files' => []];
    
    $items = array_diff(scandir($dir_path), ['..', '.']);
    foreach ($items as $item) {
        if (pathinfo($item, PATHINFO_EXTENSION) === explode('.', $extension)[0] || str_ends_with($item, $extension)) {
             $files[] = $item;
        }
    }
    return ['status' => 'success', 'files' => $files];
}

function create_file($project, $type, $name, $extension, $initial_content = []) {
    $name = sanitize_filename($name);
    if (empty($name)) return ['status' => 'error', 'message' => 'File name cannot be empty.'];
    if (!str_ends_with(strtolower($name), ".$extension")) {
        $name .= ".$extension";
    }
    $file_path = DATA_DIR . "/$project/$type/$name";
    if (file_exists($file_path)) return ['status' => 'error', 'message' => 'File already exists.'];
    
    file_put_contents($file_path, json_encode($initial_content, JSON_PRETTY_PRINT));
    return ['status' => 'success', 'file' => $name];
}

// --- Definition Functions ---
function get_definitions($project, $lib) {
    $file_path = DATA_DIR . "/$project/definitions/" . sanitize_filename($lib);
    if (!file_exists($file_path)) return ['status' => 'error', 'message' => 'Definition library not found.'];
    
    $content = json_decode(file_get_contents($file_path), true);
    return ['status' => 'success', 'definitions' => is_array($content) ? $content : []];
}

// --- Definition Functions ---
function save_definition($project, $payload) {
    $lib_path = DATA_DIR . "/$project/definitions/" . sanitize_filename($payload['lib']);
    if (!file_exists($lib_path))
        return ['status' => 'error', 'message' => 'Library not found.'];

    $definitions = json_decode(file_get_contents($lib_path), true) ?: [];

    // Treat an empty or missing id as "new"
    $id = trim($payload['id'] ?? '');
    if ($id === '') {
        $id = 'def_' . uniqid();
    }

    $new_def = [
        'id'      => $id,
        'name'    => $payload['name'],
        'content' => $payload['content'],
        'notes'   => $payload['notes']
    ];

    // Upsert
    $found = false;
    foreach ($definitions as &$def) {
        if ($def['id'] === $id) {
            $def   = $new_def;
            $found = true;
            break;
        }
    }
    if (!$found) $definitions[] = $new_def;

    file_put_contents($lib_path, json_encode($definitions, JSON_PRETTY_PRINT));
    return ['status' => 'success', 'definition' => $new_def];
}


function delete_definition($project, $payload) {
    $lib_path = DATA_DIR . "/$project/definitions/" . sanitize_filename($payload['lib']);
    if (!file_exists($lib_path)) return ['status' => 'error', 'message' => 'Library not found.'];
    
    $definitions = json_decode(file_get_contents($lib_path), true);
    if (!is_array($definitions)) $definitions = [];
    $id_to_delete = $payload['id'];
    
    $definitions = array_filter($definitions, function($def) use ($id_to_delete) {
        return $def['id'] !== $id_to_delete;
    });
    
    file_put_contents($lib_path, json_encode(array_values($definitions), JSON_PRETTY_PRINT));
    return ['status' => 'success'];
}

// --- Composition Functions ---
function get_composition($project, $comp_name) {
    $comp_path = DATA_DIR . "/$project/compositions/" . sanitize_filename($comp_name);
    if (!file_exists($comp_path)) return ['status' => 'error', 'message' => 'Composition not found.'];

    $composition = json_decode(file_get_contents($comp_path), true);
    $def_ids = $composition['definitions'] ?? [];
    
    // Load all definitions for the project into a hash map for quick lookup
    $all_definitions = [];
    $def_libs = list_files($project, 'definitions', 'json')['files'];
    foreach ($def_libs as $lib) {
        $defs_data = get_definitions($project, $lib);
        if ($defs_data['status'] === 'success') {
            foreach ($defs_data['definitions'] as $def) {
                $all_definitions[$def['id']] = $def;
            }
        }
    }

    $full_content = '';
    foreach ($def_ids as $id) {
        if (isset($all_definitions[$id])) {
            $full_content .= $all_definitions[$id]['content'];
        }
    }

    return ['status' => 'success', 'composition' => $composition, 'full_content' => $full_content];
}

function save_composition($project, $payload) {
    // fall back to an empty array if “definitions” is missing
    $defs = $payload['definitions'] ?? [];
    $composition = ['definitions' => array_values($defs)];

    // locate the file
    $comp_name = sanitize_filename($payload['name']);
    $comp_path = DATA_DIR . "/$project/compositions/$comp_name";
    if (!file_exists($comp_path))
        return ['status' => 'error', 'message' => 'Composition not found.'];

    // write the JSON
    file_put_contents($comp_path, json_encode($composition, JSON_PRETTY_PRINT));

    // also emit the assembled .txt version
    $assembled_data    = get_composition($project, $comp_name);
    $assembled_content = $assembled_data['full_content'] ?? '';
    $txt_filename      = str_replace('.composition.json', '.txt', $comp_name);
    file_put_contents(DATA_DIR . "/$project/compositions/$txt_filename", $assembled_content);

    return ['status' => 'success'];
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Codebase Composer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f4f7f9;
            --panel-bg: #ffffff;
            --text-color: #334155;
            --heading-color: #1e293b;
            --border-color: #e2e8f0;
            --primary-color: #3b82f6;
            --primary-hover: #2563eb;
            --danger-color: #ef4444;
            --danger-hover: #dc2626;
            --code-bg: #f8fafc;
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --font-sans: 'Inter', sans-serif;
            --font-mono: 'Roboto Mono', monospace;
        }
        *, *::before, *::after { box-sizing: border-box; }
        body { font-family: var(--font-sans); line-height: 1.6; margin: 0; background-color: var(--bg-color); color: var(--text-color); font-size: 16px; }
        .main-container { display: grid; grid-template-columns: 300px 1fr 1fr; height: 100vh; gap: 1rem; padding: 1rem; }
        .panel { background-color: var(--panel-bg); border-radius: 0.5rem; box-shadow: var(--shadow); border: 1px solid var(--border-color); display: flex; flex-direction: column; overflow: hidden; }
        .panel-header { padding: 0.75rem 1rem; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
        .panel-title { font-size: 1.125rem; font-weight: 600; color: var(--heading-color); }
        .panel-body { padding: 1rem; overflow-y: auto; flex-grow: 1; }
        .panel-body.no-padding { padding: 0; }
        .btn { padding: 0.5rem 1rem; border: 1px solid transparent; border-radius: 0.375rem; cursor: pointer; font-size: 0.875rem; font-weight: 500; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; border-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--primary-hover); }
        .btn-sm { padding: 0.25rem 0.5rem; font-size: 0.75rem; }
        .btn:disabled { background-color: #9ca3af; border-color: #9ca3af; color: #e5e7eb; cursor: not-allowed; transform: none; box-shadow: none; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; font-size: 0.875rem; }
        input[type="text"], textarea { width: 100%; padding: 0.625rem; border: 1px solid var(--border-color); border-radius: 0.375rem; transition: all 0.2s ease; }
        input[type="text"]:focus, textarea:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        textarea { resize: vertical; min-height: 120px; font-family: var(--font-mono); tab-size: <?= $TAB_SIZE ?>; -moz-tab-size: <?= $TAB_SIZE ?>; }
        .file-list { list-style: none; padding: 0; margin: 0; }
        .file-list-item { padding: 0.75rem 1rem; cursor: pointer; border-bottom: 1px solid var(--border-color); transition: background-color 0.2s ease; }
        .file-list-item:last-child { border-bottom: none; }
        .file-list-item:hover { background-color: #f1f5f9; }
        .file-list-item.active { background-color: var(--primary-color); color: white; font-weight: 500; }
        .definition-item { padding: 1rem; border: 1px solid var(--border-color); border-radius: 0.5rem; margin-bottom: 1rem; cursor: pointer; transition: all 0.2s ease; }
        .definition-item:hover { border-color: var(--primary-color); box-shadow: var(--shadow); }
        .definition-name { font-weight: 600; color: var(--heading-color); }
        .definition-content { font-family: var(--font-mono); font-size: 0.875rem; background-color: var(--code-bg); padding: 0.5rem; border-radius: 0.25rem; margin-top: 0.5rem; white-space: pre-wrap; word-break: break-all; }
        .modal { display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4); }
        .modal-content { background-color: #fff; margin: 10% auto; padding: 2rem; border-radius: 0.5rem; width: 80%; max-width: 600px; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem; margin-bottom: 1rem; }
        .hidden { display: none; }
        #composition-editor { width: 100%; height: 100%; border: none; padding: 1rem; resize: none; font-family: var(--font-mono); }
        #composition-editor:focus { outline: none; }
        .settings-bar { padding: 0.5rem 1rem; background-color: var(--code-bg); border-top: 1px solid var(--border-color); display: flex; align-items: center; gap: 1rem; }
    </style>
</head>
<body>

<div class="main-container">
    <!-- Panel 1: Project & File Management -->
    <div class="panel" id="panel-projects">
        <div class="panel-header">
            <h2 class="panel-title">Projects</h2>
            <button class="btn btn-primary btn-sm" id="btn-new-project" aria-label="New Project">+</button>
        </div>
        <div class="panel-body no-padding">
            <ul class="file-list" id="project-list"></ul>
        </div>
        <div id="project-files-container" class="hidden">
            <div class="panel-header">
                <h3 class="panel-title">Def. Libraries</h3>
                <button class="btn btn-primary btn-sm" id="btn-new-def-lib" aria-label="New Definition Library">+</button>
            </div>
            <ul class="file-list" id="def-lib-list"></ul>
            <div class="panel-header">
                <h3 class="panel-title">Compositions</h3>
                <button class="btn btn-primary btn-sm" id="btn-new-composition" aria-label="New Composition">+</button>
            </div>
            <ul class="file-list" id="composition-list"></ul>
        </div>
    </div>

    <!-- Panel 2: Definitions -->
    <div class="panel" id="panel-definitions">
        <div class="panel-header">
            <h2 class="panel-title">Definitions</h2>
            <button class="btn btn-primary btn-sm" id="btn-new-definition" disabled>New Definition</button>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <input type="text" id="search-definitions" placeholder="Search definitions...">
            </div>
            <div id="definition-list-container"></div>
        </div>
    </div>

    <!-- Panel 3: Composition Editor -->
    <div class="panel" id="panel-composition">
        <div class="panel-header">
            <h2 class="panel-title" id="composition-title">Composition</h2>
            <button class="btn btn-primary btn-sm hidden" id="btn-save-composition">Save</button>
        </div>
        <div class="panel-body no-padding">
            <textarea id="composition-editor" readonly aria-labelledby="composition-title"></textarea>
        </div>
        <div class="settings-bar">
            <label for="tab-size-input">Tab Size:</label>
            <input type="number" id="tab-size-input" min="1" max="16" value="<?= $TAB_SIZE ?>" style="width: 60px;">
        </div>
    </div>
</div>

<!-- Modals -->
<div id="new-project-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2>New Project</h2></div>
        <div class="form-group">
            <label for="new-project-name">Project Name:</label>
            <input type="text" id="new-project-name">
        </div>
        <button id="btn-create-project" class="btn btn-primary">Create</button>
        <button class="btn" onclick="closeModal('new-project-modal')">Cancel</button>
    </div>
</div>

<div id="new-file-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2 id="new-file-title">New File</h2></div>
        <div class="form-group">
            <label for="new-file-name">File Name:</label>
            <input type="text" id="new-file-name">
        </div>
        <button id="btn-create-file" class="btn btn-primary">Create</button>
        <button class="btn" onclick="closeModal('new-file-modal')">Cancel</button>
    </div>
</div>

<div id="definition-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2 id="definition-form-title">Definition</h2></div>
        <input type="hidden" id="definition-id">
        <input type="hidden" id="definition-lib">
        <div class="form-group">
            <label for="definition-name">Name:</label>
            <input type="text" id="definition-name" placeholder="e.g., php_open_tag">
        </div>
        <div class="form-group">
            <label for="definition-content">Content:</label>
            <textarea id="definition-content"></textarea>
        </div>
        <div class="form-group">
            <label for="definition-notes">Notes:</label>
            <textarea id="definition-notes" rows="3"></textarea>
        </div>
        <button id="btn-save-definition" class="btn btn-primary">Save</button>
        <button id="btn-delete-definition" class="btn btn-danger hidden">Delete</button>
        <button class="btn" onclick="closeModal('definition-modal')">Cancel</button>
    </div>
</div>

<script>
    // --- STATE MANAGEMENT ---
    const state = {
        projects: [],
        activeProject: null,
        definitionLibs: [],
        activeDefLib: null,
        compositions: [],
        activeComposition: null,
        definitions: [], // Now only holds definitions for the active library
        allDefinitions: {}, // Holds all loaded definitions for composition
        compositionDefIds: [],
    };

    // --- DOM ELEMENTS ---
    const M = {
        projectList: document.getElementById('project-list'),
        projectFilesContainer: document.getElementById('project-files-container'),
        defLibList: document.getElementById('def-lib-list'),
        compositionList: document.getElementById('composition-list'),
        definitionListContainer: document.getElementById('definition-list-container'),
        compositionEditor: document.getElementById('composition-editor'),
        compositionTitle: document.getElementById('composition-title'),
        btnNewDefinition: document.getElementById('btn-new-definition'),
        btnSaveComposition: document.getElementById('btn-save-composition'),
        searchDefinitions: document.getElementById('search-definitions'),
        tabSizeInput: document.getElementById('tab-size-input'),
    };

    // --- API HELPERS ---
    async function apiCall(action, project = null, payload = {}) {
        const formData = new FormData();
        formData.append('action', action);
        if (project) formData.append('project', project);
        

		for (const key in payload) {
			if (Array.isArray(payload[key])) {
				payload[key].forEach(item =>
					formData.append(`payload[${key}][]`, item));
			} else {
				formData.append(`payload[${key}]`, payload[key]);
			}
		}


        try {
            const response = await fetch('', { method: 'POST', body: formData });
            const contentType = response.headers.get("content-type");
            if (!response.ok || !contentType || !contentType.includes("application/json")) {
                const text = await response.text();
                throw new Error(`Server returned non-JSON response: ${text}`);
            }
            return await response.json();
        } catch (error) {
            console.error('API Call Failed:', error);
            alert('An error occurred. Check the console for details.');
            return { status: 'error', message: error.message };
        }
    }

    // --- RENDER FUNCTIONS ---
    function renderProjects() {
        M.projectList.innerHTML = '';
        state.projects.forEach(p => {
            const li = document.createElement('li');
            li.className = 'file-list-item';
            li.textContent = p;
            if (p === state.activeProject) li.classList.add('active');
            li.addEventListener('click', () => selectProject(p));
            M.projectList.appendChild(li);
        });
    }

    function renderDefLibs() {
        M.defLibList.innerHTML = '';
        state.definitionLibs.forEach(lib => {
            const li = document.createElement('li');
            li.className = 'file-list-item';
            li.textContent = lib;
            if (lib === state.activeDefLib) li.classList.add('active');
            li.addEventListener('click', () => selectDefLib(lib));
            M.defLibList.appendChild(li);
        });
    }
    
    function renderCompositions() {
        M.compositionList.innerHTML = '';
        state.compositions.forEach(comp => {
            const li = document.createElement('li');
            li.className = 'file-list-item';
            li.textContent = comp;
            if (comp === state.activeComposition) li.classList.add('active');
            li.addEventListener('click', () => selectComposition(comp));
            M.compositionList.appendChild(li);
        });
    }

    function renderDefinitions() {
        const searchTerm = M.searchDefinitions.value.toLowerCase();
        M.definitionListContainer.innerHTML = '';
        const filteredDefs = state.definitions.filter(def => 
            def.name.toLowerCase().includes(searchTerm) || 
            def.content.toLowerCase().includes(searchTerm)
        );

        filteredDefs.forEach(def => {
            const div = document.createElement('div');
            div.className = 'definition-item';
            div.innerHTML = `
                <div class="definition-name">${escapeHtml(def.name)}</div>
                <div class="definition-content">${escapeHtml(def.content)}</div>
            `;
            div.addEventListener('click', () => addDefinitionToComposition(def.id));
            div.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                openDefinitionModal(def);
            });
            M.definitionListContainer.appendChild(div);
        });
    }

    async function renderCompositionEditor() {
        if (!state.activeComposition) {
            M.compositionEditor.value = '';
            M.compositionTitle.textContent = 'Composition';
            M.btnSaveComposition.classList.add('hidden');
            return;
        }
        M.compositionTitle.textContent = state.activeComposition;
        M.btnSaveComposition.classList.remove('hidden');

        const res = await apiCall('get_composition', state.activeProject, { name: state.activeComposition });
        if (res.status === 'success') {
            state.compositionDefIds = res.composition.definitions || [];
            M.compositionEditor.value = res.full_content;
        }
    }

    // --- EVENT HANDLERS & LOGIC ---
    async function init() {
        const res = await apiCall('list_projects');
        if (res.status === 'success') {
            state.projects = res.projects;
            renderProjects();
        }
        M.searchDefinitions.addEventListener('input', renderDefinitions);
        enableTabInTextarea(document.getElementById('definition-content'));
    }

    async function selectProject(projectName) {
        state.activeProject = projectName;
        state.activeDefLib = null;
        state.activeComposition = null;
        state.definitions = [];
        state.allDefinitions = {};
        M.btnNewDefinition.disabled = true;
        renderProjects();
        renderDefinitions();
        renderCompositionEditor();
        M.projectFilesContainer.classList.remove('hidden');
        
        const [libsRes, compsRes] = await Promise.all([
            apiCall('list_definition_libs', state.activeProject),
            apiCall('list_compositions', state.activeProject)
        ]);

        if (libsRes.status === 'success') {
            state.definitionLibs = libsRes.files;
            renderDefLibs();
            // Pre-load all definitions for composition
            for (const lib of state.definitionLibs) {
                const defsRes = await apiCall('get_definitions', state.activeProject, { lib });
                if (defsRes.status === 'success') {
                    defsRes.definitions.forEach(def => {
                        state.allDefinitions[def.id] = def;
                    });
                }
            }
        }
        if (compsRes.status === 'success') {
            state.compositions = compsRes.files;
            renderCompositions();
        }
    }

    async function selectDefLib(libName) {
        state.activeDefLib = libName;
        M.btnNewDefinition.disabled = false;
        renderDefLibs();
        
        const res = await apiCall('get_definitions', state.activeProject, { lib: libName });
        if (res.status === 'success') {
            state.definitions = res.definitions;
            state.definitions.forEach(def => def.lib = libName);
            renderDefinitions();
        }
    }
    
    async function selectComposition(compName) {
        state.activeComposition = compName;
        renderCompositions();
        await renderCompositionEditor();
    }
    
    function addDefinitionToComposition(defId) {
        if (!state.activeComposition) {
            alert('Please select a composition first.');
            return;
        }
        const def = state.allDefinitions[defId];
        if (def) {
            state.compositionDefIds.push(def.id);
            M.compositionEditor.value += def.content;
        } else {
            const localDef = state.definitions.find(d => d.id === defId);
            if(localDef) {
                 state.compositionDefIds.push(localDef.id);
                 M.compositionEditor.value += localDef.content;
            }
        }
    }

    async function saveComposition() {
        if (!state.activeComposition) return;
        const res = await apiCall('save_composition', state.activeProject, {
            name: state.activeComposition,
            definitions: state.compositionDefIds
        });
        if (res.status === 'success') {
            alert('Composition saved!');
        } else {
            alert('Error saving composition: ' + res.message);
        }
    }

    // --- MODAL & FORM LOGIC ---
    function openModal(id) { document.getElementById(id).style.display = 'block'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }

    document.getElementById('btn-new-project').addEventListener('click', () => openModal('new-project-modal'));
    document.getElementById('btn-create-project').addEventListener('click', async () => {
        const name = document.getElementById('new-project-name').value;
        const res = await apiCall('create_project', null, { name });
        if (res.status === 'success') {
            state.projects.push(res.project);
            selectProject(res.project);
            closeModal('new-project-modal');
        } else {
            alert('Error: ' + res.message);
        }
    });

    let fileCreationContext = {};
    document.getElementById('btn-new-def-lib').addEventListener('click', () => {
        if (!state.activeProject) return;
        fileCreationContext = { type: 'definitions', action: 'create_definition_lib' };
        document.getElementById('new-file-title').textContent = 'New Definition Library';
        document.getElementById('new-file-name').value = '';
        openModal('new-file-modal');
    });
    document.getElementById('btn-new-composition').addEventListener('click', () => {
        if (!state.activeProject) return;
        fileCreationContext = { type: 'compositions', action: 'create_composition' };
        document.getElementById('new-file-title').textContent = 'New Composition';
        document.getElementById('new-file-name').value = '';
        openModal('new-file-modal');
    });
    document.getElementById('btn-create-file').addEventListener('click', async () => {
        const name = document.getElementById('new-file-name').value;
        const res = await apiCall(fileCreationContext.action, state.activeProject, { name });
        if (res.status === 'success') {
            if (fileCreationContext.type === 'definitions') {
                state.definitionLibs.push(res.file);
                renderDefLibs();
            } else {
                state.compositions.push(res.file);
                renderCompositions();
            }
            closeModal('new-file-modal');
        } else {
            alert('Error: ' + res.message);
        }
    });

    function openDefinitionModal(def = null) {
        if (!state.activeDefLib && !def) {
            alert('Please select a definition library first.');
            return;
        }
        const formTitle = document.getElementById('definition-form-title');
        const idInput = document.getElementById('definition-id');
        const libInput = document.getElementById('definition-lib');
        const nameInput = document.getElementById('definition-name');
        const contentInput = document.getElementById('definition-content');
        const notesInput = document.getElementById('definition-notes');
        const deleteBtn = document.getElementById('btn-delete-definition');

        if (def) {
            formTitle.textContent = 'Edit Definition';
            idInput.value = def.id;
            libInput.value = def.lib; 
            nameInput.value = def.name;
            contentInput.value = def.content;
            notesInput.value = def.notes;
            deleteBtn.classList.remove('hidden');
        } else {
            formTitle.textContent = 'New Definition';
            idInput.value = '';
            libInput.value = state.activeDefLib;
            nameInput.value = '';
            contentInput.value = '';
            notesInput.value = '';
            deleteBtn.classList.add('hidden');
        }
        openModal('definition-modal');
    }

    document.getElementById('btn-new-definition').addEventListener('click', () => openDefinitionModal());
    
    document.getElementById('btn-save-definition').addEventListener('click', async () => {
        const payload = {
            lib: document.getElementById('definition-lib').value,
            id: document.getElementById('definition-id').value,
            name: document.getElementById('definition-name').value,
            content: document.getElementById('definition-content').value,
            notes: document.getElementById('definition-notes').value,
        };
		if (!payload.id.trim()) delete payload.id;   // let PHP create the id
        const res = await apiCall('save_definition', state.activeProject, payload);
        if (res.status === 'success') {
            await selectDefLib(state.activeDefLib);
            closeModal('definition-modal');
        } else {
            alert('Error: ' + res.message);
        }
    });

    document.getElementById('btn-delete-definition').addEventListener('click', async () => {
        if (!confirm('Are you sure?')) return;
        const payload = {
            lib: document.getElementById('definition-lib').value,
            id: document.getElementById('definition-id').value,
        };
        const res = await apiCall('delete_definition', state.activeProject, payload);
        if (res.status === 'success') {
            await selectDefLib(state.activeDefLib);
            closeModal('definition-modal');
        } else {
            alert('Error: ' + res.message);
        }
    });

    document.getElementById('btn-save-composition').addEventListener('click', saveComposition);
    
    // --- UTILITIES ---
    function escapeHtml(unsafe) {
        return unsafe
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
    }

    function enableTabInTextarea(textarea) {
        textarea.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                this.value = this.value.substring(0, start) + "\t" + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 1;
            }
        });
    }

    M.tabSizeInput.addEventListener('change', async (e) => {
        const size = e.target.value;
        const res = await apiCall('set_tab_size', null, { tab_size: size });
        if (res.status === 'success') {
            const newSize = res.tab_size;
            document.querySelectorAll('textarea').forEach(ta => {
                ta.style.tabSize = newSize;
                ta.style.MozTabSize = newSize;
            });
        }
    });

    // --- INITIAL LOAD ---
    init();

</script>
</body>
</html>

```

# jisc.php
```php
<?php
// jisc.php - JSON Indexing-Sequencer Controller
// Version 1.4
// Implements the definitive fix for the newline/tab conversion bug by
// correctly un-escaping control characters in the Alphabet Generator.

// --- INITIALIZATION & CONFIGURATION ---
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('COMPOSER_DATA_DIR', __DIR__ . '/composer_data');

// Handle Tab Size Setting
if (isset($_POST['action']) && $_POST['action'] === 'set_tab_size') {
    $tabSize = (int)$_POST['tab_size'];
    if ($tabSize > 0 && $tabSize <= 16) {
        $_SESSION['tab_size'] = $tabSize;
    }
    echo json_encode(['status' => 'success', 'tab_size' => $_SESSION['tab_size']]);
    exit;
}
$TAB_SIZE = $_SESSION['tab_size'] ?? 4;


// --- API ROUTER ---
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $project = $_POST['project'] ?? null;
    $payload = $_POST['payload'] ?? [];

    // Basic validation
    if ($project && (strpos($project, '/') !== false || strpos($project, '..') !== false)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid project name.']);
        exit;
    }

    switch ($action) {
        // Shared helpers from composer
        case 'list_projects':
            echo json_encode(list_composer_projects());
            break;
        case 'list_definition_libs':
            echo json_encode(list_composer_definition_libs($project));
            break;
        // JISC specific actions
        case 'batch_generate_definitions':
            echo json_encode(batch_generate_definitions($project, $payload));
            break;
        case 'get_all_definitions':
            echo json_encode(['status' => 'success', 'definitions' => get_all_definitions($project)]);
            break;
        case 'get_definitions':
             echo json_encode(get_definitions($project, $payload['lib']));
             break;
        case 'execute_sequence':
            echo json_encode(execute_sequence($project, $payload));
            break;
    }
    exit;
}

// --- BACKEND FUNCTIONS ---

function sanitize_filename($filename, $is_path = false) {
    if ($is_path) {
        return preg_replace('/[^A-Za-z0-9_\-\.\/]/', '_', $filename);
    }
    $sanitized = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $filename);
    return preg_replace('/_+/', '_', $sanitized);
}

// --- Composer Data Interaction Functions ---
function list_composer_projects() {
    $projects = [];
    if (!is_dir(COMPOSER_DATA_DIR)) return ['status' => 'success', 'projects' => []];
    $items = array_diff(scandir(COMPOSER_DATA_DIR), ['..', '.']);
    foreach ($items as $item) {
        if (is_dir(COMPOSER_DATA_DIR . '/' . $item)) {
            $projects[] = $item;
        }
    }
    return ['status' => 'success', 'projects' => $projects];
}

function list_composer_definition_libs($project) {
    $project = sanitize_filename($project);
    $dir_path = COMPOSER_DATA_DIR . "/$project/definitions";
    $files = [];
    if (!is_dir($dir_path)) return ['status' => 'success', 'files' => []];
    
    $items = array_diff(scandir($dir_path), ['..', '.']);
    foreach ($items as $item) {
        if (pathinfo($item, PATHINFO_EXTENSION) === 'json') {
             $files[] = $item;
        }
    }
    return ['status' => 'success', 'files' => $files];
}

function get_definitions($project, $lib) {
    $file_path = COMPOSER_DATA_DIR . "/$project/definitions/" . sanitize_filename($lib);
    if (!file_exists($file_path)) return ['status' => 'error', 'message' => 'Definition library not found.'];
    
    $content = json_decode(file_get_contents($file_path), true);
    return ['status' => 'success', 'definitions' => is_array($content) ? $content : []];
}

function get_all_definitions($project) {
    $all_definitions = [];
    $libs_data = list_composer_definition_libs($project);
    if ($libs_data['status'] !== 'success') return [];

    foreach ($libs_data['files'] as $lib_file) {
        $lib_path = COMPOSER_DATA_DIR . "/$project/definitions/" . sanitize_filename($lib_file);
        $content = json_decode(file_get_contents($lib_path), true);
        if (is_array($content)) {
            foreach($content as $def) {
                $all_definitions[$def['name']] = $def;
            }
        }
    }
    return $all_definitions;
}


// --- JISC Core Functions ---

function batch_generate_definitions($project, $payload) {
    $lib_name = sanitize_filename($payload['lib_name']);
    $char_string = $payload['characters'];

    if (empty($lib_name)) return ['status' => 'error', 'message' => 'Library name cannot be empty.'];
    if (!str_ends_with($lib_name, '.json')) $lib_name .= '.json';

    $lib_path = COMPOSER_DATA_DIR . "/$project/definitions/$lib_name";
    if (file_exists($lib_path)) return ['status' => 'error', 'message' => "Library '$lib_name' already exists."];

    // FIX: Un-escape the input string to handle \n, \t, etc. correctly.
    $processed_string = stripcslashes($char_string);
    $definitions = [];
    $unique_chars = array_unique(str_split($processed_string));

    $symbol_map = [
        '`'=>'backtick', '~'=>'tilde', '!'=>'exclamation', '@'=>'at', '#'=>'hash', '$'=>'dollar',
        '%'=>'percent', '^'=>'caret', '&'=>'ampersand', '*'=>'asterisk', '('=>'paren_open', ')'=>'paren_close',
        '-'=>'minus', '_'=>'underscore', '='=>'equals', '+'=>'plus', '['=>'bracket_open', ']'=>'bracket_close',
        '{'=>'brace_open', '}'=>'brace_close', '\\'=>'backslash', '|'=>'pipe', ';'=>'semicolon', ':'=>'colon',
        '\''=>'single_quote', '"'=>'double_quote', ','=>'comma', '.'=>'period', '/'=>'slash', '<'=>'less_than',
        '>'=>'greater_than', '?'=>'question_mark'
    ];

    foreach ($unique_chars as $char) {
        $name = '';
        if ($char === "\n") $name = 'char_newline';
        else if ($char === "\r") $name = 'char_carriage_return';
        else if ($char === "\t") $name = 'char_tab';
        else if ($char === ' ') $name = 'char_space';
        else if (ctype_alnum($char)) {
            $name = (ctype_lower($char) ? 'char_' : 'char_upper_') . strtolower($char);
        } else if (isset($symbol_map[$char])) {
            $name = 'char_' . $symbol_map[$char];
        } else if (ctype_space($char)) {
            $name = 'char_whitespace_' . dechex(ord($char));
        } else {
            $name = 'char_unknown_' . bin2hex($char);
        }

        $final_name = $name;
        $counter = 2;
        while (isset($definitions[$final_name])) {
            $final_name = $name . '_' . $counter++;
        }
        
        $definitions[$final_name] = [
            'id' => 'def_' . uniqid(),
            'name' => $final_name,
            'content' => $char,
            'notes' => 'Auto-generated by JISC'
        ];
    }

    file_put_contents($lib_path, json_encode(array_values($definitions), JSON_PRETTY_PRINT));
    return ['status' => 'success', 'message' => 'Definition library created successfully.'];
}

function execute_sequence($project, $payload) {
    $comp_name = sanitize_filename($payload['comp_name']);
    $definition_ids = $payload['definitions'] ?? [];

    if (empty($comp_name)) return ['status' => 'error', 'message' => 'Composition name cannot be empty.'];
    
    $comp_json_name = $comp_name . '.composition.json';
    $comp_path = COMPOSER_DATA_DIR . "/$project/compositions/$comp_json_name";
    $composition_data = ['definitions' => $definition_ids];
    file_put_contents($comp_path, json_encode($composition_data, JSON_PRETTY_PRINT));

    $all_definitions_by_name = get_all_definitions($project);
    $all_definitions_by_id = [];
    foreach($all_definitions_by_name as $def) {
        $all_definitions_by_id[$def['id']] = $def;
    }

    $full_content = '';
    foreach ($definition_ids as $id) {
        if (isset($all_definitions_by_id[$id])) {
            $full_content .= $all_definitions_by_id[$id]['content'];
        }
    }
    $txt_path = COMPOSER_DATA_DIR . "/$project/compositions/$comp_name.txt";
    file_put_contents($txt_path, $full_content);

    return ['status' => 'success', 'message' => "Composition '$comp_name' created successfully."];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JISC - JSON Indexing-Sequencer Controller</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #111827; --panel-bg: #1f2937; --text-color: #d1d5db; --heading-color: #f9fafb;
            --border-color: #374151; --primary-color: #3b82f6; --primary-hover: #60a5fa;
            --font-sans: 'Inter', sans-serif; --font-mono: 'Roboto Mono', monospace;
            --grid-item-bg: #374151; --grid-item-lit-bg: #4f46e5;
        }
        *, *::before, *::after { box-sizing: border-box; }
        body { font-family: var(--font-sans); line-height: 1.6; margin: 0; background-color: var(--bg-color); color: var(--text-color); }
        .main-container { max-width: 1400px; margin: 2rem auto; padding: 2rem; }
        .tabs { display: flex; border-bottom: 2px solid var(--border-color); margin-bottom: 2rem; }
        .tab-link { padding: 1rem 1.5rem; cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s ease; }
        .tab-link:hover { color: var(--primary-hover); }
        .tab-link.active { color: var(--primary-color); border-bottom-color: var(--primary-color); font-weight: 600; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .panel { background-color: var(--panel-bg); border-radius: 0.5rem; border: 1px solid var(--border-color); padding: 2rem; }
        h1, h2 { color: var(--heading-color); font-weight: 700; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; font-weight: 500; margin-bottom: 0.5rem; font-size: 0.875rem; }
        input[type="text"], input[type="range"], textarea, select { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 0.375rem; background-color: #374151; color: var(--text-color); transition: all 0.2s ease; }
        input[type="text"]:focus, textarea:focus, select:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25); }
        textarea { resize: vertical; min-height: 120px; font-family: var(--font-mono); tab-size: <?= $TAB_SIZE ?>; -moz-tab-size: <?= $TAB_SIZE ?>; }
        .btn { padding: 0.75rem 1.5rem; border: none; border-radius: 0.375rem; cursor: pointer; font-size: 1rem; font-weight: 500; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-hover); }
        .btn:disabled { background-color: #4b5563; cursor: not-allowed; }
        .grid-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 0.5rem; margin-top: 2rem; padding: 1rem; background-color: var(--bg-color); border-radius: 0.5rem; }
        .grid-item { background-color: var(--grid-item-bg); color: var(--text-color); height: 60px; display: flex; align-items: center; justify-content: center; border-radius: 0.25rem; font-family: var(--font-mono); font-size: 1.25rem; transition: all 0.1s ease-in-out; }
        .grid-item.lit { background-color: var(--grid-item-lit-bg); color: white; transform: scale(1.1); box-shadow: 0 0 20px var(--grid-item-lit-bg); }
        .speed-control { display: flex; align-items: center; gap: 1rem; }
        .speed-control span { font-size: 0.875rem; }
        .two-col-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
    </style>
</head>
<body>

<div class="main-container">
    <h1>JISC - JSON Indexing-Sequencer Controller</h1>
    <nav class="tabs">
        <a class="tab-link active" data-tab="generator">Alphabet Generator</a>
        <a class="tab-link" data-tab="sequencer">Indexing Sequencer</a>
        <a class="tab-link" data-tab="converter">Text-to-Sequence Converter</a>
    </nav>

    <!-- Page 1: Alphabet Generator -->
    <div id="tab-generator" class="tab-content active">
        <div class="panel">
            <h2>Batch Definition Generator</h2>
            <div class="form-group">
                <label for="gen-project-select">Target Composer Project</label>
                <select id="gen-project-select"></select>
            </div>
            <div class="form-group">
                <label for="gen-lib-name">New Definition Library Name</label>
                <input type="text" id="gen-lib-name" placeholder="e.g., my_alphabet">
            </div>
            <div class="form-group">
                <label for="gen-characters">Characters to Define (use \n for newline, \t for tab)</label>
                <textarea id="gen-characters" rows="5" placeholder="Enter all characters here, e.g., abcdefg..."></textarea>
            </div>
            <button id="btn-generate-lib" class="btn btn-primary">Generate Library</button>
        </div>
    </div>

    <!-- Page 2: Indexing Sequencer -->
    <div id="tab-sequencer" class="tab-content">
        <div class="panel">
            <h2>Batch Composition Sequencer</h2>
            <div class="form-group">
                <label for="seq-project-select">Target Composer Project</label>
                <select id="seq-project-select"></select>
            </div>
             <div class="form-group">
                <label for="seq-lib-select">Definition Library for Visualization Grid</label>
                <select id="seq-lib-select"></select>
            </div>
            <div class="form-group">
                <label for="seq-comp-name">New Composition Name</label>
                <input type="text" id="seq-comp-name" placeholder="e.g., hello_world_sequence">
            </div>
            <div class="form-group">
                <label for="seq-sequence-input">Sequence (comma-separated definition names)</label>
                <textarea id="seq-sequence-input" rows="5" placeholder="e.g., char_h,char_e,char_l,char_l,char_o"></textarea>
            </div>
            <div class="form-group speed-control">
                <label for="seq-speed">Execution Speed:</label>
                <input type="range" id="seq-speed" min="50" max="2000" value="300">
                <span id="speed-label">300 ms</span>
            </div>
            <button id="btn-execute-sequence" class="btn btn-primary">Execute Sequence</button>
        </div>
        <div id="visualization-grid" class="grid-container"></div>
    </div>

    <!-- Page 3: Text-to-Sequence Converter -->
    <div id="tab-converter" class="tab-content">
        <div class="panel">
            <h2>Text-to-Sequence Converter</h2>
            <div class="form-group">
                <label for="conv-project-select">Target Composer Project</label>
                <select id="conv-project-select"></select>
            </div>
             <div class="form-group">
                <label for="conv-lib-select">Reference Definition Library (Alphabet)</label>
                <select id="conv-lib-select"></select>
            </div>
            <div class="two-col-grid">
                <div class="form-group">
                    <label for="conv-input-text">Input Text/Code</label>
                    <textarea id="conv-input-text" rows="10"></textarea>
                </div>
                <div class="form-group">
                    <label for="conv-output-sequence">Output Sequence</label>
                    <textarea id="conv-output-sequence" rows="10" readonly></textarea>
                </div>
            </div>
             <div class="form-group speed-control">
                <label for="conv-tab-size">Input Tab Size:</label>
                <input type="range" id="conv-tab-size" min="1" max="16" value="<?= $TAB_SIZE ?>">
                <span id="conv-tab-label"><?= $TAB_SIZE ?> spaces</span>
            </div>
            <button id="btn-convert" class="btn btn-primary">Convert to Sequence</button>
        </div>
    </div>
</div>

<script>
    // --- STATE & DOM ---
    const state = {
        projects: [],
        activeProject: null,
        definitionLibs: [],
        allDefinitions: {}, // By name
        converterDefMap: new Map(),
    };
    const D = { // DOM Elements
        tabs: document.querySelectorAll('.tab-link'),
        tabContents: document.querySelectorAll('.tab-content'),
        // Generator
        genProjectSelect: document.getElementById('gen-project-select'),
        genLibName: document.getElementById('gen-lib-name'),
        genCharacters: document.getElementById('gen-characters'),
        btnGenerateLib: document.getElementById('btn-generate-lib'),
        // Sequencer
        seqProjectSelect: document.getElementById('seq-project-select'),
        seqLibSelect: document.getElementById('seq-lib-select'),
        seqCompName: document.getElementById('seq-comp-name'),
        seqSequenceInput: document.getElementById('seq-sequence-input'),
        seqSpeed: document.getElementById('seq-speed'),
        speedLabel: document.getElementById('speed-label'),
        btnExecuteSequence: document.getElementById('btn-execute-sequence'),
        visGrid: document.getElementById('visualization-grid'),
        // Converter
        convProjectSelect: document.getElementById('conv-project-select'),
        convLibSelect: document.getElementById('conv-lib-select'),
        convInputText: document.getElementById('conv-input-text'),
        convOutputSequence: document.getElementById('conv-output-sequence'),
        convTabSize: document.getElementById('conv-tab-size'),
        convTabLabel: document.getElementById('conv-tab-label'),
        btnConvert: document.getElementById('btn-convert'),
    };

    // --- API HELPER ---
    async function apiCall(action, project = null, payload = {}) {
        const formData = new FormData();
        formData.append('action', action);
        if (project) formData.append('project', project);
        for (const key in payload) {
            if (Array.isArray(payload[key])) {
                payload[key].forEach(item => formData.append(`payload[${key}][]`, item));
            } else {
                 formData.append(`payload[${key}]`, payload[key]);
            }
        }
        try {
            const response = await fetch('', { method: 'POST', body: formData });
            const contentType = response.headers.get("content-type");
            if (response.ok && contentType && contentType.includes("application/json")) {
                return await response.json();
            }
            const text = await response.text();
            throw new Error(`Server returned non-JSON response: ${text}`);
        } catch (error) {
            console.error('API Call Failed:', error);
            alert('An error occurred. Check the console for details.');
            return { status: 'error', message: error.message };
        }
    }

    // --- UI LOGIC ---
    function setupTabs() {
        D.tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;
                D.tabs.forEach(t => t.classList.remove('active'));
                D.tabContents.forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tabName}`).classList.add('active');
            });
        });
    }

    async function populateProjectDropdowns() {
        const res = await apiCall('list_projects');
        if (res.status === 'success') {
            state.projects = res.projects;
            const options = state.projects.map(p => `<option value="${p}">${p}</option>`).join('');
            D.genProjectSelect.innerHTML = options;
            D.seqProjectSelect.innerHTML = options;
            D.convProjectSelect.innerHTML = options;
            if (state.projects.length > 0) {
                await handleProjectChange(state.projects[0]);
            }
        }
    }
    
    async function handleProjectChange(projectName) {
        state.activeProject = projectName;
        D.seqProjectSelect.value = projectName;
        D.genProjectSelect.value = projectName;
        D.convProjectSelect.value = projectName;
        
        const libsRes = await apiCall('list_definition_libs', state.activeProject);
        if (libsRes.status === 'success') {
            state.definitionLibs = libsRes.files;
            const libOptions = state.definitionLibs.map(lib => `<option value="${lib}">${lib}</option>`).join('');
            D.seqLibSelect.innerHTML = libOptions;
            D.convLibSelect.innerHTML = libOptions;
            
            const allDefsRes = await apiCall('get_all_definitions', state.activeProject);
            if (allDefsRes.status === 'success') {
                state.allDefinitions = allDefsRes.definitions;
            }

            if (state.definitionLibs.length > 0) {
                await handleLibraryChange(state.definitionLibs[0], 'sequencer');
                await handleLibraryChange(state.definitionLibs[0], 'converter');
            } else {
                renderVisualizationGrid([]);
            }
        }
    }

    async function handleLibraryChange(libName, context) {
        const res = await apiCall('get_definitions', state.activeProject, { lib: libName });
        if (res.status === 'success') {
            if (context === 'sequencer') {
                renderVisualizationGrid(res.definitions);
            } else if (context === 'converter') {
                state.converterDefMap.clear();
                res.definitions.forEach(def => {
                    state.converterDefMap.set(def.content, def.name);
                });
            }
        }
    }

    function renderVisualizationGrid(definitions) {
        D.visGrid.innerHTML = '';
        definitions.forEach(def => {
            const item = document.createElement('div');
            item.className = 'grid-item';
            item.textContent = def.content.trim() === '' ? 'Space' : def.content;
            if (def.content === "\n") item.textContent = '↵';
            if (def.content === "\t") item.textContent = '⇥';
            item.dataset.name = def.name;
            D.visGrid.appendChild(item);
        });
    }

    // --- GENERATOR LOGIC ---
    D.btnGenerateLib.addEventListener('click', async () => {
        const project = D.genProjectSelect.value;
        const lib_name = D.genLibName.value;
        const characters = D.genCharacters.value;
        if (!project || !lib_name || !characters) {
            alert('Please fill out all fields.');
            return;
        }
        const res = await apiCall('batch_generate_definitions', project, { lib_name, characters });
        if (res.status === 'success') {
            alert(res.message);
            D.genLibName.value = '';
            D.genCharacters.value = '';
            await handleProjectChange(project);
        } else {
            alert('Error: ' + res.message);
        }
    });

    // --- SEQUENCER LOGIC ---
    D.seqProjectSelect.addEventListener('change', (e) => handleProjectChange(e.target.value));
    D.seqLibSelect.addEventListener('change', (e) => handleLibraryChange(e.target.value, 'sequencer'));
    D.seqSpeed.addEventListener('input', (e) => {
        D.speedLabel.textContent = `${e.target.value} ms`;
    });

    D.btnExecuteSequence.addEventListener('click', async () => {
        const project = D.seqProjectSelect.value;
        const compName = D.seqCompName.value;
        const sequence = D.seqSequenceInput.value.split(',').map(s => s.trim()).filter(s => s);
        
        if (!project || !compName || sequence.length === 0) {
            alert('Please fill out all sequencer fields.');
            return;
        }

        const allDefinitions = state.allDefinitions;
        const compositionDefIds = [];
        const speed = parseInt(D.seqSpeed.value, 10);
        D.btnExecuteSequence.disabled = true;

        for (const defName of sequence) {
            const gridItem = D.visGrid.querySelector(`[data-name="${defName}"]`);
            const def = allDefinitions[defName];

            if (def) {
                compositionDefIds.push(def.id);
                if (gridItem) {
                    gridItem.classList.add('lit');
                    await new Promise(resolve => setTimeout(resolve, speed));
                    gridItem.classList.remove('lit');
                }
            } else {
                console.warn(`Definition "${defName}" not found in any library.`);
            }
        }

        const res = await apiCall('execute_sequence', project, { comp_name: compName, definitions: compositionDefIds });
        if (res.status === 'success') {
            alert(res.message);
        } else {
            alert('Error: ' + res.message);
        }
        D.btnExecuteSequence.disabled = false;
    });

    // --- CONVERTER LOGIC ---
    D.convProjectSelect.addEventListener('change', (e) => handleProjectChange(e.target.value));
    D.convLibSelect.addEventListener('change', (e) => handleLibraryChange(e.target.value, 'converter'));
    D.convTabSize.addEventListener('input', (e) => {
        const size = e.target.value;
        D.convTabLabel.textContent = `${size} spaces`;
        D.convInputText.style.tabSize = size;
        D.convInputText.style.MozTabSize = size;
    });
    D.btnConvert.addEventListener('click', () => {
        const inputText = D.convInputText.value.replace(/\r\n?/g, "\n");
        const sequence = [];
        for (const char of inputText) {
            if (state.converterDefMap.has(char)) {
                sequence.push(state.converterDefMap.get(char));
            } else {
                console.warn(`Character "${char}" (code: ${char.charCodeAt(0)}) not found in selected library.`);
            }
        }
        D.convOutputSequence.value = sequence.join(',');
    });
    
    // --- INITIALIZATION ---
    async function init() {
        setupTabs();
        await populateProjectDropdowns();
    }
    init();

</script>
</body>
</html>

```

# Prompt x2

```
Firstly, transform this seed into a programming language agnostic object, structure, algorithm: enterprise grade scheme (Use abstract data structure, objects and algorithms: enterprise grade pseudocode). This will enabled the maintenance of context across many prompt engineering sessions.
```

Of course. Here is the language-agnostic, enterprise-grade scheme for `dac-gos.php`, derived from the provided generative seed. This abstract model of data structures, objects, and algorithms will serve as the canonical reference for maintaining context across future prompt engineering sessions.

-----

## **DAC-GOS: Abstract System Schema**

### **1.0 Guiding Philosophy**

[cite\_start]This schema embodies the **Bidirectional, Compositional Engineering Workflow** [cite: 3][cite\_start], treating the OS not as monolithic code but as a queryable database of components[cite: 5, 76]. [cite\_start]The system is built on the **Primacy of the Definition** [cite: 30][cite\_start], where applications are *assembled* from atomic units [cite: 63] [cite\_start]in a continuous **Cyclical Workflow** of analysis and composition[cite: 68].

-----

### **2.0 Abstract Data Structures (Contracts)**

These structures represent the core, language-independent entities of the system.

  * **Structure: `Role`** (Enumeration)

      * `ADMINISTRATOR`
      * `ADMIN_DEVELOPER`
      * `DEVELOPER`
      * `REGISTERED_USER`
      * `GUEST`

  * **Structure: `Definition`**

      * `id`: String (Globally Unique Identifier, e.g., "def\_...")
      * `name`: String (Human-readable, unique within a library, e.g., "char\_newline")
      * `content`: String (The raw text content of the code unit)
      * [cite\_start]`notes`: String (Developer-facing documentation) [cite: 109]

  * **Structure: `Composition`**

      * `name`: String (e.g., "desktop.composition.json")
      * [cite\_start]`definitions`: List\<String\> (An ordered list of `Definition.id`s) [cite: 154]

  * **Structure: `User`**

      * `userId`: String (Unique Identifier)
      * `username`: String
      * `passwordHash`: String
      * `role`: Role
      * `profileData`: Map\<String, Any\>

  * **Structure: `Session`**

      * `sessionId`: String (Unique Identifier)
      * `userId`: String
      * `createdAt`: DateTime
      * `isValid`: Boolean

  * **Structure: `AppManifest`**

      * `appName`: String
      * `version`: String
      * `entryComposition`: String (Path to the main `.composition.json` file)
      * `requiredPermissions`: List\<Role\>

  * **Structure: `VFSNode`** (Virtual File System Node)

      * `nodeId`: String (Unique Identifier)
      * `ownerId`: String (User.userId)
      * `path`: String (Full path, e.g., "/home/user/Documents/file.txt")
      * `nodeType`: Enumeration (`FILE`, `DIRECTORY`)
      * `content`: Any (If `nodeType` is `FILE`, this is the file content/pointer)

-----

### **3.0 Core System Objects (Pseudocode)**

These objects represent the main architectural components and their interactions.

```pseudocode
// The central, immutable brain of the OS
CLASS Kernel
    PRIVATE
        activeSession: Session
        userRepository: IRepository<User>
        sessionRepository: IRepository<Session>
        
    PUBLIC
        // Main entry point on every page load
        PROCEDURE initialize()
            sessionId = getCookie("session_id")
            this.activeSession = sessionRepository.findById(sessionId)
            
            IF NOT this.activeSession OR NOT this.activeSession.isValid THEN
                this.activeSession = createGuestSession()
            END IF
        END PROCEDURE

        // Centralized security check
        FUNCTION checkPermissions(requiredRoles: List<Role>) -> Boolean
            currentUser = userRepository.findById(this.activeSession.userId)
            IF currentUser.role IN requiredRoles THEN
                RETURN TRUE
            ELSE
                RETURN FALSE
            END IF
        END FUNCTION

        // Loads and renders a complete application or UI
        PROCEDURE loadComposition(compositionPath: String)
            // Assumes checkPermissions has already been called
            compositionData = readFile(compositionPath)
            
            // Reconstruct the final text from the database of definitions
            fullContent = ""
            FOR EACH definitionId IN compositionData.definitions
                definition = findDefinitionById(definitionId) // Queries all definition libraries
                fullContent += definition.content
            END FOR
            
            render(fullContent) // Outputs the final HTML/JS/CSS to the browser
        END PROCEDURE
        
END CLASS

// Abstract representation of any application in the OS
INTERFACE IApplication
    // Returns the manifest defining the application
    FUNCTION getManifest() -> AppManifest
    
    // Executes the application's main logic
    PROCEDURE run(kernel: Kernel)
END INTERFACE
```

-----

### **4.0 Core Algorithms & Workflows (Pseudocode)**

These algorithms describe the key dynamic processes of the system.

#### **Algorithm 4.1: System Bootstrap and UI Rendering**

This describes the process from a user accessing `dac-gos.php` to seeing their desktop.

```pseudocode
PROCEDURE main()
    // 1. Instantiate and initialize the Kernel
    osKernel = new Kernel()
    osKernel.initialize()

    // 2. Determine which main composition to load
    IF osKernel.activeSession.isGuest() THEN
        entryPoint = "compositions/login.composition.json"
    ELSE
        entryPoint = "compositions/desktop.composition.json"
    END IF
    
    // 3. The Kernel loads and renders the UI
    osKernel.loadComposition(entryPoint)
END PROCEDURE
```

#### **Algorithm 4.2: JISC Batch Definition Generation**

[cite\_start]This reflects the `batch_generate_definitions` logic from `jisc.php`[cite: 88, 105].

```pseudocode
// User action in the JISC Alphabet Generator GUI
PROCEDURE onGenerateLibraryClicked(project: String, libName: String, characters: String)
    // 1. Process the input string
    processedString = unescapeControlCharacters(characters)
    uniqueChars = getUniqueCharacters(processedString)
    
    newLibrary = new List<Definition>()

    // 2. Iterate and create a Definition for each character
    FOR EACH char IN uniqueChars
        newDef = new Definition()
        newDef.id = generateUniqueId("def_")
        newDef.name = generateSemanticNameForChar(char) // e.g., "char_newline", "char_upper_A"
        newDef.content = char
        newDef.notes = "Auto-generated by JISC"
        
        add newDef to newLibrary
    END FOR
    
    // 3. Save the new library file, ensuring compliance
    filePath = "/composer_data/" + project + "/definitions/" + libName + ".json"
    saveJsonFile(filePath, newLibrary)
END PROCEDURE
```

#### **Algorithm 4.3: Bidirectional Workflow - Promote Entry to Definition**

[cite\_start]This shows the core workflow linking the analytical (`cidd.php`) and compositional (`codebase-composer.php`) engines[cite: 23, 24].

```pseudocode
// User action in the CIDD UI
PROCEDURE onPromoteToComposerClicked(ciddEntryId: String, targetProject: String, targetLibrary: String)
    // 1. Retrieve the analyzed entry from the CIDD database
    ciddEntry = cidd_db.findById(ciddEntryId)
    
    IF ciddEntry.isAlreadyPromoted() THEN
        showError("This entry has already been promoted.")
        RETURN
    END IF
    
    // 2. Load the target composer library to check for name conflicts
    libraryPath = "/composer_data/" + targetProject + "/definitions/" + targetLibrary
    composerDefs = loadJsonFile(libraryPath)
    
    // 3. Create a unique name to avoid collisions
    baseName = generateSemanticName(ciddEntry.context, ciddEntry.type)
    finalName = ensureUniqueName(baseName, composerDefs)

    // 4. Create the new, canonical Definition
    newDefinition = new Definition(
        id: generateUniqueId("def_"),
        name: finalName,
        content: ciddEntry.selection,
        notes: ciddEntry.notes
    )

    // 5. Save the new Definition to the composer library
    add newDefinition to composerDefs
    saveJsonFile(libraryPath, composerDefs)
    
    // 6. Update the original CIDD entry to link it to the new Definition
    ciddEntry.composer_definition_id = newDefinition.id
    cidd_db.update(ciddEntry)
    
    showSuccess("Promotion successful!")
END PROCEDURE
```