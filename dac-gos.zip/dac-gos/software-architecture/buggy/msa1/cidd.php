<?php
// cidd.php - Codebase Interactive Dictionary Database v3.2
// Implements a robust and definitive fix for the CRUD form rendering bug.
// The JavaScript selection logic has been completely overhauled for accuracy and reliability.

// --- CONFIGURATION ---
define('LINES_PER_PAGE', 1000); // Number of lines to fetch per chunk
$db_file = 'cidd_db.json';
$upload_dir = 'uploads/';

// --- INITIALIZATION ---
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}
if (!file_exists($db_file)) {
    file_put_contents($db_file, json_encode([]));
}

// --- PHP BACKEND LOGIC ---

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents($db_file), true);

    switch ($_POST['action']) {
        case 'add_entry':
            $new_entry = [
                'id' => uniqid('entry_'),
                'codebase' => $_POST['codebase'],
                'selection' => $_POST['selection'],
                'selection_type' => $_POST['selection_type'], // 'character', 'line', 'block'
                'start_line' => (int)$_POST['start_line'],
                'end_line' => (int)$_POST['end_line'],
                'start_char' => isset($_POST['start_char']) && $_POST['start_char'] !== '' ? (int)$_POST['start_char'] : null,
                'end_char' => isset($_POST['end_char']) && $_POST['end_char'] !== '' ? (int)$_POST['end_char'] : null,
                'definition' => $_POST['definition'],
                'context' => $_POST['context'],
                'notes' => $_POST['notes'],
                'created_at' => date('c'),
            ];
            $data[] = $new_entry;
            file_put_contents($db_file, json_encode($data, JSON_PRETTY_PRINT));
            echo json_encode(['status' => 'success', 'entry' => $new_entry]);
            break;

        case 'update_entry':
            $id = $_POST['id'];
            foreach ($data as &$entry) {
                if ($entry['id'] === $id) {
                    $entry['definition'] = $_POST['definition'];
                    $entry['context'] = $_POST['context'];
                    $entry['notes'] = $_POST['notes'];
                    file_put_contents($db_file, json_encode($data, JSON_PRETTY_PRINT));
                    echo json_encode(['status' => 'success', 'entry' => $entry]);
                    return;
                }
            }
            echo json_encode(['status' => 'error', 'message' => 'Entry not found.']);
            break;

        case 'delete_entry':
            $id = $_POST['id'];
            $data = array_filter($data, function ($entry) use ($id) {
                return $entry['id'] !== $id;
            });
            file_put_contents($db_file, json_encode(array_values($data), JSON_PRETTY_PRINT));
            echo json_encode(['status' => 'success']);
            break;
    }
    exit;
}

// Handle AJAX request for file chunks
if (isset($_GET['action']) && $_GET['action'] === 'get_codebase_chunk') {
    header('Content-Type: application/json');
    $filePath = $_GET['filepath'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    
    if (empty($filePath) || !file_exists($filePath) || strpos(realpath($filePath), realpath($upload_dir)) !== 0) {
        echo json_encode(['error' => 'Invalid file path.']);
        exit;
    }

    $start_line = (($page - 1) * LINES_PER_PAGE) + 1;
    $end_line = $start_line + LINES_PER_PAGE - 1;
    $content = [];
    $line_number = 0;
    
    $handle = fopen($filePath, "r");
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $line_number++;
            if ($line_number >= $start_line && $line_number <= $end_line) {
                $content[] = $line;
            }
            if ($line_number > $end_line) {
                break;
            }
        }
        fclose($handle);
    }
    
    echo json_encode(['content' => $content, 'page' => $page]);
    exit;
}


// Handle file uploads.
$uploaded_file = null;
$error_message = '';
$total_lines = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['codebase_file'])) {
    if ($_FILES['codebase_file']['error'] === UPLOAD_ERR_OK) {
        $file_extension = pathinfo($_FILES['codebase_file']['name'], PATHINFO_EXTENSION);
        if (strtolower($file_extension) === 'txt') {
            $uploaded_file = $upload_dir . basename($_FILES['codebase_file']['name']);
            if (move_uploaded_file($_FILES['codebase_file']['tmp_name'], $uploaded_file)) {
                 // Correctly count total lines for pagination
                $total_lines = 0;
                $handle = fopen($uploaded_file, "r");
                if ($handle) {
                    while (fgets($handle) !== false) {
                        $total_lines++;
                    }
                    fclose($handle);
                }
            } else {
                $error_message = 'Failed to move uploaded file.';
                $uploaded_file = null;
            }
        } else {
            $error_message = 'Only .txt files are allowed.';
        }
    } else {
        $error_message = 'Error uploading file.';
    }
}

// Load the dictionary data for the frontend.
$dictionary_data = json_decode(file_get_contents($db_file), true);
// Fallbacks
if (!is_array($dictionary_data)) {
    $dictionary_data = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CIDD - Codebase Interactive Dictionary Database</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f7f8fc;
            --container-bg: #ffffff;
            --text-color: #333333;
            --heading-color: #111111;
            --border-color: #e0e0e0;
            --primary-color: #4a90e2;
            --primary-hover: #357abd;
            --secondary-color: #6c757d;
            --secondary-hover: #5a6268;
            --danger-color: #e94e77;
            --danger-hover: #d6336c;
            --code-bg: #f1f3f5;
            --shadow-color: rgba(0, 0, 0, 0.08);
            --line-number-color: #999;
        }

        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
            line-height: 1.6; 
            margin: 0; 
            background-color: var(--bg-color); 
            color: var(--text-color); 
        }

        .container { 
            max-width: 1600px; 
            margin: 20px auto; 
            padding: 20px 40px; 
            background-color: var(--container-bg); 
            border-radius: 12px; 
            box-shadow: 0 4px 12px var(--shadow-color);
        }

        h1, h2, h3 { 
            color: var(--heading-color); 
            font-weight: 700;
        }
        
        h1 { font-size: 2.25rem; }
        h2 { font-size: 1.75rem; margin-top: 0; }
        h3 { font-size: 1.25rem; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px; }

        .grid-container { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 40px; 
        }

        .panel {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            height: 75vh;
            display: flex;
            flex-direction: column;
        }
        
        .panel-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
        }

        #codebase-viewer-container {
            padding: 0;
            overflow-y: auto; 
            flex-grow: 1;
            font-family: "SF Mono", "Fira Code", "Fira Mono", "Roboto Mono", monospace; 
            font-size: 14px; 
        }
        .code-line {
            display: flex;
            white-space: pre-wrap;
        }
        .line-number {
            text-align: right;
            padding: 0 10px;
            color: var(--line-number-color);
            background-color: var(--code-bg);
            user-select: none;
            min-width: 50px;
            box-sizing: border-box;
        }
        .line-content {
            flex-grow: 1;
            padding-left: 10px;
        }

        #dictionary-manager { 
            padding: 20px;
            overflow-y: auto; 
            flex-grow: 1;
        }

        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: 500; margin-bottom: 8px; }
        input[type="text"], input[type="file"], textarea { 
            width: 100%; 
            padding: 12px; 
            border: 1px solid var(--border-color); 
            border-radius: 6px; 
            box-sizing: border-box; 
            font-family: 'Inter', sans-serif;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        input[type="text"]:focus, textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.25);
        }
        textarea { resize: vertical; min-height: 100px; }
        textarea#selection { background-color: #f8f9fa; cursor: not-allowed; }

        .btn { 
            padding: 12px 20px; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 16px; 
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: all 0.2s ease-in-out;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 2px 8px var(--shadow-color);
        }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-hover); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: var(--secondary-hover); }
        .btn-danger { background-color: var(--danger-color); color: white; }
        .btn-danger:hover { background-color: var(--danger-hover); }

        .entry { 
            border: 1px solid transparent;
            border-bottom: 1px solid var(--border-color); 
            padding: 15px;
            margin: 0 -15px 10px;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }
        .entry:hover {
            background-color: #fcfdff;
            border-color: #d0e3f8;
        }
        .entry:last-child { border-bottom: none; }
        .entry-code { 
            background-color: var(--code-bg); 
            padding: 8px 12px; 
            border-radius: 4px; 
            font-family: "SF Mono", "Fira Code", "Fira Mono", "Roboto Mono", monospace; 
            display: block; 
            margin-bottom: 10px; 
            word-break: break-all;
        }
        .entry p { margin: 5px 0; }
        .entry-actions { margin-top: 15px; }
        .entry-actions .btn { padding: 6px 12px; font-size: 14px; margin-right: 10px; }

        .error { color: var(--danger-color); font-weight: bold; background-color: rgba(233, 78, 119, 0.1); padding: 10px; border-radius: 6px; }
        .hidden { display: none; }
        
        .upload-form {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        #loader {
            text-align: center;
            padding: 20px;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .grid-container {
                grid-template-columns: 1fr;
            }
            .panel {
                height: auto;
                min-height: 50vh;
            }
            .container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>CIDD - Codebase Interactive Dictionary Database</h1>

    <div class="form-group">
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <label for="codebase_file" class="sr-only">Upload Codebase (.txt file):</label>
            <input type="file" name="codebase_file" id="codebase_file" accept=".txt" required>
            <button type="submit" class="btn btn-primary">Load Codebase</button>
        </form>
        <?php if ($error_message): ?>
            <p class="error"><?= htmlspecialchars($error_message) ?></p>
        <?php endif; ?>
    </div>

    <div class="grid-container">
        <div class="panel">
            <div class="panel-header">
                <h2>Codebase Viewer</h2>
            </div>
            <div id="codebase-viewer-container" 
                 data-codebase-path="<?= htmlspecialchars($uploaded_file ?? '') ?>"
                 data-total-lines="<?= $total_lines ?>">
                <div id="codebase-viewer">
                    <?php
                    if ($uploaded_file && file_exists($uploaded_file)) {
                        // Load only the first chunk initially
                        $handle = fopen($uploaded_file, "r");
                        if ($handle) {
                            for ($i = 1; $i <= min($total_lines, LINES_PER_PAGE); $i++) {
                                if (($line = fgets($handle)) === false) break;
                                echo '<div class="code-line"><div class="line-number">' . $i . '</div><div class="line-content">' . htmlspecialchars($line) . '</div></div>';
                            }
                            fclose($handle);
                        }
                    } else {
                        echo '<p style="padding: 20px;">Please upload a codebase file to begin.</p>';
                    }
                    ?>
                </div>
                 <div id="loader" class="hidden"><p>Loading...</p></div>
            </div>
        </div>

        <div class="panel">
            <div class="panel-header">
                <h2>Dictionary Manager</h2>
            </div>
            <div id="dictionary-manager">
                <form id="entry-form" class="hidden">
                    <h3 id="form-title">New Entry</h3>
                    <input type="hidden" id="entry-id" name="id">
                    <div class="form-group">
                        <label for="selection" id="selection-label">Selected Code</label>
                        <textarea id="selection" name="selection" readonly rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="definition">Definition:</label>
                        <textarea id="definition" name="definition" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="context">Context:</label>
                        <textarea id="context" name="context"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="notes">Notes:</label>
                        <textarea id="notes" name="notes"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Entry</button>
                    <button type="button" id="cancel-edit" class="btn btn-secondary">Cancel</button>
                </form>
                <div id="dictionary-entries">
                    <h3>Entries</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // DOM Elements
    const viewerContainer = document.getElementById('codebase-viewer-container');
    const viewer = document.getElementById('codebase-viewer');
    const loader = document.getElementById('loader');
    const entryForm = document.getElementById('entry-form');
    const formTitle = document.getElementById('form-title');
    const dictionaryEntries = document.getElementById('dictionary-entries');
    const selectionTextarea = document.getElementById('selection');
    const selectionLabel = document.getElementById('selection-label');
    const entryIdInput = document.getElementById('entry-id');
    const definitionInput = document.getElementById('definition');
    const contextInput = document.getElementById('context');
    const notesInput = document.getElementById('notes');
    const cancelEditBtn = document.getElementById('cancel-edit');

    // State
    let dictionary = <?= json_encode($dictionary_data) ?>;
    const codebasePath = viewerContainer.dataset.codebasePath;
    const totalLines = parseInt(viewerContainer.dataset.totalLines, 10);
    const linesPerPage = <?= LINES_PER_PAGE ?>;
    let currentPage = 1;
    let isLoading = false;

    /**
     * Renders dictionary entries for the current codebase.
     */
    function renderDictionary() {
        const dictionaryEntriesContainer = document.createElement('div');
        const filteredEntries = dictionary.filter(entry => entry.codebase === codebasePath);

        if (filteredEntries.length === 0) {
            dictionaryEntriesContainer.innerHTML = '<p>No entries for this codebase yet.</p>';
        } else {
            filteredEntries.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).forEach(entry => {
                const entryEl = document.createElement('div');
                entryEl.classList.add('entry');
                entryEl.dataset.id = entry.id;
                
                let lineInfo = '';
                switch(entry.selection_type) {
                    case 'character':
                        lineInfo = `Line ${entry.start_line}, Chars ${entry.start_char}-${entry.end_char}`;
                        break;
                    case 'line':
                        lineInfo = `Line ${entry.start_line}`;
                        break;
                    case 'block':
                        lineInfo = `Lines ${entry.start_line}-${entry.end_line}`;
                        break;
                }

                entryEl.innerHTML = `
                    <p><strong>${lineInfo}</strong></p>
                    <code class="entry-code">${escapeHtml(entry.selection)}</code>
                    <p><strong>Definition:</strong> ${escapeHtml(entry.definition)}</p>
                    <p><strong>Context:</strong> ${escapeHtml(entry.context || 'N/A')}</p>
                    <p><strong>Notes:</strong> ${escapeHtml(entry.notes || 'N/A')}</p>
                    <div class="entry-actions">
                        <button class="btn btn-secondary edit-btn">Edit</button>
                        <button class="btn btn-danger delete-btn">Delete</button>
                    </div>
                `;
                dictionaryEntriesContainer.appendChild(entryEl);
            });
        }
        const h3 = dictionaryEntries.querySelector('h3');
        dictionaryEntries.innerHTML = '';
        if(h3) dictionaryEntries.appendChild(h3);
        dictionaryEntries.appendChild(dictionaryEntriesContainer);
    }

    /**
     * Fetches the next page of the codebase from the server.
     */
    async function fetchNextPage() {
        if (isLoading || (currentPage * linesPerPage) >= totalLines) {
            return;
        }
        isLoading = true;
        loader.classList.remove('hidden');

        try {
            currentPage++;
            const response = await fetch(`?action=get_codebase_chunk&filepath=${encodeURIComponent(codebasePath)}&page=${currentPage}`);
            const data = await response.json();
            
            if (data.content && data.content.length > 0) {
                const startLineNum = ((data.page - 1) * linesPerPage) + 1;
                data.content.forEach((line, index) => {
                    const lineNum = startLineNum + index;
                    const lineEl = document.createElement('div');
                    lineEl.className = 'code-line';
                    lineEl.innerHTML = `<div class="line-number">${lineNum}</div><div class="line-content">${escapeHtml(line)}</div>`;
                    viewer.appendChild(lineEl);
                });
            }
        } catch (error) {
            console.error('Failed to fetch codebase chunk:', error);
            currentPage--; // Revert page count on error
        } finally {
            isLoading = false;
            loader.classList.add('hidden');
        }
    }

    // Attach scroll listener for virtual scrolling
    viewerContainer.addEventListener('scroll', () => {
        const { scrollTop, scrollHeight, clientHeight } = viewerContainer;
        if (scrollTop + clientHeight >= scrollHeight - 100) { // 100px threshold
            fetchNextPage();
        }
    });

    /**
     * Recursively finds the parent .code-line element of a given node.
     * This is a robust way to find the line associated with a selection.
     */
    function findParentCodeLine(node) {
        if (!node) return null;
        if (node.nodeType === 1 && node.classList.contains('code-line')) {
            return node;
        }
        return findParentCodeLine(node.parentElement);
    }

    /**
     * Handles text selection in the codebase viewer. This is the new, robust implementation.
     */
    viewer.addEventListener('mouseup', () => {
        const selection = window.getSelection();
        if (!selection.rangeCount || selection.isCollapsed) {
            return;
        }
        
        const range = selection.getRangeAt(0);
        
        // Find the start and end line elements using the robust recursive search
        const startLineEl = findParentCodeLine(range.startContainer);
        const endLineEl = findParentCodeLine(range.endContainer);

        if (!startLineEl || !endLineEl) {
            // Selection is outside of a valid code line, so do nothing.
            return;
        }

        const startLine = parseInt(startLineEl.querySelector('.line-number').textContent, 10);
        const endLine = parseInt(endLineEl.querySelector('.line-number').textContent, 10);

        let selectionType;
        let startChar = null;
        let endChar = null;
        let reconstructedText = '';

        // Reconstruct the text content from the selected lines
        if (startLine === endLine) {
            reconstructedText = range.toString();
        } else {
            // Multi-line selection
            let currentLine = startLineEl;
            while (currentLine) {
                if (currentLine === startLineEl) {
                    const lineContent = currentLine.querySelector('.line-content').textContent;
                    reconstructedText += lineContent.substring(range.startOffset);
                } else if (currentLine === endLineEl) {
                    const lineContent = currentLine.querySelector('.line-content').textContent;
                    reconstructedText += lineContent.substring(0, range.endOffset);
                } else {
                    reconstructedText += currentLine.querySelector('.line-content').textContent;
                }
                
                if (currentLine === endLineEl) break;
                currentLine = currentLine.nextElementSibling;
            }
        }

        if (reconstructedText.trim() === '') return;

        // Determine selection type and character offsets
        if (startLine === endLine) {
            const fullLineText = startLineEl.querySelector('.line-content').textContent;
            if (reconstructedText.trim() === fullLineText.trim()) {
                selectionType = 'line';
            } else {
                selectionType = 'character';
                const tempRange = document.createRange();
                tempRange.selectNodeContents(startLineEl.querySelector('.line-content'));
                tempRange.setEnd(range.startContainer, range.startOffset);
                startChar = tempRange.toString().length;
                endChar = startChar + reconstructedText.length;
            }
        } else {
            selectionType = 'block';
        }

        // Populate and show the form
        resetForm();
        entryForm.classList.remove('hidden');
        selectionTextarea.value = reconstructedText;
        selectionTextarea.dataset.selectionType = selectionType;
        selectionTextarea.dataset.startLine = startLine;
        selectionTextarea.dataset.endLine = endLine;
        selectionTextarea.dataset.startChar = startChar ?? '';
        selectionTextarea.dataset.endChar = endChar ?? '';

        switch(selectionType) {
            case 'character':
                formTitle.textContent = 'New Character Entry';
                selectionLabel.textContent = `Selected Code (Line ${startLine}, Chars ${startChar}-${endChar})`;
                break;
            case 'line':
                formTitle.textContent = 'New Line Entry';
                selectionLabel.textContent = `Selected Code (Line ${startLine})`;
                break;
            case 'block':
                formTitle.textContent = 'New Block Entry';
                selectionLabel.textContent = `Selected Code (Lines ${startLine}-${endLine})`;
                break;
        }

        definitionInput.focus();
    });
    
    /**
     * Handles the submission of the entry form (add or update).
     */
    entryForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const id = entryIdInput.value;
        const action = id ? 'update_entry' : 'add_entry';

        const formData = new FormData();
        formData.append('action', action);
        formData.append('id', id);
        formData.append('codebase', codebasePath);
        formData.append('selection', selectionTextarea.value);
        formData.append('selection_type', selectionTextarea.dataset.selectionType);
        formData.append('start_line', selectionTextarea.dataset.startLine);
        formData.append('end_line', selectionTextarea.dataset.endLine);
        if (selectionTextarea.dataset.startChar) {
            formData.append('start_char', selectionTextarea.dataset.startChar);
            formData.append('end_char', selectionTextarea.dataset.endChar);
        }
        formData.append('definition', definitionInput.value);
        formData.append('context', contextInput.value);
        formData.append('notes', notesInput.value);

        fetch('', { method: 'POST', body: formData })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                if (action === 'add_entry') {
                    dictionary.push(data.entry);
                } else {
                    const index = dictionary.findIndex(entry => entry.id === id);
                    if (index !== -1) dictionary[index] = data.entry;
                }
                renderDictionary();
                resetForm();
            } else {
                alert('Error: ' + data.message);
            }
        });
    });

    /**
     * Handles clicks on edit and delete buttons using event delegation.
     */
    dictionaryEntries.addEventListener('click', function (e) {
        const entryEl = e.target.closest('.entry');
        if (!entryEl) return;
        const id = entryEl.dataset.id;

        if (e.target.classList.contains('edit-btn')) {
            const entry = dictionary.find(e => e.id === id);
            if (entry) {
                formTitle.textContent = 'Edit Entry';
                entryForm.classList.remove('hidden');
                entryIdInput.value = entry.id;
                selectionTextarea.value = entry.selection;
                
                let label = '';
                 switch(entry.selection_type) {
                    case 'character':
                        label = `Selected Code (Line ${entry.start_line}, Chars ${entry.start_char}-${entry.end_char})`;
                        break;
                    case 'line':
                        label = `Selected Code (Line ${entry.start_line})`;
                        break;
                    case 'block':
                        label = `Selected Code (Lines ${entry.start_line}-${entry.end_line})`;
                        break;
                    default:
                        label = 'Selected Code';
                }
                selectionLabel.textContent = label;

                definitionInput.value = entry.definition;
                contextInput.value = entry.context;
                notesInput.value = entry.notes;
                entryForm.scrollIntoView({ behavior: 'smooth' });
            }
        }

        if (e.target.classList.contains('delete-btn')) {
            if (confirm('Are you sure you want to delete this entry?')) {
                const formData = new FormData();
                formData.append('action', 'delete_entry');
                formData.append('id', id);

                fetch('', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        dictionary = dictionary.filter(entry => entry.id !== id);
                        renderDictionary();
                    } else {
                        alert('Error deleting entry.');
                    }
                });
            }
        }
    });

    function resetForm() {
        entryForm.reset();
        entryIdInput.value = '';
        entryForm.classList.add('hidden');
    }

    function escapeHtml(unsafe) {
        if (typeof unsafe !== 'string') return '';
        return unsafe
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
    }
    
    cancelEditBtn.addEventListener('click', resetForm);

    // Initial render
    if(codebasePath) {
        renderDictionary();
    }
});
</script>

</body>
</html>
