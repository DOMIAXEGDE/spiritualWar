<?php
// ide.php - A standalone text editor and definition creation tool for the Codebase Composer system.
// Version 1.0
// This module provides a text editing interface and allows for the promotion
// of its content into the codebase-composer.php data structure as a new definition.
// It does not modify codebase-composer.php or cidd.php.

// --- CONFIGURATION ---
define('COMPOSER_DATA_DIR', __DIR__ . '/composer_data');

// --- UTILITY FUNCTIONS (Required for interacting with Composer data) ---
function sanitize_filename($filename) {
    $sanitized = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $filename);
    return preg_replace('/_+/', '_', $sanitized);
}

// --- API ROUTER ---
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    switch ($action) {
        case 'list_composer_projects':
            $projects = [];
            if (is_dir(COMPOSER_DATA_DIR)) {
                $items = array_diff(scandir(COMPOSER_DATA_DIR), ['..', '.']);
                foreach ($items as $item) {
                    if (is_dir(COMPOSER_DATA_DIR . '/' . $item)) $projects[] = $item;
                }
            }
            echo json_encode(['status' => 'success', 'projects' => $projects]);
            break;

        case 'list_composer_libs':
            $project = $_POST['project'] ?? '';
            $files = [];
            if ($project) {
                $dir_path = COMPOSER_DATA_DIR . "/" . sanitize_filename($project) . "/definitions";
                if (is_dir($dir_path)) {
                    $items = array_diff(scandir($dir_path), ['..', '.']);
                    foreach ($items as $item) {
                        if (pathinfo($item, PATHINFO_EXTENSION) === 'json') $files[] = $item;
                    }
                }
            }
            echo json_encode(['status' => 'success', 'files' => $files]);
            break;

        case 'promote_to_composer':
            $project = $_POST['project'];
            $library = $_POST['library'];
            $name = $_POST['name'];
            $content = $_POST['content'];

            if (empty($project) || empty($library) || empty($name) || !isset($content)) {
                echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
                exit;
            }

            $lib_path = COMPOSER_DATA_DIR . "/" . sanitize_filename($project) . "/definitions/" . sanitize_filename($library);
            if (!file_exists($lib_path)) {
                echo json_encode(['status' => 'error', 'message' => 'Composer library not found.']);
                exit;
            }

            $composer_defs = json_decode(file_get_contents($lib_path), true);
            if (!is_array($composer_defs)) $composer_defs = [];

            // Ensure unique name
            $base_name = sanitize_filename($name);
            $final_name = $base_name;
            $counter = 2;
            while (true) {
                $name_exists = false;
                foreach ($composer_defs as $def) { if ($def['name'] === $final_name) { $name_exists = true; break; } }
                if (!$name_exists) break;
                $final_name = $base_name . '_' . $counter++;
            }

            $new_def = [
                'id' => 'def_' . uniqid(),
                'name' => $final_name,
                'content' => $content,
                'notes' => 'Created from ide.php @ ' . date('c')
            ];

            $composer_defs[] = $new_def;
            file_put_contents($lib_path, json_encode($composer_defs, JSON_PRETTY_PRINT));

            echo json_encode(['status' => 'success', 'message' => "Definition '{$final_name}' successfully created."]);
            break;
    }
    exit;
}

$is_composer_present = is_dir(COMPOSER_DATA_DIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IDE Module</title>
  <style>
    :root {
      --bg-color: #1e1e2e; --text-color: #cdd6f4; --accent-color: #89b4fa;
      --border-color: #313244; --focus-color: #f5c2e7; --input-bg-color: #282a36;
      --panel-bg: #181825; --danger-color: #f38ba8; --success-color: #a6e3a1;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace; background-color: var(--bg-color); color: var(--text-color); display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
    .editor-container { width: 90%; max-width: 900px; display: flex; flex-direction: column; gap: 15px; }
    .controls { display: flex; align-items: center; justify-content: space-between; gap: 10px; font-size: 14px; background-color: var(--panel-bg); padding: 10px 15px; border-radius: 8px; border: 1px solid var(--border-color); }
    .controls-left { display: flex; align-items: center; gap: 15px; }
    #tab-size-input { background-color: var(--input-bg-color); color: var(--text-color); border: 1px solid var(--border-color); border-radius: 4px; padding: 5px 8px; width: 60px; font-family: inherit; }
    #tab-size-input:focus { outline: none; border-color: var(--focus-color); }
    #prompt-text { width: 100%; height: 75vh; background-color: var(--input-bg-color); color: var(--text-color); border: 2px solid var(--border-color); border-radius: 8px; padding: 20px; font-size: 16px; line-height: 1.6; resize: vertical; box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3); transition: all 0.3s ease; white-space: pre; overflow-x: auto; }
    #prompt-text:focus { outline: none; border-color: var(--focus-color); box-shadow: 0 0 0 3px rgba(245, 194, 231, 0.3); }
    .btn { padding: 8px 15px; border: 1px solid var(--accent-color); border-radius: 5px; cursor: pointer; font-size: 14px; font-weight: 500; font-family: inherit; text-decoration: none; transition: all 0.2s ease; background-color: var(--accent-color); color: var(--bg-color); }
    .btn:hover { opacity: 0.9; }
    .btn:disabled { background-color: #585b70; border-color: #585b70; cursor: not-allowed; }
    .modal { display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); }
    .modal-content { background-color: var(--panel-bg); margin: 15% auto; padding: 2rem; border-radius: 0.5rem; width: 90%; max-width: 500px; border: 1px solid var(--border-color); }
    .modal-header { padding-bottom: 1rem; margin-bottom: 1rem; font-size: 1.25rem; font-weight: bold; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; margin-bottom: 0.5rem; font-size: 0.875rem; }
    .form-group input, .form-group select { width: 100%; padding: 0.625rem; border: 1px solid var(--border-color); border-radius: 0.375rem; background-color: var(--input-bg-color); color: var(--text-color); font-family: inherit; }
    .modal-actions { margin-top: 1.5rem; display: flex; justify-content: flex-end; gap: 1rem; }
  </style>
</head>
<body>

  <div class="editor-container">
    <div class="controls">
        <div class="controls-left">
          <label for="tab-size-input">Tab Size:</label>
          <input type="number" id="tab-size-input" value="4" min="1" max="16">
        </div>
        <button id="btn-push-composer" class="btn" <?= !$is_composer_present ? 'disabled' : '' ?>>Push to Composer</button>
    </div>
    <textarea id="prompt-text" placeholder="Enter code or content here..."></textarea>
  </div>

  <div id="promotion-modal" class="modal">
      <div class="modal-content">
          <div class="modal-header">Push to Composer</div>
          <div class="form-group">
              <label for="composer-projects">Select Project:</label>
              <select id="composer-projects"></select>
          </div>
          <div class="form-group">
              <label for="composer-libs">Select Definition Library:</label>
              <select id="composer-libs"></select>
          </div>
          <div class="form-group">
              <label for="definition-name">New Definition Name:</label>
              <input type="text" id="definition-name" placeholder="e.g., my_new_function">
          </div>
          <div class="modal-actions">
            <button class="btn" id="btn-cancel-promotion">Cancel</button>
            <button class="btn" id="btn-confirm-promotion">Confirm & Push</button>
          </div>
      </div>
  </div>

  <script>
    const promptTextInput = document.getElementById('prompt-text');
    const D = { // DOM Elements
        promotionModal: document.getElementById('promotion-modal'),
        composerProjectsSelect: document.getElementById('composer-projects'),
        composerLibsSelect: document.getElementById('composer-libs'),
        definitionNameInput: document.getElementById('definition-name'),
    };

    // --- API HELPER ---
    async function apiCall(action, params = {}) {
        const formData = new FormData();
        formData.append('action', action);
        for (const key in params) {
            formData.append(key, params[key]);
        }
        try {
            const response = await fetch('', { method: 'POST', body: formData });
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            alert('An error occurred. Check console.');
        }
    }

    // --- TEXT EDITOR LOGIC ---
    promptTextInput.addEventListener('keydown', function(e) {
      if (e.key === 'Tab' && !e.shiftKey) {
        e.preventDefault();
        const tabSize = parseInt(document.getElementById('tab-size-input').value, 10) || 4;
        const tabCharacter = ' '.repeat(tabSize);
        const start = this.selectionStart, end = this.selectionEnd;
        this.value = this.value.substring(0, start) + tabCharacter + this.value.substring(end);
        this.selectionStart = this.selectionEnd = start + tabCharacter.length;
      }
    });

    // --- MODAL & PROMOTION LOGIC ---
    function openModal() { D.promotionModal.style.display = 'block'; }
    function closeModal() { D.promotionModal.style.display = 'none'; }

    async function updateComposerLibsDropdown() {
        const project = D.composerProjectsSelect.value;
        D.composerLibsSelect.innerHTML = '<option>Loading...</option>';
        const res = await apiCall('list_composer_libs', { project });
        if (res.status === 'success') {
            D.composerLibsSelect.innerHTML = res.files.length ? res.files.map(f => `<option value="${f}">${f}</option>`).join('') : '<option disabled>No libraries found</option>';
        }
    }
    
    document.getElementById('btn-push-composer').addEventListener('click', async () => {
        D.composerProjectsSelect.innerHTML = '<option>Loading...</option>';
        openModal();
        const res = await apiCall('list_composer_projects');
        if (res.status === 'success' && res.projects.length > 0) {
            D.composerProjectsSelect.innerHTML = res.projects.map(p => `<option value="${p}">${p}</option>`).join('');
            await updateComposerLibsDropdown();
        } else {
            D.composerProjectsSelect.innerHTML = '<option disabled>No projects found</option>';
        }
    });

    D.composerProjectsSelect.addEventListener('change', updateComposerLibsDropdown);
    document.getElementById('btn-cancel-promotion').addEventListener('click', closeModal);
    
    document.getElementById('btn-confirm-promotion').addEventListener('click', async () => {
        const content = promptTextInput.value;
        const name = D.definitionNameInput.value;
        const project = D.composerProjectsSelect.value;
        const library = D.composerLibsSelect.value;

        if (!content || !name || !project || !library) {
            alert('Please fill out all fields and ensure content is in the editor.');
            return;
        }

        const res = await apiCall('promote_to_composer', { project, library, name, content });
        if (res.status === 'success') {
            alert(res.message);
            closeModal();
            D.definitionNameInput.value = '';
        } else {
            alert('Error: ' + (res.message || 'Promotion failed.'));
        }
    });
  </script>
</body>
</html>