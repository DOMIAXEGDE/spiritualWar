import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from itertools import product
import os
from qiskit import QuantumCircuit
from qiskit.visualization import circuit_drawer

class QuantumCircuitDesignerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Quantum Circuit Designer")
        self.root.geometry("1200x800")
        
        # Create main notebook for tabs
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.create_tab = ttk.Frame(self.notebook)
        self.view_tab = ttk.Frame(self.notebook)
        self.modify_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.create_tab, text="Create Circuits")
        self.notebook.add(self.view_tab, text="View Circuits")
        self.notebook.add(self.modify_tab, text="Modify Circuits")
        
        # Initialize UI components
        self.setup_create_tab()
        self.setup_view_tab()
        self.setup_modify_tab()
        
        # Track current circuits
        self.circuits = []
        self.current_circuit = None
        
    def setup_create_tab(self):
        # Left panel for inputs
        left_frame = ttk.LabelFrame(self.create_tab, text="Circuit Parameters")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=10, pady=10)
        
        # Right panel for circuit preview
        right_frame = ttk.LabelFrame(self.create_tab, text="Circuit Preview")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Input fields
        ttk.Label(left_frame, text="Number of Qubits:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.num_qubits_var = tk.IntVar(value=2)
        ttk.Spinbox(left_frame, from_=1, to=10, textvariable=self.num_qubits_var, width=5).grid(row=0, column=1, sticky=tk.W, padx=5, pady=5)
        
        ttk.Label(left_frame, text="Number of Gate Layers:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.num_cells_var = tk.IntVar(value=2)
        ttk.Spinbox(left_frame, from_=1, to=10, textvariable=self.num_cells_var, width=5).grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Gate selection frame
        gate_frame = ttk.LabelFrame(left_frame, text="Available Gates")
        gate_frame.grid(row=2, column=0, columnspan=2, sticky=tk.W+tk.E, padx=5, pady=5)
        
        self.gate_vars = {}
        gates = ['x', 'y', 'z', 'h', 's', 'sdg', 't', 'tdg', 'rx', 'ry', 'rz', 'cx']
        
        for i, gate in enumerate(gates):
            self.gate_vars[gate] = tk.BooleanVar(value=True)
            ttk.Checkbutton(gate_frame, text=gate, variable=self.gate_vars[gate]).grid(
                row=i//3, column=i%3, sticky=tk.W, padx=5, pady=2)
        
        # Generation options
        options_frame = ttk.LabelFrame(left_frame, text="Generation Options")
        options_frame.grid(row=3, column=0, columnspan=2, sticky=tk.W+tk.E, padx=5, pady=5)
        
        self.limit_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Limit number of circuits", variable=self.limit_var).grid(
            row=0, column=0, sticky=tk.W, padx=5, pady=2)
        
        ttk.Label(options_frame, text="Max Circuits:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.max_circuits_var = tk.IntVar(value=10)
        ttk.Spinbox(options_frame, from_=1, to=1000, textvariable=self.max_circuits_var, width=5).grid(
            row=1, column=1, sticky=tk.W, padx=5, pady=2)
        
        # Action buttons
        btn_frame = ttk.Frame(left_frame)
        btn_frame.grid(row=4, column=0, columnspan=2, sticky=tk.W+tk.E, padx=5, pady=10)
        
        ttk.Button(btn_frame, text="Generate Circuits", command=self.generate_circuits).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Save to File", command=self.save_circuits).pack(side=tk.RIGHT, padx=5)
        
        # Preview area
        self.preview_figure = plt.Figure(figsize=(6, 4), dpi=100)
        self.preview_ax = self.preview_figure.add_subplot(111)
        self.preview_canvas = FigureCanvasTkAgg(self.preview_figure, right_frame)
        self.preview_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Circuit selection
        circuit_frame = ttk.Frame(right_frame)
        circuit_frame.pack(fill=tk.X, expand=False, padx=5, pady=5)
        
        ttk.Label(circuit_frame, text="Circuit:").pack(side=tk.LEFT, padx=5)
        self.circuit_index_var = tk.IntVar(value=0)
        self.circuit_spinner = ttk.Spinbox(circuit_frame, from_=0, to=0, textvariable=self.circuit_index_var, width=5,
                                          command=self.update_preview)
        self.circuit_spinner.pack(side=tk.LEFT, padx=5)
        
        # Circuit info
        self.circuit_info = scrolledtext.ScrolledText(right_frame, height=6)
        self.circuit_info.pack(fill=tk.X, expand=False, padx=5, pady=5)
        
    def setup_view_tab(self):
        # Left panel for file selection and circuit list
        left_frame = ttk.LabelFrame(self.view_tab, text="Circuit Selection")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=10, pady=10)
        
        # Right panel for circuit visualization
        right_frame = ttk.LabelFrame(self.view_tab, text="Circuit Visualization")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # File selection
        file_frame = ttk.Frame(left_frame)
        file_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(file_frame, text="Source File:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.source_file_var = tk.StringVar()
        ttk.Entry(file_frame, textvariable=self.source_file_var, width=20).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(file_frame, text="Browse", command=self.browse_source_file).grid(row=0, column=2, padx=5, pady=5)
        ttk.Button(file_frame, text="Load Circuits", command=self.load_circuits).grid(row=1, column=0, columnspan=3, padx=5, pady=5)
        
        # Circuit list
        ttk.Label(left_frame, text="Available Circuits:").pack(anchor=tk.W, padx=5, pady=5)
        self.circuit_listbox = tk.Listbox(left_frame, width=30, height=20)
        self.circuit_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.circuit_listbox.bind('<<ListboxSelect>>', self.on_circuit_select)
        
        # Action buttons
        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        ttk.Button(btn_frame, text="View Circuit", command=self.view_selected_circuit).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Export as PNG", command=self.export_circuit_png).pack(side=tk.RIGHT, padx=5)
        
        # Circuit visualization area
        self.view_figure = plt.Figure(figsize=(6, 4), dpi=100)
        self.view_ax = self.view_figure.add_subplot(111)
        self.view_canvas = FigureCanvasTkAgg(self.view_figure, right_frame)
        self.view_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Circuit details
        self.view_circuit_info = scrolledtext.ScrolledText(right_frame, height=6)
        self.view_circuit_info.pack(fill=tk.X, expand=False, padx=5, pady=5)
        
    def setup_modify_tab(self):
        # Left panel for circuit selection and editing
        left_frame = ttk.LabelFrame(self.modify_tab, text="Circuit Editing")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=10, pady=10)
        
        # Right panel for preview
        right_frame = ttk.LabelFrame(self.modify_tab, text="Modified Circuit Preview")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Circuit selection
        ttk.Label(left_frame, text="Select Circuit:").pack(anchor=tk.W, padx=5, pady=5)
        self.modify_circuit_listbox = tk.Listbox(left_frame, width=30, height=10)
        self.modify_circuit_listbox.pack(fill=tk.X, padx=5, pady=5)
        self.modify_circuit_listbox.bind('<<ListboxSelect>>', self.on_modify_circuit_select)
        
        # Circuit gate editing
        gate_edit_frame = ttk.LabelFrame(left_frame, text="Edit Gates")
        gate_edit_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        ttk.Label(gate_edit_frame, text="Gate Sequence:").pack(anchor=tk.W, padx=5, pady=5)
        self.gate_sequence_text = scrolledtext.ScrolledText(gate_edit_frame, height=8)
        self.gate_sequence_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Action buttons
        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=10)
        ttk.Button(btn_frame, text="Update Circuit", command=self.update_circuit).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Delete Circuit", command=self.delete_circuit).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Save Changes", command=self.save_modified_circuits).pack(side=tk.RIGHT, padx=5)
        
        # Preview area
        self.modify_figure = plt.Figure(figsize=(6, 4), dpi=100)
        self.modify_ax = self.modify_figure.add_subplot(111)
        self.modify_canvas = FigureCanvasTkAgg(self.modify_figure, right_frame)
        self.modify_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def generate_circuits(self):
        try:
            num_qubits = self.num_qubits_var.get()
            num_cells = self.num_cells_var.get()
            
            if num_qubits <= 0 or num_cells <= 0:
                messagebox.showerror("Invalid Input", "Number of qubits and cells must be positive")
                return
            
            # Get selected gates
            selected_gates = [gate for gate, var in self.gate_vars.items() if var.get()]
            if not selected_gates:
                messagebox.showerror("No Gates Selected", "Please select at least one gate type")
                return
            
            # Generate circuits
            self.circuits = []
            
            # Limit number of gate combinations if needed
            max_circuits = self.max_circuits_var.get() if self.limit_var.get() else float('inf')
            gate_combinations = product(selected_gates, repeat=num_cells)
            
            for idx, combo in enumerate(gate_combinations):
                if idx >= max_circuits:
                    break
                
                qc = QuantumCircuit(num_qubits)
                gate_sequence = ""
                
                for i, gate in enumerate(combo):
                    qubit = i % num_qubits
                    
                    if gate in ['x', 'y', 'z', 'h', 's', 'sdg', 't', 'tdg']:
                        getattr(qc, gate)(qubit)
                        gate_sequence += f"{gate}({qubit}) "
                    elif gate == 'cx':
                        control = qubit
                        target = (qubit + 1) % num_qubits
                        getattr(qc, gate)(control, target)
                        gate_sequence += f"{gate}({control},{target}) "
                    elif gate in ['rx', 'ry', 'rz']:
                        getattr(qc, gate)(np.pi/2, qubit)
                        gate_sequence += f"{gate}(pi/2,{qubit}) "
                
                self.circuits.append((qc, gate_sequence.strip()))
            
            # Update circuit spinner
            self.circuit_spinner.config(to=len(self.circuits)-1 if self.circuits else 0)
            self.circuit_index_var.set(0)
            
            # Update preview
            self.update_preview()
            
            messagebox.showinfo("Success", f"Generated {len(self.circuits)} circuits")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def update_preview(self):
        if not self.circuits:
            return
        
        idx = self.circuit_index_var.get()
        if idx < 0 or idx >= len(self.circuits):
            return
        
        qc, gate_sequence = self.circuits[idx]
        
        # Update circuit info
        self.circuit_info.delete(1.0, tk.END)
        self.circuit_info.insert(tk.END, f"Circuit {idx}:\n{gate_sequence}")
        
        # Update circuit diagram
        self.preview_ax.clear()
        circuit_drawer(qc, output='mpl', style={'name': 'iqx'}, 
                      ax=self.preview_ax)
        self.preview_canvas.draw()
    
    def save_circuits(self):
        if not self.circuits:
            messagebox.showwarning("No Circuits", "No circuits to save")
            return
        
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", 
                                               filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'w') as file:
                for idx, (_, gate_sequence) in enumerate(self.circuits):
                    file.write(f"Circuit {idx}: {gate_sequence}\n")
            
            messagebox.showinfo("Success", f"Saved {len(self.circuits)} circuits to {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save circuits: {str(e)}")
    
    def browse_source_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if file_path:
            self.source_file_var.set(file_path)
    
    def load_circuits(self):
        file_path = self.source_file_var.get()
        if not file_path or not os.path.exists(file_path):
            messagebox.showerror("File Not Found", "Please select a valid file")
            return
        
        try:
            # Clear current list
            self.circuit_listbox.delete(0, tk.END)
            self.modify_circuit_listbox.delete(0, tk.END)
            
            with open(file_path, 'r') as file:
                lines = file.readlines()
                
                num_qubits, ok = self.prompt_for_qubits()
                if not ok:
                    return
                
                self.circuits = []
                
                for idx, line in enumerate(lines):
                    if line.strip():
                        # Parse circuit line
                        gate_sequence = ' '.join(line.strip().split(' ')[2:])  # Skip the 'Circuit X:' part
                        qc = self.generate_circuit_from_line(line.strip(), num_qubits)
                        
                        self.circuits.append((qc, gate_sequence))
                        self.circuit_listbox.insert(tk.END, f"Circuit {idx}")
                        self.modify_circuit_listbox.insert(tk.END, f"Circuit {idx}")
                
                messagebox.showinfo("Success", f"Loaded {len(self.circuits)} circuits from {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load circuits: {str(e)}")
    
    def prompt_for_qubits(self):
        # Create a dialog to ask for number of qubits
        dialog = tk.Toplevel(self.root)
        dialog.title("Input Required")
        dialog.transient(self.root)
        dialog.geometry("300x120")
        dialog.resizable(False, False)
        
        ttk.Label(dialog, text="Enter number of qubits per circuit:").pack(padx=10, pady=10)
        
        qubits_var = tk.IntVar(value=2)
        ttk.Spinbox(dialog, from_=1, to=10, textvariable=qubits_var, width=5).pack(padx=10, pady=5)
        
        result = [0, False]  # [qubits, ok]
        
        def on_ok():
            try:
                qubits = qubits_var.get()
                if qubits <= 0:
                    messagebox.showerror("Invalid Input", "Number of qubits must be positive", parent=dialog)
                    return
                result[0] = qubits
                result[1] = True
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Invalid input: {str(e)}", parent=dialog)
        
        def on_cancel():
            dialog.destroy()
        
        button_frame = ttk.Frame(dialog)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Button(button_frame, text="OK", command=on_ok).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=on_cancel).pack(side=tk.RIGHT, padx=5)
        
        dialog.grab_set()
        self.root.wait_window(dialog)
        
        return result
    
    def generate_circuit_from_line(self, line, num_qubits):
        qc = QuantumCircuit(num_qubits)
        commands = line.strip().split(' ')[2:]  # Skip the 'Circuit X:' part
        
        for cmd in commands:
            if not cmd:
                continue
                
            parts = cmd.split('(')
            if len(parts) != 2:
                continue
                
            gate = parts[0]
            args = parts[1].strip(')').split(',')
            
            try:
                if gate in ['x', 'y', 'z', 'h', 's', 'sdg', 't', 'tdg']:
                    getattr(qc, gate)(int(args[0]))
                elif gate in ['rx', 'ry', 'rz']:
                    if 'pi/2' in args[0]:
                        angle = np.pi / 2
                    else:
                        angle = float(args[0])
                    getattr(qc, gate)(angle, int(args[1]))
                elif gate == 'cx':
                    getattr(qc, gate)(int(args[0]), int(args[1]))
            except Exception as e:
                print(f"Error processing gate {gate} with args {args}: {str(e)}")
                
        return qc
    
    def on_circuit_select(self, event):
        selection = self.circuit_listbox.curselection()
        if selection:
            idx = selection[0]
            self.view_selected_circuit(idx)
    
    def view_selected_circuit(self, idx=None):
        if idx is None:
            selection = self.circuit_listbox.curselection()
            if not selection:
                messagebox.showwarning("No Selection", "Please select a circuit to view")
                return
            idx = selection[0]
        
        if idx < 0 or idx >= len(self.circuits):
            return
        
        qc, gate_sequence = self.circuits[idx]
        
        # Update circuit info
        self.view_circuit_info.delete(1.0, tk.END)
        self.view_circuit_info.insert(tk.END, f"Circuit {idx}:\n{gate_sequence}")
        
        # Update circuit diagram
        self.view_ax.clear()
        circuit_drawer(qc, output='mpl', style={'name': 'iqx'}, 
                      ax=self.view_ax)
        self.view_canvas.draw()
    
    def export_circuit_png(self):
        selection = self.circuit_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a circuit to export")
            return
        
        idx = selection[0]
        if idx < 0 or idx >= len(self.circuits):
            return
        
        qc, _ = self.circuits[idx]
        
        file_path = filedialog.asksaveasfilename(defaultextension=".png", 
                                               filetypes=[("PNG Files", "*.png"), ("All Files", "*.*")])
        
        if not file_path:
            return
        
        try:
            circuit_drawer(qc, output='mpl', filename=file_path)
            messagebox.showinfo("Success", f"Exported circuit to {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export circuit: {str(e)}")
    
    def on_modify_circuit_select(self, event):
        selection = self.modify_circuit_listbox.curselection()
        if selection:
            idx = selection[0]
            if idx < 0 or idx >= len(self.circuits):
                return
            
            _, gate_sequence = self.circuits[idx]
            
            # Update gate sequence text
            self.gate_sequence_text.delete(1.0, tk.END)
            self.gate_sequence_text.insert(tk.END, gate_sequence)
            
            # Show preview
            self.update_modified_preview(idx)
    
    def update_modified_preview(self, idx):
        if idx < 0 or idx >= len(self.circuits):
            return
        
        qc, _ = self.circuits[idx]
        
        # Update circuit diagram
        self.modify_ax.clear()
        circuit_drawer(qc, output='mpl', style={'name': 'iqx'}, 
                      ax=self.modify_ax)
        self.modify_canvas.draw()
    
    def update_circuit(self):
        selection = self.modify_circuit_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a circuit to update")
            return
        
        idx = selection[0]
        if idx < 0 or idx >= len(self.circuits):
            return
        
        # Get modified gate sequence
        gate_sequence = self.gate_sequence_text.get(1.0, tk.END).strip()
        
        # Recreate circuit
        try:
            qc, _ = self.circuits[idx]
            num_qubits = qc.num_qubits
            
            # Create a new circuit with the same number of qubits
            modified_qc = QuantumCircuit(num_qubits)
            
            # Parse gate sequence
            commands = gate_sequence.split(' ')
            for cmd in commands:
                if not cmd:
                    continue
                    
                parts = cmd.split('(')
                if len(parts) != 2:
                    continue
                    
                gate = parts[0]
                args = parts[1].strip(')').split(',')
                
                if gate in ['x', 'y', 'z', 'h', 's', 'sdg', 't', 'tdg']:
                    getattr(modified_qc, gate)(int(args[0]))
                elif gate in ['rx', 'ry', 'rz']:
                    if 'pi/2' in args[0]:
                        angle = np.pi / 2
                    else:
                        angle = float(args[0])
                    getattr(modified_qc, gate)(angle, int(args[1]))
                elif gate == 'cx':
                    getattr(modified_qc, gate)(int(args[0]), int(args[1]))
            
            # Update circuit in list
            self.circuits[idx] = (modified_qc, gate_sequence)
            
            # Update preview
            self.update_modified_preview(idx)
            
            messagebox.showinfo("Success", f"Updated Circuit {idx}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update circuit: {str(e)}")
    
    def delete_circuit(self):
        selection = self.modify_circuit_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a circuit to delete")
            return
        
        idx = selection[0]
        if idx < 0 or idx >= len(self.circuits):
            return
        
        # Confirm deletion
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete Circuit {idx}?"):
            return
        
        # Remove circuit
        self.circuits.pop(idx)
        
        # Update listboxes
        self.circuit_listbox.delete(0, tk.END)
        self.modify_circuit_listbox.delete(0, tk.END)
        
        for i in range(len(self.circuits)):
            self.circuit_listbox.insert(tk.END, f"Circuit {i}")
            self.modify_circuit_listbox.insert(tk.END, f"Circuit {i}")
        
        # Clear preview
        self.modify_ax.clear()
        self.modify_canvas.draw()
        
        messagebox.showinfo("Success", f"Deleted Circuit {idx}")
    
    def save_modified_circuits(self):
        if not self.circuits:
            messagebox.showwarning("No Circuits", "No circuits to save")
            return
        
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", 
                                               filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'w') as file:
                for idx, (_, gate_sequence) in enumerate(self.circuits):
                    file.write(f"Circuit {idx}: {gate_sequence}\n")
            
            messagebox.showinfo("Success", f"Saved {len(self.circuits)} circuits to {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save circuits: {str(e)}")

if __name__ == "__main__":
    # Check dependencies
    try:
        import qiskit
    except ImportError:
        print("Qiskit is not installed. Installing...")
        import subprocess
        subprocess.check_call(["pip", "install", "qiskit[visualization]"])
        print("Qiskit installed successfully.")
    
    root = tk.Tk()
    app = QuantumCircuitDesignerApp(root)
    root.mainloop()