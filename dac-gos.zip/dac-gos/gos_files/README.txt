Welcome to Genesis OS


This is a self-contained web-based operating system that provides:
- A desktop interface with window management
- Mathematical sandbox for calculations and visualizations
- File management capabilities
- Terminal with command execution
- Application installation system

To get started, log in with one of these demo accounts:
- admin / 00EITA00 (Administrator)
- guest / dfcGigtm8* (Regular user)

Enjoy exploring Genesis OS!