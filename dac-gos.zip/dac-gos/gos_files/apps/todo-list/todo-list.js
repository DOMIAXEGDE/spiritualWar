/**
 * To-Do List for Genesis OS v1.0.2
 * A sandboxed application for managing tasks with a debounced auto-save feature.
 */
export function initialize(gos) {
    const container = gos.window.getContainer();
    const doc = container.ownerDocument;
    
    // --- State Management ---
    let tasks = [];
    let isModified = false;
    
    const username = gos.user.username;
    const filePath = `/users/${username}/Documents/todolist.json`;

    /**
     * ✅ NEW: A debounced save function.
     * This will trigger a save operation 1.5 seconds after the last modification,
     * ensuring changes are persisted promptly without excessive writes.
     */
    let saveTimeout;
    function debouncedSave() {
        // Clear any pending save to reset the timer
        clearTimeout(saveTimeout);
        // Set a new timeout to run the saveTasks function
        saveTimeout = setTimeout(saveTasks, 1500); 
    }

    // --- 1. SETUP UI & STYLES ---

    function setupDOM() {
        const css = `
            .todo-container { display: flex; flex-direction: column; height: 100%; font-family: sans-serif; background: var(--window-body); }
            .todo-header { padding: 10px; display: flex; border-bottom: 1px solid var(--main-border); }
            .todo-input { flex: 1; padding: 8px; border: 1px solid var(--main-border); border-radius: 3px; background: var(--terminal-bg); color: var(--main-text); }
            .todo-add-btn { padding: 8px 12px; margin-left: 10px; }
            .todo-list { flex: 1; list-style: none; padding: 10px; margin: 0; overflow-y: auto; }
            .todo-list p { text-align:center; opacity:0.7; margin-top: 20px; }
            .todo-item { display: flex; align-items: center; padding: 10px; margin-bottom: 5px; background: var(--terminal-bg); border-radius: 3px; transition: background-color 0.2s; }
            .todo-item:hover { background: rgba(255, 255, 255, 0.1); }
            .todo-item.completed span { text-decoration: line-through; opacity: 0.5; }
            .todo-item input[type='checkbox'] { margin-right: 10px; transform: scale(1.1); }
            .todo-item span { flex: 1; user-select: none; }
            .todo-item .delete-btn { background: none; border: none; color: #ff4081; cursor: pointer; font-size: 1.2rem; opacity: 0.6; }
            .todo-item .delete-btn:hover { opacity: 1; }
        `;
        const styleEl = doc.createElement('style');
        styleEl.textContent = css;
        doc.head.appendChild(styleEl);

        container.innerHTML = `
            <div class="todo-container">
                <div class="todo-header">
                    <input type="text" id="task-input" class="todo-input" placeholder="Add a new task...">
                    <button id="add-task-btn" class="button button-primary todo-add-btn">Add</button>
                </div>
                <ul id="task-list" class="todo-list"></ul>
            </div>
        `;
    }

    // --- 2. CORE FUNCTIONALITY ---

    function renderTasks() {
        const taskList = doc.getElementById('task-list');
        taskList.innerHTML = '';
        if (tasks.length === 0) {
            taskList.innerHTML = `<p>No tasks yet. Add one above!</p>`;
        }
        tasks.forEach((task, index) => {
            const li = doc.createElement('li');
            li.className = `todo-item ${task.completed ? 'completed' : ''}`;
            li.innerHTML = `
                <input type="checkbox" data-action="toggle" data-index="${index}" ${task.completed ? 'checked' : ''}>
                <span></span>
                <button class="delete-btn" data-action="delete" data-index="${index}">×</button>
            `;
            li.querySelector('span').textContent = task.text;
            taskList.appendChild(li);
        });
    }

    /**
     * ✅ MODIFIED: Now calls debouncedSave() after adding a task.
     */
    function addTask() {
        const input = doc.getElementById('task-input');
        const text = input.value.trim();
        if (text) {
            tasks.unshift({ text, completed: false });
            input.value = '';
            isModified = true;
            renderTasks();
            debouncedSave(); // Trigger the save
        }
    }

    function saveTasks() {
        if (!isModified) return;

        const jsonContent = JSON.stringify(tasks, null, 2);
        isModified = false; // Reset the flag
        
        gos.filesystem.writeFile(filePath, jsonContent)
            .then(() => {
                // We can add a subtle save indicator later if needed
                console.log("Tasks auto-saved successfully.");
            })
            .catch(error => {
                isModified = true; // Revert on failure to allow another save attempt
                gos.ui.showNotification('Error', `Could not save list: ${error.message}`, 5000);
            });
    }

    async function loadTasks() {
        try {
            const result = await gos.filesystem.readFile(filePath);
            const loadedTasks = JSON.parse(result.content);
            if (Array.isArray(loadedTasks)) {
                tasks = loadedTasks;
            }
        } catch (error) {
            tasks = [];
        }
        renderTasks();
    }

    // --- 3. INITIALIZATION & EVENT BINDING ---

    setupDOM();
    loadTasks();
    gos.window.setTitle("To-Do List");

    doc.getElementById('add-task-btn').addEventListener('click', addTask);
    doc.getElementById('task-input').addEventListener('keydown', e => {
        if (e.key === 'Enter') addTask();
    });

    /**
     * ✅ MODIFIED: Now calls debouncedSave() after any change.
     */
    doc.getElementById('task-list').addEventListener('click', e => {
        const { action, index } = e.target.dataset;
        if (!action) return;

        const taskIndex = parseInt(index, 10);
        if (isNaN(taskIndex) || taskIndex >= tasks.length) return;

        if (action === 'toggle') {
            tasks[taskIndex].completed = !tasks[taskIndex].completed;
        } else if (action === 'delete') {
            tasks.splice(taskIndex, 1);
        }
        isModified = true;
        renderTasks();
        debouncedSave(); // Trigger the save
    });
    
    // ❌ REMOVED: The unreliable fixed-interval saving is no longer needed.
    // setInterval(saveTasks, 15000);
}