export function initialize(gosApiProxy) {
    const container = gosApiProxy.window.getContainer();
    const doc = container.ownerDocument;

    // --- 1. Inject CSS Styles (with new tab styling) ---
    const style = doc.createElement('style');
    style.textContent = `
        :root {
            --primary-color: #4B5320; --secondary-color: #FFFFFF; --accent-color: #BDB76B;
            --background-color: #F5F5DC; --text-color: #333333; --font-main: "Fira Code", "Consolas", monospace;
        }
        body { font-family: var(--font-main); background-color: var(--background-color); color: var(--text-color); margin: 0; padding: 20px; box-sizing: border-box; }
        header { text-align: center; margin-bottom: 20px; padding-bottom: 20px; border-bottom: 4px double var(--primary-color); }
        main { max-width: 1400px; margin: auto; }
        h2 { color: var(--primary-color); text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1); font-weight: 600; margin-top: 0; }
        h3 { color: var(--primary-color); }

        /* Tab Styles */
        .app-tabs { display: flex; border-bottom: 2px solid var(--primary-color); margin-bottom: 20px; }
        .tab-button { background-color: transparent; color: var(--text-color); border: none; padding: 12px 18px; cursor: pointer; font-size: 1.1em; transition: background-color 0.3s, color 0.3s; border-radius: 5px 5px 0 0; margin: 0 5px -2px 5px; border: 2px solid transparent; }
        .tab-button:hover { background-color: rgba(75, 83, 32, 0.1); }
        .tab-button.active { background-color: var(--secondary-color); border-color: var(--primary-color) var(--primary-color) var(--secondary-color) var(--primary-color); font-weight: bold; }
        .content-panel { display: none; }
        .content-panel.active { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        /* Original App Styles */
        .operation-section { background-color: var(--secondary-color); padding: 20px; border: 2px solid var(--accent-color); box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .operation-container { display: flex; flex-wrap: wrap; gap: 20px; }
        .operation-controls, .operation-result { flex: 1; min-width: 300px; }
        button { background-color: var(--primary-color); color: var(--secondary-color); padding: 10px 15px; font-size: 1em; border: 2px solid var(--accent-color); cursor: pointer; transition: all 0.3s ease; font-family: var(--font-main); margin-top: 5px; }
        button:hover { background-color: var(--accent-color); color: var(--text-color); transform: translateY(-2px); }
        button:disabled { background-color: #ccc; border-color: #999; color: #666; cursor: not-allowed; transform: none; }
        input, select, textarea { width: 100%; padding: 10px; font-size: 1em; background-color: #fefefe; color: var(--text-color); border: 2px solid var(--accent-color); font-family: var(--font-main); margin-bottom: 10px; box-sizing: border-box; }
        textarea { resize: vertical; }
        .result-container { background-color: #FFFFFF; padding: 10px; border: 2px solid var(--accent-color); font-family: var(--font-main); box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) inset; color: var(--text-color); word-wrap: break-word; white-space: pre-wrap; margin-top: 10px; min-height: 50px; }
        #map-system-section #option-container { margin-top: 15px; border-top: 2px solid var(--background-color); padding-top: 15px; }
        #map-system-section #main-menu { display: flex; flex-wrap: wrap; gap: 10px; }
        #color-bar { width: 100%; height: 20px; background-color: var(--accent-color); margin-top: 15px; border: 2px solid var(--primary-color); box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); transition: background-color 0.3s ease; }
        #custom-string { white-space: pre; overflow-wrap: normal; overflow-x: auto; }
        #grid-canvas { border: 2px solid var(--accent-color); margin-top: 10px; width: 100%; max-width: 400px; height: auto; }
        #navigation-controls { display: flex; justify-content: center; align-items: center; gap: 10px; width: 100%; margin-top: 10px; flex-wrap: wrap; }
        #color-list-container { margin-top: 15px; }
        #color-list { list-style-type: none; padding: 0; margin: 0; max-height: 200px; overflow-y: auto; border: 1px solid var(--accent-color); }
        #color-list li { background: var(--background-color); padding: 5px 10px; border-bottom: 1px solid var(--accent-color); }
    `;
    doc.head.appendChild(style);

    // --- 2. Inject Tabbed HTML Structure ---
    container.innerHTML = `
        <header>
            <h1>Integrated Charset & Grid Viewer</h1>
            <p>A tool for converting strings to unique IDs and visualizing them as tile grids.</p>
        </header>
        <div class="app-tabs">
            <button class="tab-button active" data-tab="id-generation">ID Generation</button>
            <button class="tab-button" data-tab="grid-visualization">Grid Visualization</button>
        </div>
        <main class="app-content-panels">
            <div id="panel-id-generation" class="content-panel active">
                <section id="map-system-section" class="operation-section">
                    <div class="operation-container">
                        <div class="operation-controls">
                            <h2>ID Generation Controls</h2>
                            <div id="main-menu">
                                <button id="show-generate-combinations">Generate Combinations</button>
                                <button id="show-calculate-string-id">Calculate String ID</button>
                                <button id="show-decode-id">Decode ID to String</button>
                                <button id="show-find-optimal-variable">Find Optimal Variable</button>
                            </div>
                            <div id="option-container" style="display: none;">
                                <div id="generate-combinations" style="display: none;">
                                    <h3>Generate Combinations</h3>
                                    <label for="combination-size">Enter the size of combinations (n):</label>
                                    <input type="number" id="combination-size">
                                    <label for="output-file-generate">Enter the name of the output file:</label>
                                    <input type="text" id="output-file-generate" value="combinations.txt">
                                    <button id="generate-combinations-btn">Generate</button>
                                </div>
                                <div id="calculate-string-id" style="display: none;">
                                    <h3>Calculate String ID</h3>
                                    <label for="custom-string">Enter your custom string:</label>
                                    <textarea id="custom-string" rows="10" cols="50" wrap="off"></textarea>
                                    <button id="calculate-string-id-btn">Calculate</button>
                                    <p id="string-id-result" class="result-container"></p>
                                    <div id="character-word-count">Characters: 0, Words: 0</div>
                                </div>
                                <div id="decode-id" style="display: none;">
                                    <h3>Decode ID to String</h3>
                                    <label for="string-id">Enter the ID to decode:</label>
                                    <input type="text" id="string-id">
                                    <button id="decode-id-btn">Decode</button>
                                    <p id="decoded-string-result" class="result-container"></p>
                                </div>
                                <div id="find-optimal-variable" style="display: none;">
                                    <h3>Find Optimal Variable and Save to File</h3>
                                    <label for="user-number">Enter the user number:</label>
                                    <input type="number" id="user-number">
                                    <label for="output-file-optimal">Enter the name of the output file:</label>
                                    <input type="text" id="output-file-optimal" value="optimal_variables.txt">
                                    <button id="find-optimal-variable-btn">Find and Save</button>
                                </div>
                            </div>
                        </div>
                        <div class="operation-result">
                            <h3>Result</h3>
                            <div id="map-result-display" class="result-container"><p>Select an operation to start.</p></div>
                            <h3>Grid Validation Status</h3>
                            <div id="color-bar"></div>
                        </div>
                    </div>
                </section>
            </div>
            <div id="panel-grid-visualization" class="content-panel">
                 <section id="alphabet-system-section" class="operation-section">
                    <div class="operation-container">
                        <div class="operation-controls">
                            <h2>Grid Generation Controls</h2>
                            <div id="controls">
                                <label for="tile-size">Tile Size (px):</label>
                                <input type="number" id="tile-size" value="100">
                            </div>
                            <div id="compounded-id-input-container">
                                <h3>Generate Grid by Compounded ID</h3>
                                <p>Enter an ID from the Charset App or upload a file with IDs.</p>
                                <div id="compounded-id-inputs">
                                    <div class="compounded-id-input-row">
                                        <input type="text" class="compounded-id-input" placeholder="Enter Compounded Grid ID">
                                    </div>
                                </div>
                                <button id="generate-grid-by-id">Generate Grids</button>
                                <hr style="margin: 15px 0;">
                                <input type="file" id="file-input" accept=".txt">
                                <button id="execute-button">Process File</button>
                            </div>
                        </div>
                        <div class="operation-result">
                            <h3>Grid Display</h3>
                            <canvas id="grid-canvas" style="background-color: #eee;"></canvas>
                            <div id="navigation-controls">
                                <button id="prev-grid" disabled>Previous Grid</button>
                                <span id="current-grid-position">Grid 0 of 0</span>
                                <button id="next-grid" disabled>Next Grid</button>
                            </div>
                            <button id="download-grid-image" disabled>Download Grid Image</button>
                            <div id="color-list-container">
                                <h3>Current Grid Tile IDs</h3>
                                <div id="current-grid-id"></div>
                                <ul id="color-list"></ul>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    `;

    // --- 3. Application Logic ---

    // Tab Switching Logic
    const tabs = doc.querySelectorAll('.tab-button');
    const panels = doc.querySelectorAll('.content-panel');
    const switchTab = (targetTabId) => {
        panels.forEach(panel => {
            panel.classList.remove('active');
            if (panel.id === `panel-${targetTabId}`) {
                panel.classList.add('active');
            }
        });
        tabs.forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.tab === targetTabId) {
                tab.classList.add('active');
            }
        });
    };
    tabs.forEach(tab => tab.addEventListener('click', () => switchTab(tab.dataset.tab)));

    // Charset App (Module 1)
    const mapApp = (() => {
        let _charsetConfig = [], _uniqueCharset = [];
        function initialize() {
            _initCharsetConfig();
            _uniqueCharset = _generateCharsetFromConfig(_charsetConfig);
            _initEventListeners();
        }
        function _initCharsetConfig() {
            _charsetConfig = [
                { name: 'Basic Latin', range: [0x0020, 0x007F] }, { name: 'Latin-1 Supplement', range: [0x0080, 0x00FF] },
                { name: 'Latin Extended-A', range: [0x0100, 0x017F] }, { name: 'Latin Extended-B', range: [0x0180, 0x024F] },
                { name: 'Greek and Coptic', range: [0x0370, 0x03FF] }, { name: 'Cyrillic', range: [0x0400, 0x04FF] },
                { name: 'Arabic', range: [0x0600, 0x06FF] }, { name: 'Hebrew', range: [0x0590, 0x05FF] },
                { name: 'Devanagari', range: [0x0900, 0x097F] }, { name: 'Mathematical Operators', range: [0x2200, 0x22FF] },
                { name: 'Supplemental Mathematical Operators', range: [0x2A00, 0x2AFF] }, { name: 'Miscellaneous Technical', range: [0x2300, 0x23FF] },
                { name: 'Miscellaneous Symbols and Arrows', range: [0x2190, 0x21FF] }, { name: 'CJK Unified Ideographs', range: [0x4E00, 0x9FFF] },
                { name: 'Hangul Syllables', range: [0xAC00, 0xD7AF] }, { name: 'Hiragana', range: [0x3040, 0x309F] },
                { name: 'Katakana', range: [0x30A0, 0x30FF] }, { name: 'Bopomofo', range: [0x3100, 0x312F] },
                { name: 'Currency Symbols', range: [0x20A0, 0x20CF] }, { name: 'Additional Punctuation', range: [0x2000, 0x206F] }
            ];
        }
        function _generateCharsetFromConfig(config) {
            const charset = new Set();
            config.forEach(block => { for (let i = block.range[0]; i <= block.range[1]; i++) { try { charset.add(String.fromCharCode(i)); } catch (e) {} } });
            charset.add('\n'); charset.add('\t');
            return Array.from(charset);
        }
        function _initEventListeners() {
            doc.getElementById('show-generate-combinations').addEventListener('click', () => showOption('generate-combinations'));
            doc.getElementById('show-calculate-string-id').addEventListener('click', () => showOption('calculate-string-id'));
            doc.getElementById('show-decode-id').addEventListener('click', () => showOption('decode-id'));
            doc.getElementById('show-find-optimal-variable').addEventListener('click', () => showOption('find-optimal-variable'));
            doc.getElementById('generate-combinations-btn').addEventListener('click', generateCombinations);
            doc.getElementById('calculate-string-id-btn').addEventListener('click', calculateStringID);
            doc.getElementById('decode-id-btn').addEventListener('click', decodeID);
            doc.getElementById('find-optimal-variable-btn').addEventListener('click', findOptimalVariable);
            doc.getElementById('custom-string').addEventListener('input', (e) => displayCharacterAndWordCount(e.target.value));
        }
        function showOption(optionId) {
            doc.querySelectorAll('#option-container > div').forEach(opt => opt.style.display = 'none');
            doc.getElementById(optionId).style.display = 'block';
            doc.getElementById('option-container').style.display = 'block';
        }
        function downloadFile(filename, content) {
            const blob = new Blob([content], { type: 'text/plain' }); const url = URL.createObjectURL(blob);
            const a = doc.createElement('a'); a.href = url; a.download = filename;
            doc.body.appendChild(a); a.click(); doc.body.removeChild(a); URL.revokeObjectURL(url);
        }
        function calculateStringID() {
            const resultDisplay = doc.getElementById('map-result-display');
            try {
                const inputString = doc.getElementById('custom-string').value; if (inputString.trim() === '') throw new Error("Input string cannot be empty.");
                resultDisplay.innerHTML = '<p>Calculating...</p>';
                setTimeout(() => {
                    try {
                        const invalidChars = [...new Set([...inputString].filter(char => !_uniqueCharset.includes(char)))];
                        if (invalidChars.length > 0) throw new Error(`Invalid characters found: ${invalidChars.join('')}`);
                        let id = 0n;
                        for (const char of inputString) { id = id * BigInt(_uniqueCharset.length) + BigInt(_uniqueCharset.indexOf(char)); }
                        const resultText = id.toString();
                        doc.getElementById('string-id-result').innerText = "Result ID: " + resultText;
                        const colorIndexes = decodeIDtoColorIndexes(resultText); updateColorBar(colorIndexes);
                        resultDisplay.innerHTML = `<p>✅ Calculation complete. ID: <strong>${resultText}</strong></p><button id="send-id-to-viewer">Visualize This ID</button>`;
                        doc.getElementById('send-id-to-viewer').addEventListener('click', () => {
                            alphabetApp.setInputIDAndGenerate(resultText);
                            switchTab('grid-visualization');
                        });
                    } catch (error) { resultDisplay.innerHTML = `<p class="error-message">${error.message}</p>`; }
                }, 50);
            } catch (error) { resultDisplay.innerHTML = `<p class="error-message">${error.message}</p>`; }
        }
        function decodeIDtoColorIndexes(idString) { if (!idString) return []; return (idString.match(/.{1,7}/g) || []).map(s => parseInt(s, 10)); }
        function updateColorBar(indexes) {
            const colorBar = doc.getElementById('color-bar'); const isSq = (n) => n > 0 && Math.sqrt(n) % 1 === 0;
            const isValid = (idxs) => idxs.every(index => index >= 1 && index <= 16777216);
            if (isSq(indexes.length) && isValid(indexes)) {
                colorBar.style.backgroundColor = 'green'; colorBar.title = "Valid: The number of color indexes forms a perfect square.";
            } else { colorBar.style.backgroundColor = 'red'; colorBar.title = "Invalid: The number of color indexes does not form a perfect square for a grid."; }
        }
        function displayCharacterAndWordCount(inputText) {
            const charCount = inputText.length; const wordCount = inputText.trim() === '' ? 0 : inputText.trim().split(/\s+/).length;
            doc.getElementById('character-word-count').innerText = `Characters: ${charCount}, Words: ${wordCount}`;
        }

        function generateCombinations() {
            const resultDisplay = doc.getElementById('map-result-display');
            try {
                const n = BigInt(doc.getElementById('combination-size').value);
                const outputFile = doc.getElementById('output-file-generate').value || 'combinations.txt';
                if (n <= 0n) throw new Error("Combination size must be a positive integer.");
                if (n > 4n && !confirm(`This may generate a very large number of combinations. Continue?`)) return;

                resultDisplay.innerHTML = '<p>Generating combinations... This may take a while.</p>';
                setTimeout(() => {
                    try {
                        const k = BigInt(_uniqueCharset.length);
                        const nbrComb = k ** n;
                        const maxToGenerate = 100000n;
                        const actualGenerate = nbrComb > maxToGenerate ? maxToGenerate : nbrComb;
                        let combinations = '';
                        for (let i = 0n; i < actualGenerate; i++) {
                            let id = i; let combination = '';
                            for (let j = 0n; j < n; j++) {
                                combination = _uniqueCharset[Number(id % k)] + combination;
                                id /= k;
                            }
                            combinations += combination + '\n';
                        }
                        downloadFile(outputFile, combinations);
                        resultDisplay.innerHTML = `<p class="success-message">Successfully generated ${actualGenerate.toLocaleString()} combinations and saved to ${outputFile}.</p>`;
                    } catch (error) {
                        resultDisplay.innerHTML = `<p class="error-message">Error during generation: ${error.message}</p>`;
                    }
                }, 50);
            } catch (error) {
               resultDisplay.innerHTML = `<p class="error-message">${error.message}</p>`;
            }
        }
		
        function decodeID() {
            const resultDisplay = doc.getElementById('map-result-display');
            try {
                const idStr = doc.getElementById('string-id').value;
                if (!/^\d+$/.test(idStr)) throw new Error("ID must be a valid non-negative integer.");
                let id = BigInt(idStr);
                resultDisplay.innerHTML = '<p>Decoding ID...</p>';
                setTimeout(() => {
                    try {
                        let decodedString = [];
                        if (id === 0n && _uniqueCharset.length > 0) {
                            decodedString.push(_uniqueCharset[0]);
                        } else {
                            while (id > 0n) {
                                decodedString.push(_uniqueCharset[Number(id % BigInt(_uniqueCharset.length))]);
                                id /= BigInt(_uniqueCharset.length);
                            }
                        }
                        const decodedResult = decodedString.reverse().join('');
                        doc.getElementById('decoded-string-result').innerText = "Decoded String: " + decodedResult;
                        resultDisplay.innerHTML = `<p>Decoding complete. Result: <pre>${decodedResult}</pre></p>`;
                    } catch (error) {
                        resultDisplay.innerHTML = `<p class="error-message">Error decoding ID: ${error.message}</p>`;
                    }
                }, 50);
            } catch (error) {
                resultDisplay.innerHTML = `<p class="error-message">${error.message}</p>`;
            }
        }
		
        function findOptimalVariable() {
            const resultDisplay = doc.getElementById('map-result-display');
            try {
                const userNumber = BigInt(doc.getElementById('user-number').value);
                const outputFile = doc.getElementById('output-file-optimal').value || 'optimal_variables.txt';
                if (userNumber <= 0n) throw new Error("User number must be positive.");
                
                resultDisplay.innerHTML = '<p>Finding optimal variables...</p>';
                setTimeout(() => {
                    try {
                        const charsetLength = BigInt(_uniqueCharset.length);
                        const generator = (function* (u, c) { for (let k = 1n; ; k++) { yield k * u; } })(userNumber, charsetLength);
                        const decode = (num) => {
                            let decStr = []; if (num === 0n) return _uniqueCharset[0] || '';
                            while(num > 0n){
                                decStr.push(_uniqueCharset[Number(num % charsetLength)]);
                                num /= charsetLength;
                            }
                            return decStr.reverse().join('');
                        };
                        const results = Array.from({length: 100}, () => {
                            const optVar = generator.next().value;
                            const decodedString = decode(optVar);
                            return { variable: optVar, string: decodedString, length: decodedString.length };
                        });
                        const resultString = results.map(r => `${r.variable}\t${r.string}`).join('\n');
                        downloadFile(outputFile, resultString);
                        let resultsHTML = `<p class="success-message">Found 100 optimal variables. File '${outputFile}' downloaded.</p><p>Showing first 10:</p><table class="results-table"><tr><th>Variable</th><th>String</th><th>Length</th></tr>`;
                        results.slice(0, 10).forEach(r => {
                            resultsHTML += `<tr><td>${r.variable}</td><td>${r.string}</td><td>${r.length}</td></tr>`;
                        });
                        resultsHTML += '</table>';
                        resultDisplay.innerHTML = resultsHTML;
                    } catch (error) {
                        resultDisplay.innerHTML = `<p class="error-message">Error finding optimal variables: ${error.message}</p>`;
                    }
                }, 50);
            } catch (error) {
                resultDisplay.innerHTML = `<p class="error-message">${error.message}</p>`;
            }
        }

        // Other functions (generateCombinations, decodeID, findOptimalVariable) are omitted for brevity but would be included here, adapted to use 'doc'.
        return { initialize };
    })();

    // Tile Color Viewer (Module 2)
    const alphabetApp = (() => {
        let _grids = [], _currentGridIndex = 0, _defaultTileSize = 100;
        function initialize() { _initEventListeners(); displayCurrentGrid(); }
        function _initEventListeners() {
            doc.getElementById('tile-size').addEventListener('input', () => displayCurrentGrid());
            doc.getElementById('generate-grid-by-id').addEventListener('click', generateGridsFromInputs);
            doc.getElementById('execute-button').addEventListener('click', processUploadedFile);
            doc.getElementById('prev-grid').addEventListener('click', () => navigateGrid(-1));
            doc.getElementById('next-grid').addEventListener('click', () => navigateGrid(1));
            doc.getElementById('download-grid-image').addEventListener('click', downloadGridImage);
        }
        function setInputIDAndGenerate(id) {
            const inputField = doc.querySelector('.compounded-id-input'); inputField.value = id;
            generateGridsFromInputs();
        }
        function idToHex(id) { id = BigInt(id); if (id <= 0n) return '#000000'; return `#${(id - 1n).toString(16).padStart(6, '0')}`; }
        function calculateGridDimensions(numTiles) {
            if (numTiles === 0) return { rows: 0, cols: 0 }; const sideLength = Math.ceil(Math.sqrt(numTiles));
            return { rows: sideLength, cols: sideLength };
        }
        function displayCurrentGrid() {
            const canvas = doc.getElementById('grid-canvas'); const context = canvas.getContext('2d');
            const colorSequence = _grids[_currentGridIndex] || []; const numTiles = colorSequence.length;
            if (numTiles === 0) {
                canvas.width = 400; canvas.height = 100; context.clearRect(0, 0, canvas.width, canvas.height);
                context.font = "16px " + getComputedStyle(doc.body).fontFamily; context.fillStyle = "#888";
                context.textAlign = "center"; context.fillText("No grid to display.", canvas.width / 2, canvas.height / 2);
                updateUIElements(); return;
            }
            const tileSize = parseInt(doc.getElementById('tile-size').value) || _defaultTileSize;
            const { rows, cols } = calculateGridDimensions(numTiles);
            canvas.width = cols * tileSize; canvas.height = rows * tileSize;
            context.clearRect(0, 0, canvas.width, canvas.height);
            colorSequence.forEach((color, i) => {
                const col = i % cols, row = Math.floor(i / cols); context.fillStyle = color;
                context.fillRect(col * tileSize, row * tileSize, tileSize, tileSize);
                context.strokeStyle = '#ccc'; context.strokeRect(col * tileSize, row * tileSize, tileSize, tileSize);
            });
            updateUIElements();
        }
        function updateUIElements() {
            const colorSequence = _grids[_currentGridIndex] || [];
            doc.getElementById('color-list').innerHTML = colorSequence.map(color => `<li>ID ${BigInt('0x' + color.replace('#', '')) + 1n}: ${color}</li>`).join('');
            doc.getElementById('current-grid-position').textContent = `Grid ${_grids.length > 0 ? _currentGridIndex + 1 : 0} of ${_grids.length}`;
            doc.getElementById('prev-grid').disabled = _currentGridIndex === 0;
            doc.getElementById('next-grid').disabled = _currentGridIndex >= _grids.length - 1;
            doc.getElementById('download-grid-image').disabled = colorSequence.length === 0;
        }
        function navigateGrid(direction) {
            const newIndex = _currentGridIndex + direction;
            if (newIndex >= 0 && newIndex < _grids.length) { _currentGridIndex = newIndex; displayCurrentGrid(); }
        }
        function regenerateGrids(compoundedIDs) {
            _grids = compoundedIDs.map(idString => (idString.trim().match(/.{1,7}/g) || []).map(id => idToHex(id)));
            _currentGridIndex = 0; displayCurrentGrid();
            gosApiProxy.ui.showNotification("Success", `${_grids.length} grid(s) regenerated successfully.`);
        }
        function generateGridsFromInputs() {
            const ids = [...doc.querySelectorAll('.compounded-id-input')].map(i => i.value.trim()).filter(id => id);
            if (ids.length === 0) { gosApiProxy.ui.showNotification("Error", 'Please enter at least one ID.', 4000); return; }
            regenerateGrids(ids);
        }
        function processUploadedFile() {
            const file = doc.getElementById('file-input').files[0];
            if (!file) { gosApiProxy.ui.showNotification("Error", "Please select a file.", 4000); return; }
            const reader = new FileReader();
            reader.onload = (e) => {
                const ids = e.target.result.split('\n').map(l => l.trim()).filter(l => /^\d+$/.test(l));
                if (ids.length > 0) regenerateGrids(ids);
                else gosApiProxy.ui.showNotification("Error", "No valid IDs found in file.", 4000);
            };
            reader.readAsText(file);
        }
        function downloadGridImage() {
            const canvas = doc.getElementById('grid-canvas'); const image = canvas.toDataURL('image/png');
            const a = doc.createElement('a'); a.href = image; a.download = `grid_${_currentGridIndex + 1}.png`; a.click();
        }
        return { initialize, setInputIDAndGenerate };
    })();

    // --- Initialize Both App Modules ---
    mapApp.initialize();
    alphabetApp.initialize();
}