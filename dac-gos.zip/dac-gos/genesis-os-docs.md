# **Genesis Operating System: Technical Documentation**

**Version 1.0.0**

## **1\. Abstract**

The Genesis Operating System (GOS) is a web-based application designed to simulate a desktop environment entirely within a browser. It is characterized as a monolithic web application with a distinctly modular, API-driven backend implemented in PHP and a dynamic, object-oriented JavaScript frontend. The primary function of GOS is to provide a persistent, multi-user environment with a virtual filesystem, a role-based permission model, and a framework for running sandboxed applications. Its architecture is notable for separating the backend logic (state management, security, file operations) from the frontend presentation (UI rendering, event handling, process management), communicating exclusively via a JSON-based API.

## **2\. System Architecture**

GOS operates on a client-server model. The server-side, built with PHP, functions as a headless API, while the client-side, built with JavaScript, renders the entire user interface and manages the user experience.

### **2.1. Backend Architecture (PHP)**

The backend is composed of a set of micro-modular PHP files, each responsible for a distinct domain of the system's logic. This design adheres to the principle of separation of concerns, enhancing maintainability and clarity.

#### **2.1.1. Bootstrapping and Request Lifecycle (bootstrap.php)**

All requests to the server are first processed by bootstrap.php. This file constitutes the foundational layer of the system.

* **Core Function:** To initialize the system environment for every API request.  
* **Components & Process:**  
  1. **Configuration Loading:** It begins by loading the master configuration array from config.php.  
  2. **JSON Body Shim:** It inspects incoming POST requests and, if the Content-Type is application/json, it decodes the raw input stream and merges the data into the $\_POST superglobal. This allows the system to handle JSON API calls with the same semantics as traditional form submissions.  
  3. **Error Handling:** A robust, system-wide error and exception handler is registered. All errors (including fatal ones via register\_shutdown\_function) are captured and logged to /gos\_files/system/error.log.  
  4. **Session Management:** It configures and initiates the PHP session. Critically, it dynamically sets the secure flag for the session cookie based on whether the connection is HTTPS, ensuring secure transmission of the session ID.  
  5. **Module Inclusion:** It includes all other core PHP modules (auth.php, filesystem.php, etc.), making their functions available globally.  
  6. **Filesystem Initialization:** It verifies that the necessary directories defined in config.php exist on the server, creating them on first run.

#### **2.1.2. API Dispatcher (genesis-os.php)**

While genesis-os.php also serves the initial HTML shell, its primary backend role is to act as the central API dispatcher.

* **Core Function:** To route incoming API requests to the appropriate backend module.  
* **Components & Process:**  
  1. **Endpoint Routing:** It inspects the ?api= query parameter (e.g., ?api=filesystem) to determine which module should handle the request.  
  2. **Authentication Check:** It maintains a list of public endpoints (like login and registration). For all other endpoints, it verifies that a user is authenticated using isAuthenticated(). If the check fails, it immediately returns a JSON error, halting further execution.  
  3. **Method Handling:** It calls the designated handler function from the relevant module (e.g., handleFileSystemAPI(), handleAuthAPI()).  
  4. **Exception Safety:** All API calls are wrapped in a try...catch block to ensure that any unhandled exception within a module is caught and returned as a clean JSON error response, preventing application crashes.

#### **2.1.3. Configuration (config.php)**

This file returns a single, multi-dimensional associative array that contains all system-wide configuration parameters. This centralization allows for straightforward modification of system behavior.

* **system**: Defines the OS name, version, and debug status.  
* **security**: Contains security-related flags, such as allow\_developer\_registration, and parameters for the code execution sandbox.  
* **filesystem**: Specifies whether to use the local server filesystem (use\_local) and defines the absolute paths for all system-critical directories (user\_dir, apps\_dir, etc.).  
* **ui**: Sets default user interface properties like theme and language.

#### **2.1.4. Core Backend Modules**

Each module is a self-contained PHP file that exposes a primary handler function (e.g., handleAuthAPI) and a set of related helper functions.

* **auth.php (Authentication Module):**  
  * **Purpose:** Manages user identity, sessions, and permissions.  
  * **Key Functions:**  
    * handleAuthAPI(): Routes login, logout, register, and validateToken requests.  
    * login: Verifies credentials against the users.json database, hashes passwords using password\_verify, and on success, regenerates the session ID to mitigate session fixation attacks.  
    * logout: Executes a secure logout by unsetting session variables, instructing the browser to expire the session cookie, and destroying the session on the server.  
    * getUserPermissions(): The definitive source for calculating a user's permissions based on their assigned roles.  
    * hasPermission(): The central gatekeeper function used by all other modules to authorize actions. It provides universal access to users with the admin role.  
* **filesystem.php (Filesystem Module):**  
  * **Purpose:** To abstract and secure all file and directory operations.  
  * **Key Functions:**  
    * resolvePath(): Translates a virtual OS path (e.g., /users/admin/Desktop) into a secure, absolute path on the server's physical disk.  
    * canAccessPath(): A critical security function that enforces read/write permissions. It checks the user's permissions against the virtual path they are attempting to access, forming the basis of the filesystem "jail."  
* **apps.php (Applications Module):**  
  * **Purpose:** Manages the application catalog and the developer submission workflow.  
  * **Key Functions:**  
    * listApps(): Compiles a comprehensive list of all applications available to the current user by merging the static builtinApps() list with manifests discovered in the filesystem.  
    * approveSubmission(): An admin-only function that promotes a developer's submitted application into the main OS by creating the necessary files and directories in /gos\_files/apps/.  
* **users.php (User Management Module):**  
  * **Purpose:** Provides an API for administrators to perform user account management.  
  * **Key Functions:** createUser, updateUser, deleteUser. It contains safeguards to prevent the deletion or demotion of the primary admin account.  
* **system.php (System Module):**  
  * **Purpose:** Handles miscellaneous system-level tasks.  
  * **Key Functions:**  
    * initializeSystem(): Populates the filesystem with default data (users.json, etc.) and home directories on first run.  
    * runSelfTests(): An admin-only diagnostic tool to verify system health and configuration.  
* **sandbox.php (Sandbox Module):**  
  * **Purpose:** Provides a secure environment for executing untrusted PHP code submitted by applications.  
  * **Mechanism:** It writes the target code to a temporary file and executes it in an isolated child process via proc\_open. Crucially, it uses the \-d disable\_functions command-line directive to prevent the sandboxed code from calling dangerous PHP functions. It also imposes strict memory and time limits on the child process.

### **2.2. Frontend Architecture (JavaScript)**

The frontend is a sophisticated single-page application built with object-oriented JavaScript. It does not rely on a modern framework but instead uses a custom-built class structure to manage the OS.

#### **2.2.1. The Kernel Class**

This is the central controller for the entire frontend application. A single instance is created and attached to the window object as window.kernel.

* **initialize() Method:** This is the OS boot sequence. It is an async function that orchestrates the following steps:  
  1. Fetches the system configuration from the backend.  
  2. Initializes all core JavaScript modules (UIManager, ProcessManager, etc.).  
  3. Creates service proxies to communicate with the backend API.  
  4. Validates the user's session token with the auth API.  
  5. Based on the authentication result, it transitions to either the login screen (\_showLoginScreen) or the main desktop environment (\_showDesktop).

#### **2.2.2. Core Frontend Modules**

* **EventSystem**: A simple publisher/subscriber model that allows for decoupled communication between different parts of the application (e.g., the auth service can emit an auth:login event, which the Kernel listens for to trigger the transition to the desktop).  
* **SecurityManager**: Caches the user's permissions on the client-side after login. This allows for immediate UI feedback (e.g., hiding an admin button) without requiring a server round-trip for every check.  
* **ProcessManager**: Manages the lifecycle of applications. It is responsible for creating, managing, and terminating application windows and their associated taskbar items.  
* **UIManager**: Handles all direct DOM manipulation related to the global UI, including themes, notifications, dialog boxes, and the context menu.

#### **2.2.3. Application Launch Flow**

1. A user action (e.g., double-clicking a desktop icon) triggers the kernel.launchApplication('app-id') method.  
2. The Kernel consults the SecurityManager to verify the user has the required permission (e.g., app.launch.fileManager).  
3. An API call is made to fetch the application's manifest (app.json) from the backend.  
4. The ProcessManager is invoked to create a new window element, render it in the DOM, and create a corresponding taskbar item.  
5. The Kernel's \_bootApplicationCode method is called. It inspects the entry point defined in the manifest and executes the corresponding global JavaScript function (e.g., fileManagerApp(process)), passing the process context to it. This final step initializes the application's specific UI inside its newly created window.

## **3\. Developer Guide**

GOS provides a streamlined workflow for users with the developer role to create and submit new applications.

### **3.1. The Development and Submission Process**

1. **Access:** The "Developer Center" application is the primary interface for creating new apps. It is only visible and launchable by users with the developer role.  
2. **Manifest Creation:** The developer fills out a form to define the application's manifest (app.json). This includes its unique ID, title, icon, and required permissions.  
3. **Code Implementation:** The developer writes the application's logic directly into a JavaScript code editor within the Developer Center. This code will be saved as app.js.  
4. **Submission:** Upon submission, the manifest and code are sent to the backend submitApp API endpoint. The backend validates the data and adds it to a pending review queue located at /gos\_files/system/app\_submissions.json.

### **3.2. The Administrative Approval Process**

1. **Review:** An administrator opens the "App Store" application. A "Submissions" tab, visible only to admins, lists all pending applications from the review queue.  
2. **Approval:** The administrator can review the manifest and code for safety and functionality. Clicking "Approve" triggers the approveSubmission API endpoint.  
3. **Deployment:** The backend handler for approveSubmission performs the final deployment step: it creates a new directory /gos\_files/apps/\<app-id\>/ and writes the app.json and app.js files into it.  
4. **Availability:** Once the files are created on the server, the application is immediately available to all users via the discoverAppManifests() function and will appear in the App Store.

## **4\. Security Model**

Security is a foundational principle of the Genesis Operating System, implemented through a multi-layered approach.

* **Role-Based Access Control (RBAC):** The system is built around a clear and strict permission model. All potentially sensitive actions are gated by a hasPermission() check on the backend. This ensures that even if a user attempts to bypass client-side restrictions, the server will reject the unauthorized request.  
* **Session Security:** The system employs standard best practices for session management. It regenerates the session ID upon login to prevent fixation and uses HttpOnly and Secure cookie flags to protect the session identifier from client-side script access and to ensure it is only transmitted over encrypted connections.  
* **Filesystem Jailing:** The combination of the resolvePath() and canAccessPath() functions in the filesystem.php module creates a "jail" for users. All file access is validated against the user's permissions and their home directory, preventing them from accessing or modifying unauthorized parts of the server's filesystem.  
* **Sandboxed Code Execution:** The Sandbox module provides a critical layer of security for running potentially untrusted code. By executing code in a separate, resource-limited process with a list of disabled, dangerous functions, it significantly mitigates the risk of a malicious or poorly written application impacting the stability or security of the host server.  
* **Input Sanitization:** User-provided data, such as names during registration, is sanitized using htmlspecialchars() before being stored or displayed, providing a fundamental defense against Cross-Site Scripting (XSS) attacks.

## **5\. API Integration Guide**

This section provides a comprehensive guide for developers to interact with the Genesis OS backend API.

### **5.1. Fundamental Concepts**

* **Endpoint Structure:** All API requests are directed to a single PHP file, genesis-os.php. The specific API module is selected via a URL query parameter ?api=\<module\_name\>.  
  * Example: https://yourdomain.com/genesis-os.php?api=filesystem  
* **Request Format:** The API exclusively uses the POST method. The body of the request must be a JSON object containing two keys:  
  * method: A string specifying the function to call within the module.  
  * params: A JSON object containing the parameters for that function.  
* **Response Format:** All API responses are JSON objects with a consistent structure:  
  * success: A boolean indicating if the operation was successful.  
  * data: (Optional) If success is true, this key contains the payload of the response.  
  * message: (Optional) If success is false, this key contains a human-readable error message.

### **5.2. Authentication**

The GOS API is session-based. To access protected endpoints, a client must first authenticate and then include the returned session cookie in all subsequent requests.

1. **Login:** Send a POST request to ?api=auth with the method login.  
2. **Session Cookie:** A successful login will result in the server sending back a Set-Cookie header containing the session ID (typically named PHPSESSID). The client's HTTP library must store this cookie.  
3. **Authenticated Requests:** All subsequent API calls to protected endpoints must include this session cookie in the Cookie header.

### **5.3. Internal Integration (Within GOS Applications)**

For developers building applications within the GOS environment, the Kernel provides a high-level abstraction for API calls, eliminating the need to manually construct fetch requests.

The Kernel exposes all API modules through its api property: kernel.api.\<module\_name\>. Each module proxy has a .call(method, params) function.

**Example: Reading a file from a GOS application**

// This code would run inside a GOS application, like the File Manager.  
async function displayWelcomeFile() {  
    try {  
        // The service proxy handles the fetch call, JSON stringifying, and error checking.  
        const file \= await kernel.api.filesystem.call('readFile', {  
            path: '/users/guest/Documents/welcome.txt'  
        });

        // The 'file' variable now contains the 'data' object from the server's response.  
        console.log('File content:', file.content);  
        kernel.modules.ui.showNotification('Success', 'File loaded successfully.');

    } catch (error) {  
        // If the server returns { success: false }, the .call() method throws an error.  
        kernel.modules.ui.showNotification('Error', error.message, 5000);  
    }  
}

### **5.4. External Integration (Third-Party Applications)**

External applications can integrate with GOS by following the standard authentication flow using an HTTP client that supports cookie management, such as cURL.

**Example: Listing files using cURL**

1. **Step 1: Authenticate and Save the Session Cookie**  
   \# The \-c flag saves the cookies from the response to a file named 'cookies.txt'  
   curl \-X POST \\  
     \-H "Content-Type: application/json" \\  
     \-d '{"method": "login", "params": {"username": "admin", "password": "00EITA00"}}' \\  
     \-c cookies.txt \\  
     https://yourdomain.com/genesis-os.php?api=auth

2. **Step 2: Make an Authenticated Request Using the Saved Cookie**  
   \# The \-b flag sends the cookies from the specified file with the request  
   curl \-X POST \\  
     \-H "Content-Type: application/json" \\  
     \-d '{"method": "listDirectory", "params": {"path": "/users/admin/Desktop"}}' \\  
     \-b cookies.txt \\  
     https://yourdomain.com/genesis-os.php?api=filesystem

### **5.5. API Endpoint Reference**

#### **Module: auth**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| login | Public | { "username": "...", "password": "..." } | { "user": {...}, "permissions": \[...\] } |
| logout | Authenticated User | {} | null |
| register | Public | { "username": "...", "password": "...", "name": "..." } | null |
| validateToken | Public | {} | { "valid": boolean, "user": {...}, "permissions": \[...\] } |

#### **Module: filesystem**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| readFile | Authenticated User | { "path": "/path/to/file.txt" } | { "content": "...", "size": 123, "modified": 1678886400 } |
| writeFile | Authenticated User | { "path": "/path/to/file.txt", "content": "..." } | { "path": "...", "size": 123, "modified": ... } |
| deleteFile | Authenticated User | { "path": "/path/to/file.txt" } | null |
| listDirectory | Authenticated User | { "path": "/path/to/directory" } | \[ { "name": "...", "path": "...", "type": "file"|"directory", ... } \] |
| createDirectory | Authenticated User | { "path": "/path/to/new\_directory" } | null |

#### **Module: apps**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| listApps | Authenticated User | {} | \[ { "id": "...", "title": "...", ... } \] |
| getAppInfo | Authenticated User | { "id": "app-id" } | { "id": "...", "title": "...", ... } |
| submitApp | Developer | { "manifest": "{...}", "code": "..." } | null |
| listSubmissions | Admin | {} | \[ { "manifest": {...}, "code": "...", ... } \] |
| approveSubmission | Admin | { "id": "app-id" } | null |
| rejectSubmission | Admin | { "id": "app-id" } | null |

#### **Module: users (Admin Only)**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| listUsers | Admin | {} | \[ { "username": "...", "name": "...", "roles": \[...\] } \] |
| createUser | Admin | { "username": "...", "password": "...", "name": "...", "roles": \[...\] } | null |
| updateUser | Admin | { "username": "...", "name": "...", "roles": \[...\] } | null |
| deleteUser | Admin | { "username": "..." } | null |
| setPassword | Admin | { "username": "...", "newPassword": "..." } | null |

#### **Module: system**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| getSystemInfo | Public | {} | { "name": "...", "version": "...", ... } |
| logError | Authenticated User | { "message": "...", "details": "..." } | null |
| getLanguagePack | Public | { "lang": "en" } | { "login\_heading": "...", ... } |
| runSelfTests | Admin | {} | { "php\_version\_ok": boolean, ... } |

#### **Module: sandbox**

| Method | Permission | Parameters (params) | Success Data (data) |
| :---- | :---- | :---- | :---- |
| execute | Admin | { "code": "\<?php ... ?\>" } | { "output": "...", "errors": "...", "exitCode": 0 } |

