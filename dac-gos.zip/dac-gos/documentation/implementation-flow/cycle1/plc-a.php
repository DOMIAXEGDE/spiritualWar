<?php
// plc-a.php - PLC with Automation System
// This script acts as a Programmable Logic Controller for the broader
// compositional software architecture. It inspects the environment,
// identifies available automation tasks, and reports the system's
// current state and configuration in a language-agnostic JSON format.

header('Content-Type: application/json');
error_reporting(0); // Suppress errors in production for clean JSON output

define('COMPOSER_DATA_DIR', __DIR__ . '/composer_data');

/**
 * A collection of functions that simulate the core logic of the provided
 * system files to gather state information for the PLC.
 */
class SystemInspector
{
    /**
     * Scans the composer data directory for projects.
     * Mimics list_composer_projects() from jisc.php.
     * @return array A list of project names.
     */
    public static function getProjects(): array
    {
        $projects = [];
        if (!is_dir(COMPOSER_DATA_DIR)) {
            return [];
        }
        $items = array_diff(scandir(COMPOSER_DATA_DIR), ['..', '.']);
        foreach ($items as $item) {
            if (is_dir(COMPOSER_DATA_DIR . '/' . $item)) {
                $projects[] = $item;
            }
        }
        return $projects;
    }

    /**
     * Scans a project for its definition libraries and compositions.
     * @param string $project The name of the project.
     * @return array An associative array with 'definition_libs' and 'compositions'.
     */
    public static function getProjectAssets(string $project): array
    {
        $assets = [
            'definition_libs' => [],
            'compositions' => [],
        ];
        $projectPath = COMPOSER_DATA_DIR . '/' . $project;
        if (!is_dir($projectPath)) {
            return $assets;
        }

        // Get Definition Libraries
        $defDir = $projectPath . '/definitions';
        if (is_dir($defDir)) {
            $items = array_diff(scandir($defDir), ['..', '.']);
            foreach ($items as $item) {
                if (pathinfo($item, PATHINFO_EXTENSION) === 'json') {
                    $assets['definition_libs'][] = $item;
                }
            }
        }

        // Get Compositions
        $compDir = $projectPath . '/compositions';
        if (is_dir($compDir)) {
            $items = array_diff(scandir($compDir), ['..', '.']);
            foreach ($items as $item) {
                if (str_ends_with($item, '.composition.json')) {
                    $assets['compositions'][] = $item;
                }
            }
        }
        return $assets;
    }
}

// --- PLC STATE GATHERING ---

$plcState = [
    'plc_id' => 'plc-a-v1.0',
    'plc_status' => 'OPERATIONAL',
    'timestamp_utc' => gmdate('c'),
    'system_architecture' => 'Bidirectional, Compositional Software Architecture',
    'monitored_directory' => realpath(COMPOSER_DATA_DIR) ?: COMPOSER_DATA_DIR,
    'system_components' => [
        'analytical_engine' => 'cidd.php',
        'compositional_engine' => 'codebase-composer.php',
        'automation_controller' => 'jisc.php',
        'plc_interface' => 'plc-a.php',
    ],
    'automation_tasks' => [
        [
            'task_id' => 'batch_generate_definitions',
            'description' => 'Automated creation of foundational Definition Libraries from a string of characters. Corresponds to the Alphabet Generator in jisc.php.',
            'api_action' => 'batch_generate_definitions',
            'required_inputs' => [
                ['name' => 'project', 'type' => 'string', 'description' => 'The target Composer project.'],
                ['name' => 'lib_name', 'type' => 'string', 'description' => 'The filename for the new Definition Library (e.g., "my_alphabet").'],
                ['name' => 'characters', 'type' => 'string', 'description' => 'A string containing all characters to be defined (e.g., "abc...").'],
            ],
            'output_artifact' => '/composer_data/{project}/definitions/{lib_name}.json',
        ],
        [
            'task_id' => 'execute_sequence',
            'description' => 'Programmatic assembly of a new Composition by executing a sequence of references to existing Definition IDs. Corresponds to the Indexing-Sequencer in jisc.php.',
            'api_action' => 'execute_sequence',
            'required_inputs' => [
                ['name' => 'project', 'type' => 'string', 'description' => 'The target Composer project.'],
                ['name' => 'comp_name', 'type' => 'string', 'description' => 'The name for the new Composition (e.g., "hello_world").'],
                ['name' => 'definitions', 'type' => 'array[string]', 'description' => 'An array of Definition IDs in the desired sequence.'],
            ],
            'output_artifact' => [
                '/composer_data/{project}/compositions/{comp_name}.composition.json',
                '/composer_data/{project}/compositions/{comp_name}.txt',
            ],
        ],
         [
            'task_id' => 'promote_to_composer',
            'description' => 'Promotes an analytical entry from the CIDD system to become a canonical, reusable Definition in the Composer system.',
            'api_action' => 'promote_to_composer',
            'required_inputs' => [
                ['name' => 'cidd_id', 'type' => 'string', 'description' => 'The unique ID of the entry in the cidd_db.json file.'],
                ['name' => 'project', 'type' => 'string', 'description' => 'The target Composer project.'],
                ['name' => 'library', 'type' => 'string', 'description' => 'The target Definition Library file within the project.'],
            ],
            'output_artifact' => 'Updates /composer_data/{project}/definitions/{library} and cidd_db.json',
        ],
    ],
    'available_projects' => [],
];

// --- POPULATE STATE WITH LIVE DATA ---

$projects = SystemInspector::getProjects();
if (empty($projects)) {
    $plcState['plc_status'] = 'WARNING';
    $plcState['status_message'] = 'No projects found in the monitored directory. The system is idle.';
} else {
    foreach ($projects as $projectName) {
        $assets = SystemInspector::getProjectAssets($projectName);
        $plcState['available_projects'][] = [
            'project_name' => $projectName,
            'definition_libraries' => $assets['definition_libs'],
            'compositions' => $assets['compositions'],
        ];
    }
}

// --- OUTPUT FINAL JSON ---

echo json_encode($plcState, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

?>
